"""Luau parser: recursive descent producing AST. Strips types, preserves semantics.
No regex transforms — all desugaring happens on the token stream / AST.
Supports: locals w/ types, export type (skipped), compound ops, continue,
if-expressions, interpolated strings, varargs, nested closures, upvalues,
numeric/generic for, while/repeat, method calls, tables, goto/labels.
"""
from dataclasses import dataclass, field
from typing import List, Optional, Tuple, Union
from .lexer import Lexer, Tok, LexError

class ParseError(Exception):
    pass

# ---------------- AST ----------------
@dataclass
class Block:
    stmts: list
    ret: Optional["Ret"]
    line: int

@dataclass
class Ret:
    exprs: list
    line: int

# Stmts
@dataclass
class S_Nop:
    pass
@dataclass
class S_Local:
    names: List[str]
    exprs: list
    line: int
@dataclass
class S_Assign:
    lhs: list  # Var nodes
    rhs: list
    line: int
@dataclass
class S_Compound:
    op: str  # 'add','sub','mul','div','idiv','mod','pow','concat','band','bor','bxor','shl','shr'
    lhs: object
    rhs: object
    line: int
@dataclass
class S_Call:
    expr: object
@dataclass
class S_Do:
    body: Block
@dataclass
class S_While:
    cond: object
    body: Block
    line: int
@dataclass
class S_Repeat:
    body: Block
    cond: object
    line: int
@dataclass
class S_If:
    arms: list  # [(cond, block)]
    else_: Optional[Block]
    line: int
@dataclass
class S_NumFor:
    var: str
    start: object
    limit: object
    step: Optional[object]
    body: Block
    line: int
@dataclass
class S_GenFor:
    names: List[str]
    iters: list
    body: Block
    line: int
@dataclass
class S_FuncDef:
    base: str
    fields: List[str]
    method: Optional[str]
    body: object  # FuncBody
    line: int
@dataclass
class S_LocalFunc:
    name: str
    body: object
    line: int
@dataclass
class S_Break:
    line: int
@dataclass
class S_Continue:
    line: int
@dataclass
class S_Goto:
    label: str
    line: int
@dataclass
class S_Label:
    name: str
    line: int
@dataclass
class S_TypeDecl:
    pass  # skipped (type/export type) -> no-op

@dataclass
class FuncBody:
    params: List[str]
    vararg: bool
    body: Block
    line: int

# Vars
@dataclass
class V_Name:
    name: str
@dataclass
class V_Index:
    tab: object
    key: object
@dataclass
class V_Field:
    tab: object
    field: str

# Exprs
@dataclass
class E_Nil:
    pass
@dataclass
class E_Bool:
    v: bool
@dataclass
class E_Num:
    v: float
    raw: str
@dataclass
class E_Str:
    data: bytes
@dataclass
class E_Interp:
    segs: list  # [('lit',bytes),('exp',expr)]
@dataclass
class E_Vararg:
    line: int
@dataclass
class E_Var:
    var: object
    line: int
@dataclass
class E_Call:
    func: object
    args: list
    line: int
@dataclass
class E_Method:
    obj: object
    method: str
    args: list
    line: int
@dataclass
class E_Func:
    body: FuncBody
@dataclass
class E_Table:
    fields: list  # TableField
    line: int
@dataclass
class E_Binop:
    op: str
    l: object
    r: object
    line: int
@dataclass
class E_Unop:
    op: str
    e: object
    line: int
@dataclass
class E_IfExpr:
    arms: list  # [(cond, val)]
    else_: object
    line: int

@dataclass
class F_Rec:
    key: str
    val: object
@dataclass
class F_Idx:
    key: object
    val: object
@dataclass
class F_Elem:
    val: object

BINOP_MAP = {
    "+": "add", "-": "sub", "*": "mul", "/": "div", "//": "idiv", "%": "mod",
    "^": "pow", "..": "concat",
    "==": "eq", "~=": "ne", "<": "lt", ">": "gt", "<=": "le", ">=": "ge",
    "and": "and", "or": "or",
    "&": "band", "|": "bor", "~": "bxor", "<<": "shl", ">>": "shr",
}
# '~' is unary bnot or binary bxor depending on context; handled in parser.
COMPOUND_MAP = {
    "+=": "add", "-=": "sub", "*=": "mul", "/=": "div", "//=": "idiv",
    "%=": "mod", "^=": "pow", "..=": "concat",
    "&=": "band", "|=": "bor", "~=": None,  # '~=' is comparison, NOT compound! (handled: '~=' never compound)
}
# Note: Luau has no &= etc.? Actually Luau does NOT have bitwise compound ops in older versions,
# but we accept them harmlessly. '~=' is always 'not equal'.

UNOP_MAP = {"-": "neg", "not": "not", "#": "len", "~": "bnot"}

class Parser:
    def __init__(self, toks: List[Tok]):
        self.t = toks
        self.p = 0

    def peek(self) -> Tok:
        return self.t[min(self.p, len(self.t)-1)]

    def peekn(self, n) -> Tok:
        return self.t[min(self.p+n, len(self.t)-1)]

    def next(self) -> Tok:
        t = self.peek()
        if self.p < len(self.t):
            self.p += 1
        return t

    def err(self, msg, tok=None):
        t = tok or self.peek()
        raise ParseError(f"parse error at {t.line}:{t.col}: {msg}")

    def is_kw(self, w):
        t = self.peek()
        return t.kind == "kw" and t.val == w

    def is_sym(self, s):
        t = self.peek()
        return t.kind == "sym" and t.val == s

    def eat_kw(self, w):
        if self.is_kw(w):
            return self.next()
        return None

    def exp_kw(self, w):
        t = self.eat_kw(w)
        if not t:
            self.err(f"expected '{w}'")
        return t

    def eat_sym(self, s):
        if self.is_sym(s):
            return self.next()
        return None

    def exp_sym(self, s):
        t = self.eat_sym(s)
        if not t:
            self.err(f"expected '{s}'")
        return t

    def peek_ident(self):
        t = self.peek()
        if t.kind == "ident":
            return t.val
        return None

    def exp_ident(self):
        t = self.peek()
        if t.kind == "ident":
            return self.next().val
        self.err("expected identifier")

    # ---------- entry ----------
    def parse_block(self) -> Block:
        stmts = []
        ret = None
        line = self.peek().line
        while True:
            t = self.peek()
            if t.kind == "eof":
                break
            if t.kind == "kw" and t.val in ("end","else","elseif","until"):
                break
            if t.kind == "sym" and t.val == "}":
                break
            # return must be last (allow trailing ';')
            if t.kind == "kw" and t.val == "return":
                ret = self.parse_return()
                # consume trailing ';'
                while self.eat_sym(";"):
                    pass
                break
            s = self.parse_stmt()
            stmts.append(s)
            while self.eat_sym(";"):
                pass
        return Block(stmts, ret, line)

    def parse_return(self) -> Ret:
        t = self.next()  # return
        exprs = []
        # return can be bare
        pk = self.peek()
        if pk.kind == "eof" or (pk.kind=="kw" and pk.val in ("end","else","elseif","until")) or (pk.kind=="sym" and pk.val=="}"):
            return Ret([], t.line)
        if pk.kind == "sym" and pk.val == ";":
            return Ret([], t.line)
        exprs.append(self.parse_expr())
        while self.eat_sym(","):
            exprs.append(self.parse_expr())
        return Ret(exprs, t.line)

    # ---------- statements ----------
    def parse_stmt(self):
        t = self.peek()
        if t.kind == "kw":
            w = t.val
            if w == "local":
                return self.parse_local()
            if w == "do":
                self.next()
                b = self.parse_block()
                self.exp_kw("end")
                return S_Do(b)
            if w == "while":
                return self.parse_while()
            if w == "repeat":
                return self.parse_repeat()
            if w == "if":
                return self.parse_if_stmt()
            if w == "for":
                return self.parse_for()
            if w == "function":
                return self.parse_funcdef()
            if w == "break":
                self.next()
                return S_Break(t.line)
            if w == "continue":
                self.next()
                return S_Continue(t.line)
            if w == "goto":
                self.next()
                lbl = self.exp_ident()
                return S_Goto(lbl, t.line)
            if w == "type" or w == "export":
                return self.parse_typedecl()
            if w == "return":
                self.err("unexpected return")
        if t.kind == "sym" and t.val == "::":
            # label ::name::
            self.next()
            nm = self.exp_ident()
            self.exp_sym("::")
            return S_Label(nm, t.line)
        # assignment / call
        return self.parse_expr_stmt()

    def parse_typedecl(self):
        # 'type' Name ['<' ... '>'] '=' <skip type>  OR  'export' 'type' ...
        t = self.peek()
        if t.val == "export":
            self.next()
            if not self.eat_kw("type"):
                self.err("expected 'type' after 'export'")
        else:
            self.next()  # type
        # name (allow dotted? no, just ident)
        if self.peek().kind == "ident":
            self.next()
        # generic params <...>
        if self.is_sym("<"):
            self.skip_angle()
        # '=' then skip type expr
        if self.eat_sym("="):
            self.skip_type_expr()
        return S_TypeDecl()

    def skip_angle(self):
        # consume balanced <...>
        assert self.eat_sym("<")
        depth = 1
        while depth > 0:
            t = self.next()
            if t.kind == "eof":
                self.err("unfinished generic params")
            if t.kind == "sym":
                if t.val == "<":
                    depth += 1
                elif t.val == ">":
                    depth -= 1
                elif t.val == ">>":
                    depth -= 2
                    if depth < 0:
                        self.err("bad >> in generics")
        # note: '>>' consumed as one token counts as 2

    def skip_type_expr(self):
        # skip tokens until ',', ';', 'end'-ish, ')' '}' ']' at depth 0, or newline-insensitive terminator.
        # We track paren/bracket/brace/angle depth; stop at ',' ';' eof or kw end/else/elseif/until/do/then/in.
        depth_p = 0; depth_b = 0; depth_c = 0; depth_a = 0
        while True:
            t = self.peek()
            if t.kind == "eof":
                break
            if t.kind == "kw" and t.val in ("end","else","elseif","until","then","do","in","return","local","function","for","while","repeat","if","break","continue","type","export"):
                if depth_p==0 and depth_b==0 and depth_c==0 and depth_a==0:
                    break
            if t.kind == "sym":
                v = t.val
                if v in ("(",):
                    depth_p += 1; self.next(); continue
                if v == ")":
                    if depth_p==0:
                        break
                    depth_p -= 1; self.next(); continue
                if v == "{":
                    depth_c += 1; self.next(); continue
                if v == "}":
                    if depth_c==0:
                        break
                    depth_c -= 1; self.next(); continue
                if v == "[":
                    depth_b += 1; self.next(); continue
                if v == "]":
                    if depth_b==0:
                        break
                    depth_b -= 1; self.next(); continue
                if v == "<":
                    depth_a += 1; self.next(); continue
                if v == ">":
                    if depth_a>0:
                        depth_a -= 1; self.next(); continue
                    else:
                        break
                if v in (",",";","=") and depth_p==0 and depth_b==0 and depth_c==0 and depth_a==0:
                    break
                # '|' '&' '?', ':' etc. are part of types
                self.next(); continue
            self.next()

    def skip_type_suffix(self):
        # after a name/param: [':' <type>] ['?' ] — also handles '::' casts? no.
        # Handle '?'-suffix (optional) and ':' type.
        if self.is_sym(":"):
            # but '::' is label; check
            if self.peekn(1).kind=="sym" and self.peekn(1).val==":":
                return
            self.next()  # :
            # also '::' ? no.
            self.skip_type_expr()

    def parse_local(self):
        t = self.next()  # local
        # 'local function name ...'
        if self.is_kw("function"):
            self.next()
            nm = self.exp_ident()
            # generic params?
            if self.is_sym("<"):
                self.skip_angle()
            body = self.parse_funcbody()
            return S_LocalFunc(nm, body, t.line)
        # 'local type ...'? Luau: 'local type X = ...' — treat as typedecl no-op
        if self.is_kw("type"):
            self.next()
            if self.peek().kind == "ident":
                self.next()
            if self.is_sym("<"):
                self.skip_angle()
            if self.eat_sym("="):
                self.skip_type_expr()
            return S_TypeDecl()
        names = [self.exp_ident()]
        # generic? no. type suffix per name? Luau allows 'local a: T, b: U = ...'
        self.skip_type_suffix()
        while self.eat_sym(","):
            names.append(self.exp_ident())
            self.skip_type_suffix()
        exprs = []
        if self.eat_sym("="):
            exprs.append(self.parse_expr())
            while self.eat_sym(","):
                exprs.append(self.parse_expr())
        return S_Local(names, exprs, t.line)

    def parse_while(self):
        t = self.next()
        cond = self.parse_expr()
        self.exp_kw("do")
        body = self.parse_block()
        self.exp_kw("end")
        return S_While(cond, body, t.line)

    def parse_repeat(self):
        t = self.next()
        body = self.parse_block()
        self.exp_kw("until")
        cond = self.parse_expr()
        return S_Repeat(body, cond, t.line)

    def parse_if_stmt(self):
        t = self.next()
        cond = self.parse_expr()
        self.exp_kw("then")
        b = self.parse_block()
        arms = [(cond, b)]
        else_ = None
        while self.is_kw("elseif"):
            self.next()
            c = self.parse_expr()
            self.exp_kw("then")
            bb = self.parse_block()
            arms.append((c, bb))
        if self.eat_kw("else"):
            else_ = self.parse_block()
        self.exp_kw("end")
        return S_If(arms, else_, t.line)

    def parse_for(self):
        t = self.next()
        nm = self.exp_ident()
        # check numeric vs generic: '=' means numeric; ':' type then '=' numeric; ',' or 'in' means generic
        # optional type suffix on loop var
        self.skip_type_suffix()
        if self.is_sym("="):
            self.next()
            start = self.parse_expr()
            self.exp_sym(",")
            limit = self.parse_expr()
            step = None
            if self.eat_sym(","):
                step = self.parse_expr()
            self.exp_kw("do")
            body = self.parse_block()
            self.exp_kw("end")
            return S_NumFor(nm, start, limit, step, body, t.line)
        # generic
        names = [nm]
        while self.eat_sym(","):
            names.append(self.exp_ident())
            self.skip_type_suffix()
        self.exp_kw("in")
        iters = [self.parse_expr()]
        while self.eat_sym(","):
            iters.append(self.parse_expr())
        self.exp_kw("do")
        body = self.parse_block()
        self.exp_kw("end")
        return S_GenFor(names, iters, body, t.line)

    def parse_funcdef(self):
        t = self.next()
        base = self.exp_ident()
        fields = []
        method = None
        while True:
            if self.eat_sym("."):
                fields.append(self.exp_ident())
            elif self.eat_sym(":"):
                method = self.exp_ident()
                break
            else:
                break
        # generic?
        if self.is_sym("<"):
            self.skip_angle()
        body = self.parse_funcbody()
        return S_FuncDef(base, fields, method, body, t.line)

    def parse_funcbody(self) -> FuncBody:
        t = self.exp_sym("(")
        params = []
        vararg = False
        if not self.is_sym(")"):
            while True:
                if self.is_sym("..."):
                    self.next()
                    # optional type after ...? ': T'
                    if self.is_sym(":"):
                        self.next()
                        self.skip_type_expr()
                    vararg = True
                    break
                if self.peek().kind == "kw" and self.peek().val == "self":
                    self.next()
                    params.append("self")
                else:
                    nm = self.exp_ident()
                    # type suffix, default value? Luau allows default? handle '=' expr as ignored? Actually keep: if '=' then skip expr? For simplicity treat default as error? Luau doesn't have defaults. Skip.
                    self.skip_type_suffix()
                    params.append(nm)
                if not self.eat_sym(","):
                    break
                if self.is_sym(")"):
                    break
        self.exp_sym(")")
        # return type? ': ...' before body
        if self.is_sym(":"):
            # could be ': Type' — skip
            # careful: ':' followed by '(' ? no. skip type
            self.next()
            self.skip_type_expr()
        # generic after params? already handled. body
        # Luau attr? ignore
        b = self.parse_block()
        # expect end
        if not self.eat_kw("end"):
            self.err("expected 'end' for function body")
        return FuncBody(params, vararg, b, t.line)

    def parse_expr_stmt(self):
        # try to parse as call first? Standard: parse prefix expr then decide.
        e = self.parse_expr()
        t0 = e
        # check assignment: e must be var(s)
        if isinstance(e, (E_Var, E_Method, E_Call)):
            # collect comma-separated LHS if next is ','
            # Only vars can be assigned. Calls cannot.
            if self.eat_sym(","):
                # multiple LHS
                lhs = [self.as_var(e)]
                # parse more vars
                e2 = self.parse_expr()
                lhs.append(self.as_var(e2))
                while self.eat_sym(","):
                    lhs.append(self.as_var(self.parse_expr()))
                # compound or plain?
                if self.peek().kind == "sym" and self.peek().val in ("=", "+=", "-=", "*=", "/=", "//=", "%=", "^=", "..="):
                    op = self.next().val
                    rhs = [self.parse_expr()]
                    while self.eat_sym(","):
                        rhs.append(self.parse_expr())
                    if op == "=":
                        return S_Assign(lhs, rhs, self.stmt_line(e))
                    else:
                        if len(lhs) != 1 or len(rhs) != 1:
                            self.err("compound assignment needs single target/value")
                        return S_Compound(BINOP_MAP[op[:-1]], lhs[0], rhs[0], self.stmt_line(e))
                else:
                    self.err("expected '=' after assignment targets")
            # single: check '=' or compound
            if self.peek().kind == "sym" and self.peek().val in ("=", "+=", "-=", "*=", "/=", "//=", "%=", "^=", "..="):
                op = self.next().val
                rhs = [self.parse_expr()]
                while self.eat_sym(","):
                    rhs.append(self.parse_expr())
                if op == "=":
                    return S_Assign([self.as_var(e)], rhs, self.stmt_line(e))
                else:
                    if len(rhs) != 1:
                        self.err("compound assignment needs single value")
                    return S_Compound(BINOP_MAP[op[:-1]], self.as_var(e), rhs[0], self.stmt_line(e))
            # bitwise compound &= |= ? (Luau doesn't have, but accept)
            if self.peek().kind == "sym" and self.peek().val in ("&=", "|="):
                op = self.next().val
                rhs = self.parse_expr()
                m = {"&=": "band", "|=": "bor"}[op]
                return S_Compound(m, self.as_var(e), rhs, self.stmt_line(e))
            # otherwise must be a call statement
            if isinstance(e, (E_Call, E_Method)):
                return S_Call(e)
            self.err("expected assignment or call")
        self.err("unexpected expression statement")

    def stmt_line(self, e):
        for attr in ("line",):
            if hasattr(e, attr):
                return getattr(e, attr)
        return self.peek().line

    def as_var(self, e):
        if isinstance(e, E_Var):
            return e.var
        self.err("cannot assign to non-variable")

    # ---------- expressions (precedence climbing) ----------
    def parse_expr(self):
        # if-expr has lowest precedence
        if self.is_kw("if"):
            return self.parse_ifexpr()
        return self.parse_or()

    def parse_ifexpr(self):
        t = self.next()  # if
        arms = []
        c = self.parse_expr()
        self.exp_kw("then")
        v = self.parse_expr()
        arms.append((c, v))
        while self.is_kw("elseif"):
            self.next()
            c = self.parse_expr()
            self.exp_kw("then")
            v = self.parse_expr()
            arms.append((c, v))
        self.exp_kw("else")
        e = self.parse_expr()
        # Luau if-expr ends with 'end'? Actually `if x then y else z` — no end? In Luau, if-expressions DO end without 'end'? Check: Luau if-expression: `local x = if cond then a else b`. No 'end'. But some versions require? We accept optional 'end'.
        if self.is_kw("end"):
            self.next()
        return E_IfExpr(arms, e, t.line)

    def parse_or(self):
        l = self.parse_and()
        while self.is_kw("or"):
            self.next()
            r = self.parse_and()
            l = E_Binop("or", l, r, self.stmt_line(l))
        return l

    def parse_and(self):
        l = self.parse_cmp()
        while self.is_kw("and"):
            self.next()
            r = self.parse_cmp()
            l = E_Binop("and", l, r, self.stmt_line(l))
        return l

    def parse_cmp(self):
        l = self.parse_bor()
        while True:
            t = self.peek()
            op = None
            if t.kind == "sym" and t.val in ("==","~=","<","<=",">",">="):
                op = BINOP_MAP[t.val]
                self.next()
            else:
                break
            r = self.parse_bor()
            l = E_Binop(op, l, r, self.stmt_line(l))
        return l

    def parse_bor(self):
        l = self.parse_bxor()
        while self.is_sym("|"):
            self.next()
            # '|' could be part of type? in expr it's bor
            r = self.parse_bxor()
            l = E_Binop("bor", l, r, self.stmt_line(l))
        return l

    def parse_bxor(self):
        l = self.parse_band()
        # '~' binary bxor — but must not consume '~=' (ne). Lexer gives '~=' as one token, so bare '~' here is bxor/bnot.
        while self.is_sym("~"):
            # check next is '='? lexer already merged, so no.
            self.next()
            r = self.parse_band()
            l = E_Binop("bxor", l, r, self.stmt_line(l))
        return l

    def parse_band(self):
        l = self.parse_shift()
        while self.is_sym("&"):
            self.next()
            r = self.parse_shift()
            l = E_Binop("band", l, r, self.stmt_line(l))
        return l

    def parse_shift(self):
        l = self.parse_concat()
        while self.peek().kind=="sym" and self.peek().val in ("<<",">>"):
            op = BINOP_MAP[self.next().val]
            r = self.parse_concat()
            l = E_Binop(op, l, r, self.stmt_line(l))
        return l

    def parse_concat(self):
        l = self.parse_add()
        if self.is_sym(".."):
            self.next()
            r = self.parse_concat()  # right assoc
            l = E_Binop("concat", l, r, self.stmt_line(l))
        return l

    def parse_add(self):
        l = self.parse_mul()
        while self.peek().kind=="sym" and self.peek().val in ("+","-"):
            op = BINOP_MAP[self.next().val]
            r = self.parse_mul()
            l = E_Binop(op, l, r, self.stmt_line(l))
        return l

    def parse_mul(self):
        l = self.parse_unary()
        while True:
            t = self.peek()
            if t.kind=="sym" and t.val in ("*","/","//","%"):
                op = BINOP_MAP[self.next().val]
                r = self.parse_unary()
                l = E_Binop(op, l, r, self.stmt_line(l))
            else:
                break
        return l

    def parse_unary(self):
        t = self.peek()
        if t.kind=="sym" and t.val in ("-","#","~"):
            self.next()
            e = self.parse_unary()
            m = {"-":"neg","#":"len","~":"bnot"}[t.val]
            return E_Unop(m, e, t.line)
        if t.kind=="kw" and t.val in ("not",):
            self.next()
            e = self.parse_unary()
            return E_Unop("not", e, t.line)
        return self.parse_pow()

    def parse_pow(self):
        b = self.parse_atom()
        if self.is_sym("^"):
            self.next()
            e = self.parse_unary()  # right assoc, unary on rhs
            b = E_Binop("pow", b, e, self.stmt_line(b))
        return b

    def parse_atom(self) -> object:
        t = self.peek()
        if t.kind == "kw":
            if t.val == "nil":
                self.next(); return E_Nil()
            if t.val == "true":
                self.next(); return E_Bool(True)
            if t.val == "false":
                self.next(); return E_Bool(False)
            if t.val == "function":
                self.next()
                if self.is_sym("<"):
                    self.skip_angle()
                body = self.parse_funcbody()
                return E_Func(body)
            if t.val == "self":
                pass  # fall through to var handling below
            else:
                # 'and/or/not' shouldn't reach here
                self.err(f"unexpected keyword '{t.val}'")
        if t.kind == "num":
            self.next()
            return E_Num(t.num if t.num is not None else 0.0, t.val)
        if t.kind == "str":
            self.next()
            assert t.data is not None
            return E_Str(t.data)
        if t.kind == "interp":
            self.next()
            segs = []
            for kind, val in t.parts:  # type: ignore
                if kind == "lit":
                    segs.append(("lit", val))
                else:
                    # re-parse inner expr from source text
                    sub = Parser(Lexer(val).tokenize())
                    e = sub.parse_expr()
                    segs.append(("exp", e))
            return E_Interp(segs)
        if t.kind == "sym" and t.val == "...":
            self.next()
            return E_Vararg(t.line)
        if t.kind == "sym" and t.val == "{":
            return self.parse_table()
        if t.kind == "sym" and t.val == "(":
            self.next()
            e = self.parse_expr()
            self.exp_sym(")")
            return self.parse_suffix(e)
        if t.kind == "ident" or (t.kind=="kw" and t.val=="self"):
            self.next()
            name = t.val
            # type cast '::'? e.g. 'x :: T' — skip cast, keep x
            base: object = E_Var(V_Name(name), t.line)
            # handle '::' cast suffix: while '::' then skip type
            while self.is_sym("::"):
                # '::' is lexed as '::' single token
                self.next()
                # skip type name
                if self.peek().kind in ("ident",):
                    self.next()
                # generic? skip
                if self.is_sym("<"):
                    self.skip_angle()
                # base stays same
            base = self.parse_suffix(base)
            return base
        self.err(f"unexpected token {t.kind}:{t.val!r}")

    def parse_suffix(self, base):
        while True:
            t = self.peek()
            if t.kind == "sym" and t.val == ".":
                self.next()
                fld = self.exp_ident()
                # optional type args? ignore
                base = E_Var(V_Field(base, fld), self.stmt_line(base))
                # handle :: cast after?
                continue
            if t.kind == "sym" and t.val == ":":
                # method call — but '::' is label/cast, already handled; single ':' here is method
                # peekn to distinguish '::'
                if self.peekn(1).kind=="sym" and self.peekn(1).val==":":
                    break
                self.next()
                m = self.exp_ident()
                args = self.parse_callargs()
                base = E_Method(base, m, args, self.stmt_line(base))
                continue
            if t.kind == "sym" and t.val == "[":
                self.next()
                k = self.parse_expr()
                self.exp_sym("]")
                base = E_Var(V_Index(base, k), self.stmt_line(base))
                continue
            if t.kind == "sym" and t.val in ("(", "{") or t.kind in ("str",):
                args = self.parse_callargs()
                # base must be callable
                base = E_Call(base, args, self.stmt_line(base))
                continue
            # also handle string-call without parens already via str token? parse_callargs handles.
            break
        return base

    def parse_callargs(self):
        t = self.peek()
        if t.kind == "sym" and t.val == "(":
            self.next()
            args = []
            if not self.is_sym(")"):
                args.append(self.parse_expr())
                while self.eat_sym(","):
                    args.append(self.parse_expr())
            self.exp_sym(")")
            return args
        if t.kind == "sym" and t.val == "{":
            return [self.parse_table()]
        if t.kind == "str":
            self.next()
            assert t.data is not None
            return [E_Str(t.data)]
        # Luau also allows `f`string`` call? e.g. f`hi{x}` — treat interp as single arg
        if t.kind == "interp":
            e = self.parse_atom()
            return [e]
        self.err("expected function arguments")

    def parse_table(self):
        t = self.exp_sym("{")
        fields = []
        line = t.line
        while not self.is_sym("}"):
            if self.is_sym("}"):
                break
            # '[k] = v' or 'name = v' or value
            if self.eat_sym("["):
                k = self.parse_expr()
                self.exp_sym("]")
                self.exp_sym("=")
                v = self.parse_expr()
                fields.append(F_Idx(k, v))
            elif self.peek().kind == "ident" and self.peekn(1).kind=="sym" and self.peekn(1).val=="=":
                nm = self.next().val
                self.next()  # =
                v = self.parse_expr()
                fields.append(F_Rec(nm, v))
            else:
                v = self.parse_expr()
                fields.append(F_Elem(v))
            if not self.eat_sym(",") and not self.eat_sym(";"):
                break
        self.exp_sym("}")
        # optional trailing? no
        e = E_Table(fields, line)
        return self.parse_suffix(e)


def parse(src: str) -> Block:
    toks = Lexer(src).tokenize()
    p = Parser(toks)
    b = p.parse_block()
    # expect eof
    if p.peek().kind != "eof":
        p.err("unexpected trailing tokens")
    return b
