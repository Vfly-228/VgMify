# luauvm-protect — VM-Based Luau Obfuscator (Luraph v15.1-class)

Single-file VM obfuscator for Roblox Luau. Compiles Luau source to private
register bytecode executed by an embedded interpreter. No `loadstring(bytecode)`
passthrough — the VM handlers actually execute the program.

Language choice: **Python** (per spec's "Node.js + TypeScript OR Python, your
choice"). File map vs the spec's JS names:

| spec | this repo |
|---|---|
| `/src/parser.js` | `src/parser.py` (lexer `src/lexer.py` + parser) |
| `/src/compiler.js` | `src/compiler.py` |
| `/src/vm_template.lua` | `src/vm_v3.lua` (+ `src/prelude_v3.lua`, `src/loader_v3.lua`, `src/parse_v3.lua`) |
| `/src/encryptor.js` | `src/encryptor.py` (+ `src/v3core.py`, `src/hardhash.py`) |
| `/src/mutator.js` | `src/mutator.py` |
| `/cli.js` | `cli.py` (+ thin Node shim `cli.js`) |
| `/tests/roundtrip.test.js` | `tests/roundtrip_test.py` (+ shim `tests/roundtrip.test.js`) |

## Quick start

```bash
python cli.py --input src.lua --output out.lua --preset luraph15 --seed RANDOM
python cli.py --input src.lua --output out.lua --preset medium --seed 12345
python cli.py --input src.lua --output out.lua --preset luraph15 --seed 99 --bind-env 123456789
python cli.py --input src.lua --emit-ir --seed 1   # dump IR
node cli.js --input src.lua --output out.lua --preset luraph15 --seed RANDOM
```

Presets: `light` (level 0: translated + superoperators, single segment),
`medium` (level 2: + fake consts, spans, keyed multi-segments),
`luraph15` (level 3: + junk protos, wrapper refs, denser spans).
`--level 0-3` overrides the preset. `--seed` accepts decimal/hex int or
`RANDOM`. Same seed ⇒ byte-identical output. `--bind-env ID` binds the build
to a runtime env id (e.g. `game.JobId`); the output only decrypts where the
runtime id matches, so a static dump alone is insufficient.

## Pipeline

```
Luau source -> lex (src/lexer.py, no regex) -> parse (src/parser.py, types stripped)
  -> compile (src/compiler.py: 54-op register/box IR incl. 5 superoperators)
  -> harden+encrypt (src/encryptor.py + v3core.py + hardhash.py:
     per-build ARX hash, salted KDF, superop fusion, fake consts, junk,
     real-touching spans, bitstream + chained per-instruction keys,
     split out-of-order consts, keyed segments)
  -> emit (src/emit.py + src/mutator.py + v3 lua templates:
     per-build hash params, salts/seps, widths, wire map, opaque dispatch,
     shuffled handlers/spec, self-check, order-bit decoys)
  -> single obfuscated.lua
```

## VM opcodes (54 real ids, wired polymorphically per build)

Base 49 (`NOP/MOVE/LOADK/LOADNIL/LOADBOOL/ADD/SUB/MUL/DIV/MOD/POW/
IDIV/BAND/BOR/BXOR/SHL/SHR/BNOT/UNM/NOT/LEN/CONCAT/EQ/LT/LE/TEST/JMP/CALL/
RETURN/TAILCALL/VARARG/CLOSURE/GETUPVAL/SETUPVAL/CAPTURE/CAPNIL/GETGLOBAL/
SETGLOBAL/GETTABLE/SETTABLE/SELF/NEWTABLE/SETLIST/FORPREP/FORLOOP/TFORPREP/
TFORCALL/TFORLOOP/CLOSE`) plus 5 superoperators:

- `LCONCAT_KK A,Bk,Ck` — fused `LOADK,LOADK,CONCAT` (both const)
- `LCONCAT_RK A,Breg,Ck` / `LCONCAT_KR A,Bk,Creg` — fused `LOADK,CONCAT`
- `TLOOP A,Bo,Co` — fused `TFORCALL,TFORLOOP`
- `TJMP A,Bo,C` — fused `TEST,JMP`

Per build, 2–5 of the 5 are enabled for emission (all 5 handlers ship, so
unused ones are decoys). This breaks the old 1:1 Lua mapping
(`1=MOVE,2=LOADK,5=ADD,21=CONCAT,27=CALL,38=GETTABLE` no longer holds).

Named locals live in boxes (`BX` own, `UX` inherited); temps in `R`. This gives
correct upvalues/closures without a capture pre-pass. `GETGLOBAL/SETGLOBAL`
carry lazily-decrypted consts, so `game`, `task`, `getgenv`, method names, etc.
never appear literally. `...` is preserved via `VARARG` + `table.pack/unpack`
with `n`. Executor compat: only `string/table/math` core + `bit32` when present
(pure-Lua fallback otherwise); no `buffer`, no FFI, no 5.4-only operators in
emitted code.

## Encryption (v3)

- Hash: per-build ARX (`src/hardhash.py`): randomized rotation constants,
  round count 56–80, random init vectors, K-table split into 2–4 shuffled
  chunks reconstructed with arithmetic. No stock SHA256 constants in output;
  a different hash function ships per build. Lua mirror is byte-exact
  (verified against Python for empty/short/long/binary inputs).
- KDF: `user_key = H(priv_salt + env)` where `env` is the runtime
  `game.JobId` or `"local-test"`; `seed_material = H(user_key + build_salt +
  seed4)`; `k_enc/k_perm/k_con/k_jnk = H(seed_material + sep_domain)` with
  6 random separator bytes per domain built at runtime via `string.char`
  arithmetic. Only salts/IV ship (obfuscated); never the user key, never a
  `LVM2` literal. `--bind-env` makes Python use the expected id so output
  only runs there.
- Stream: `enc[i] = plain[i] ^ ks ^ (prev_plain & FF)` with per-256B rekey
  `H(k_enc + iv + chunk + clock_quant)`. The clock quantum is 0 on normal
  runs and drifts under a slowed-down debugger (garbage, fail closed).
- Opcodes: 68–90 wire ids per build (54 real + 10–20 alias doubles + dead).
  Per-proto Fisher–Yates seeded by `H(k_perm + proto_idx)`; per-instruction
  bias from `H(k_perm + proto_idx + instr_idx)` plus low-byte chaining with
  the previous instruction and overlapping fields (`B += A*m1`, `C += B*m2`).
- Bitstream: 7-bit wire ids + escaped operands (per-build widths 10–14 bit,
  32-bit escape) + 0–2 fake pad bits per instruction keyed by the stream.
  No LEB128. Operand counts/lengths use fixed little-endian fields.
- Consts: type byte encrypted; strings/numbers split into 2–5 chunks with
  random sizes, shuffled order with index, per-chunk nonce and chained key
  `H(k_con + nonce + idx + prev_hash)`. Reassembled on demand at use
  (`__kget`; strings are never memoized). Fake consts are appended and
  referenced by dead blocks.
- Segments: 1 (L0/L1) or keyed 2–4 with a per-segment mixed decimal/hex map
  and keyed bucket assignment. Integrity is encrypt-then-MAC (per-build
  HMAC); any mismatch wipes all key material (`nil` + `collectgarbage`)
  and fails with a runtime-built generic message.

## Mutations

- Number/salt/sep material as expressions; seed split into 3 random shares
  (never derived from payload lengths); load-bearing segment-order decoys.
- Superoperator fusion with full jump remapping (verified by tests).
- Dead code: alias/string/arithmetic opaque predicates (always-true/false,
  never `MOVE r,r; EQ r,r` templates), live blocks that save/touch/restore
  real registers with identity ops, shared rejoin targets, crash-safe junk
  protos, wrapper closures capturing real upvalues and called conditionally,
  no NOP sleds on live paths.
- VM: threaded dispatch through 4 handler groups keyed by per-build opaque
  ids (`((real*mult+add) % 256) ^ xor`, shuffled spec/handler order, 8–32
  fault decoys + 255 fault), plus a flattened dispatcher state
  (`trans[state] + opaque + key`). No linear `if op==38 ... elseif` chain.
- Anti-instrumentation: runtime behavior self-check of the hash
  implementation (mismatch silently corrupts the key, no error signal),
  on-demand const decrypt without string caching, clock-quantum key drift,
  split VM/handlers with per-build renames (no single hookable interpreter
  name).

## Tests

```bash
python tests/roundtrip_test.py --preset light
python tests/roundtrip_test.py --preset medium
python tests/roundtrip_test.py --preset luraph15
python tests/acceptance_test.py
```

25 roundtrip cases per preset (services, upvalues, varargs, loops, methods,
tailcalls, metatables, …) plus 5 acceptance tests: fingerprint
(`6a09e667|428a2f98|LVM2|bad opcode|bad chunk` ⇒ 0 hits), liveness
(naive def-use DCE retains >90%), tamper (1-char flip fails closed, no
partial output), diversity (different seeds ⇒ ~78% byte diff, dispatch
order diff), secrecy + functional (`Alice/Bob/Charlie/Hello` never literal;
`example.lua` prints `Hello…/counter=85/5+7=12`).

Status (verified 2026-10-13): 75/75 roundtrip + 5/5 acceptance green.
Growth on `luraph15` is ~87× for the 583 B `example.lua` (50,658 chars,
seed 99; `light`/`medium` ~79–81×) and ~28× for the 2.8 KB many-locals
case (was ~150–400× / ~150× before the v3.1 lean pass); single-char inputs
stay ~4000× (fixed ~44 KB VM/loader floor). Executor load+execute on the
example dropped ~27.8 s → ~0.30 s (~93×, lupa proxy) from removing
per-instruction hashes, the bit-at-a-time reader, and threaded dispatch.
Different seeds ⇒ different bytes, same seed ⇒ byte-identical output
(LF-canonical file write, cross-OS stable).

## Reverse-spec

See `REPORT.md` for the IronBrew2 vs Luraph v15.1 vs this implementation spec
table, inferred from the five provided Luraph outputs, plus the v3
hardening notes.
