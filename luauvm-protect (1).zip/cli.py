#!/usr/bin/env python3
"""CLI: obfuscate --input src.lua --output out.lua --preset [light|medium|luraph15] --seed RANDOM"""
import argparse
import random
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

from src.api import obfuscate, emit_ir, PRESETS

def main():
    ap = argparse.ArgumentParser(prog="obfuscate", description="VM-based Luau obfuscator")
    ap.add_argument("--input", required=False, default="-", help="Input .lua/.luau file or - for stdin")
    ap.add_argument("--output", required=False, default="-", help="Output file or - for stdout")
    ap.add_argument("--preset", default="medium", choices=sorted(PRESETS), help="Hardening preset")
    ap.add_argument("--seed", default=None, help="Obfuscation seed (int) or RANDOM")
    ap.add_argument("--level", type=int, default=None, help="Override level 0-3")
    ap.add_argument("--strip-debug", action="store_true", help="Strip debug line info")
    ap.add_argument("--emit-ir", action="store_true", help="Print IR dump instead of obfuscating")
    ap.add_argument("--bind-env", default=None, help="Bind build to a runtime env id (e.g. game JobId); output only runs where it matches")
    # compat: allow positional `protect input` form and --input/--output with = or space
    args, extra = ap.parse_known_args()
    # handle `protect` positional remnant
    if extra:
        # allow: obfuscate protect input.luau  OR  obfuscate input.luau
        cleaned = [e for e in extra if e != "protect"]
        if len(cleaned) == 1 and args.input == "-":
            args.input = cleaned[0]
        elif cleaned:
            ap.error(f"unexpected extra arguments: {cleaned}")

    if args.seed is None or (isinstance(args.seed, str) and args.seed.upper() == "RANDOM"):
        seed = random.randrange(0, 2**32)
    else:
        try:
            seed = int(str(args.seed), 0)
        except ValueError:
            ap.error(f"bad --seed {args.seed!r}")

    if args.input == "-":
        src = sys.stdin.read()
    else:
        src = Path(args.input).read_text(encoding="utf-8")

    if args.emit_ir:
        out = emit_ir(src)
    else:
        out = obfuscate(src, seed=seed, preset=args.preset, level=args.level,
                        strip_debug=args.strip_debug, bind_env=args.bind_env)

    if args.output == "-":
        sys.stdout.write(out)
    else:
        # LF-canonical write: same seed => byte-identical file on all OSes
        # (default text-mode write would inflate with CRLF on Windows).
        Path(args.output).write_text(out, encoding="utf-8", newline="\n")
    # log seed to stderr for reproducibility
    print(f"[luauvm-protect] preset={args.preset} seed={seed}", file=sys.stderr)

if __name__ == "__main__":
    main()
