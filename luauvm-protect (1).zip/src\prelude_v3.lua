local __G = _G
local __select = select
local __type = type
local __next = next
local __getmt = getmetatable
local __setmt = setmetatable
local __tostring = tostring
local __tonumber = tonumber
local __error = error
local __xpcall = xpcall
local __tpack = table.pack or function(...)
    local t = { n = __select("#", ...) }
    for i = 1, t.n do t[i] = __select(i, ...) end
    return t
end
local __tunpack = table.unpack or unpack
local __tconcat = table.concat
local __sbyte = string.byte
local __schar = string.char
local __ssub = string.sub
local __slen = string.len
local __mathfloor = math.floor
local __clock = os and os.clock

local __ENV = __G
do
    local ok, e = pcall(function() return getfenv(0) end)
    if ok and __type(e) == "table" then
        __ENV = e
    else
        local ok1, e1 = pcall(function() return getfenv() end)
        if ok1 and __type(e1) == "table" then
            __ENV = e1
        else
            local ok2, g = pcall(function() return (getgenv and getgenv()) or nil end)
            if ok2 and __type(g) == "table" then
                __ENV = g
            else
                local ok3, r = pcall(function() return (getrenv and getrenv()) or nil end)
                if ok3 and __type(r) == "table" then
                    __ENV = r
                end
            end
        end
    end
    if __type(__ENV) ~= "table" then __ENV = __G end
    if __type(__ENV) ~= "table" then __ENV = {} end
end

local __bit = __ENV["bit32"]
if __bit == nil then __bit = rawget(__G, "bit32") end
local __band, __bor, __bxor, __shl, __shr, __bnot
if __bit then
    __band, __bor, __bxor, __shl, __shr, __bnot =
        __bit.band, __bit.bor, __bit.bxor, __bit.lshift, __bit.rshift, __bit.bnot
else
    local __nbx, __nbn, __nbo = {}, {}, {}
    for __a = 0, 15 do
        for __b = 0, 15 do
            local __x, __y, __rx, __rn, __ro, __m = __a, __b, 0, 0, 0, 1
            for __k = 1, 4 do
                local __ba, __bb = __x % 2, __y % 2
                if __ba ~= __bb then __rx = __rx + __m end
                if __ba == 1 and __bb == 1 then __rn = __rn + __m end
                if __ba == 1 or __bb == 1 then __ro = __ro + __m end
                __x = __mathfloor(__x / 2)
                __y = __mathfloor(__y / 2)
                __m = __m * 2
            end
            __nbx[__a * 16 + __b] = __rx
            __nbn[__a * 16 + __b] = __rn
            __nbo[__a * 16 + __b] = __ro
        end
    end
    local function __cmb32(__t, __a, __b)
        __a = __a % 4294967296
        __b = __b % 4294967296
        local __r, __m = 0, 1
        for __i = 1, 8 do
            __r = __r + __t[(__a % 16) * 16 + (__b % 16)] * __m
            __m = __m * 16
            __a = __mathfloor(__a / 16)
            __b = __mathfloor(__b / 16)
        end
        return __r
    end
    __band = function(__a, __b) return __cmb32(__nbn, __a, __b) end
    __bor = function(__a, __b) return __cmb32(__nbo, __a, __b) end
    __bxor = function(__a, __b) return __cmb32(__nbx, __a, __b) end
    __shl = function(__a, __n)
        __n = __n % 32
        if __n == 0 then return __a % 4294967296 end
        return ((__a % (2 ^ (32 - __n))) * (2 ^ __n)) % 4294967296
    end
    __shr = function(__a, __n)
        __n = __n % 32
        if __n == 0 then return __a % 4294967296 end
        return __mathfloor((__a % 4294967296) / (2 ^ __n))
    end
    __bnot = function(__a) return 4294967295 - (__a % 4294967296) end
end
local function __idiv(a, b) return __mathfloor(a / b) end
local function __rotr(__x, __n)
    __n = __n % 32
    if __n == 0 then return __x % 4294967296 end
    return (__shr(__x, __n) + __shl(__x, 32 - __n)) % 4294967296
end
local function __xsstep(__s)
    __s = __s % 4294967296
    __s = __bxor(__s, __shl(__s, 13))
    __s = __bxor(__s, __shr(__s, 17))
    __s = __bxor(__s, __shl(__s, 5))
    if __s == 0 then __s = 2654435769 end
    return __s
end

__HASHPARAMS__

__HASHFN__

-- __ENV captured above (prefers getfenv(0) so game/task/etc. resolve on Roblox)

local function __getfenv(f)
    if f == nil or f == 0 then return __ENV end
    return __ENV
end
local function __setfenv(f, t)
    if __type(t) == "table" then
        if f == nil or f == 0 then
            for k, v in __next, t, nil do __ENV[k] = v end
        end
        return t
    end
    return t
end

local function __iteradj(v)
    if __type(v) == "function" then return v, nil, nil end
    local mt = __getmt(v)
    if mt ~= nil then
        local it = mt.__iter
        if it ~= nil then
            local a, b, c = it(v)
            return a, b, c
        end
    end
    if __type(v) == "table" then return __next, v, nil end
    __error("attempt to iterate over a " .. __type(v) .. " value", 2)
end

local __reg = __setmt({}, { __mode = "k" })

local __eline = 0
local function __eh(msg)
    if __type(msg) == "string" then
        return msg .. " (line " .. __tostring(__eline) .. ")"
    end
    return msg
end
