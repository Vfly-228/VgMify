"""Top-level obfuscation API + presets (v3)."""
from . import parser as parser_mod
from . import compiler as compiler_mod
from . import encryptor as encryptor_mod
from . import emit as emit_mod

PRESETS = {
    "light":   {"level": 0},
    "medium":  {"level": 2},
    "luraph15": {"level": 3},
}

def obfuscate(src: str, seed: int = 0x12345678, preset: str = "medium",
               level: int | None = None, strip_debug: bool = False,
               bind_env: str | None = None) -> str:
    """Obfuscate Lua source.

    bind_env: expected runtime env id (e.g. game JobId) to bind the
    build to. None = no binding (tests / portable). When set, the
    output only decrypts where runtime JobId equals bind_env; static
    dumps alone are insufficient.
    """
    if preset not in PRESETS:
        raise ValueError(f"unknown preset {preset!r}; choose from {sorted(PRESETS)}")
    lv = PRESETS[preset]["level"] if level is None else max(0, min(3, level))
    block = parser_mod.parse(src)
    proto = compiler_mod.Compiler().compile(block)
    payload = encryptor_mod.build_payload(proto, seed & 0xFFFFFFFFFFFFFFFF, lv, strip_debug, bind_env)
    return emit_mod.render(payload, seed & 0xFFFFFFFFFFFFFFFF, lv)

def emit_ir(src: str) -> str:
    block = parser_mod.parse(src)
    proto = compiler_mod.Compiler().compile(block)
    return proto.dump(0)
