-- Example script for maximum-protection obfuscation demo
local function greet(name)
    local msg = "Hello, " .. name .. "!"
    return msg
end

local players = { "Alice", "Bob", "Charlie" }
for i, name in ipairs(players) do
    print(greet(name) .. " (#" .. i .. ")")
end

local counter = 0
for i = 1, 10 do
    if i % 2 == 0 then
        counter = counter + i * 2
    else
        counter = counter + i
    end
end
print("counter=" .. counter)

local function makeAdder(x)
    return function(y)
        return x + y
    end
end
local add5 = makeAdder(5)
print("5+7=" .. add5(7))
