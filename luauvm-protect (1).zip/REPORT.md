# REPORT.md — VM Obfuscator Reverse-Spec: IronBrew2 pattern vs Luraph v15.1 vs Our Implementation

Target: single-file Luau output runnable on standard Roblox executors (Lua 5.1 + Luau + UNC, `loadstring` + `getgenv` style, no external deps).

Samples analysed (all start with `-- This file was protected using Luraph Obfuscator v15.1`):

| file | bytes | shape |
|---|---|---|
| `e20f3887d419069f.lua` | 345141 | full-VM, ~66 handler funcs, 10× `while true do local`, 287× `elseif` |
| `cf96f658de290478.lua` | 356561 | full-VM, ~66 handlers, 16× `while true`, 290× `elseif` |
| `390ea6acb88b8f9f.lua` | 286257 | full-VM, ~68 handlers, 13× `while true`, 288× `elseif` |
| `99ba879f8b2ec51c.lua` | 1542205 | full-VM large (likely big input), ~66 handlers, 12× `while true` |
| `2153b779fa7a87f2.lua` | 280360 | **different preset** ("light"?): only 5 funcs, 1× `while true`, `loadstring` ×2, `table.create`, small dispatch |

## 1. IronBrew v2 architecture (reference model)

IronBrew2 is the canonical open-source Lua VM obfuscator. Studied as architectural example:

- **Chunk reader**: parses `luac` bytecode (header, prototypes, constants, code, debug). Constants kept typed (nil/bool/number/string).
- **Constant encoder**: strings XOR-encrypted per-build, numbers arithmetically masked (`(k*X+Y)%M`), stored as encrypted blob.
- **Opcode mapping**: ~35–40 Lua 5.1 opcodes (`MOVE, LOADK, LOADBOOL, LOADNIL, GETUPVAL, GETGLOBAL, GETTABLE, SETTABLE, ADD…CALL, RETURN, JMP, TEST, EQ, LT, LE, FORLOOP, TFORLOOP, CLOSURE, VARARG…`) remapped through a per-build permutation; instruction stream stored as numbers, decoded at runtime.
- **VM template generation**: a Lua template with `while true do <dispatch> end`, one `if op==N then <handler> end` branch per opcode, stack table `Stk`, `Top`, `Const`, `Proto` tables. Handlers are plain Lua that emulates the original semantics.
- **Wrapper structure**: `loadstring(decrypted_chunk)()` is **not** used for logic — the VM loop actually executes. Outer wrapper only decrypts the payload string and calls the VM entry. Desync techniques: extra `[]` chunks, fake jumps, and `do … end` wrappers that break naive decompilers expecting `luac` structure.
- **Anti-tamper**: integrity constant (checksum of payload); mutated payload fails to decode.

## 2. Luraph v15.1 inferred spec (from the 5 samples)

### 2.1 VM header / bootloader shape

All samples share:

```lua
-- This file was protected using Luraph Obfuscator v15.1 [https://lura.ph/]
return setmetatable({...}, {}):name() (...)
```

- Outer is a single `return setmetatable(V, {}):method(...)` call. `V` is a table mixing:
  - **import slots**: `[82]=buffer.writeu32, [116]=ipairs, [70]=function…` — numeric keys bound to whitelisted stdlib / Roblox APIs (`buffer.*`, `bit32.*`, `string.*`, `table.*`, `coroutine.*`, `Vector2.new`, `UDim.new`, `Color3.new`, `typeof`, `ipairs/pairs`, `tostring`, `pcall`, `assert`, …). Full-VM samples bind ~60 distinct imports; the light sample binds ~8.
  - **opcode handlers**: short 1–2-letter names (`ju, Lu, z, xu, Au, a, …` / `wA, oA, bA, …` / `tH, O, Q, …`) — each is `function(m,F,o,V,P,a,M,…) if o<=N then … elseif … end end`. Each handler takes the VM state and a numeric sub-opcode and returns `next_handler_id, new_state…`. This is a **register/threaded dispatch**, not a single `while/op==N` loop: handlers tail-call each other by numeric id (`return 16,a,Y,L` / `return 34,a,m[77](V),M`). Observed return-id range 0–~160, consistent with **~60–90 distinct micro-ops** (multiple handlers per logical opcode for operand-mode splits).
  - **encrypted payload**: either inline long-string blobs (`z=[=[LPH?%&~ …]=]` in the light sample, several KB of high-entropy `A-Za-z0-9` + punctuation) or numeric/buffer blobs referenced by handlers. Full-VM samples keep the blob fragmented across handler upvalues rather than one visible string.
- Trailer calls the entry handler with varargs: `}):ou()(...)`, `}):qA()(...)`, `}):rH()(...)`, `}):WS()(...)`, `}):u()(...)`. `...` is forwarded, so **varargs survive** by construction.
- `2153b779…` (light) differs: only 5 top-level funcs (`u,h,G,D,T`), `loadstring` ×2, `table.create`, `buffer.create/fromstring`. It most likely decrypts to a smaller VM or a `loadstring`-staged payload. Full samples have **zero** `loadstring` — they never recompile source, they interpret.

### 2.2 Junk / dead-code patterns

- Opaque predicates: `local F,L,_=Y[2],Y[4],Y[5]; local n,Z=F+L,L<=0; L,F=n>=_,n<=_; _=Z and L or not Z and F; Y[2]=n; if _ then return 24,… else return 38,… end` — computes both `>=` and `<=` and selects with `and/or/not` so the branch looks data-dependent but is a flattened comparison. Repeated verbatim across handlers.
- Dead arithmetic: `local _,n,Z,H=85*(L-P),52200625*(S-33),7225*(M-33),(f-33)*1; local P=n+_+(H+(Z+I))` — base-85-style digit recombination (string/number decode) mixed with unused intermediates.
- Single-use locals with random caps (`S,f,I,L,_,n,Z,H,P,Y,…`), shadowed params (`function(A,H,H,H)`), `if o<=19 then if o<=18 then …` dense numeric range splits (control-flow flattening of the handler itself).
- `while true do local S=H<=5; if S then local S=H<=2; if H<=0 then …` — **flattened VM loop**: numeric state `H` (0–11 in that loop) selects the next block; every block ends with `H,…=next,…`. This is classic control-flow flattening.

### 2.3 Custom bytecode format, opcode count, handlers

- Handler-function count ~66 per full build (plus ~10 `while true` loops = flattened functions). Each handler covers 2–5 sub-ops via `if o<=N` chains. Estimated logical opcode coverage: `LOADK, LOADNIL, LOADBOOL, MOVE, GETUPVAL/SETUPVAL, GETGLOBAL/SETGLOBAL, GETTABLE/SETTABLE, SELF, ADD/SUB/MUL/DIV/MOD/POW/IDIV/BAND/BOR/BXOR/SHL/SHR/BNOT/UNM/NOT/LEN/CONCAT, EQ/LT/LE/TEST, JMP, CALL/TAILCALL/RETURN, CLOSURE, VARARG, NEWTABLE/SETLIST, FORPREP/FORLOOP/TFORPREP/TFORCALL/TFORLOOP, CLOSE` — i.e. full Lua 5.1 + Luau extensions (`IDIV, BAND…SHR`, `SELF`, `CAPTURE`-equivalents). Our target of **25+ custom opcodes** is a lower bound; we implement **49** (see §4).
- Instruction encoding: varint-style byte streams. Fingerprints: `m[66](V,2+o)` / `m[66](V,o)` = `buffer.readu8`-like fetch; `128>P`, `128>F`, `P<128`, `P%128*128`, `(F-128)*2097152`, `(M-128)*16384`, `2097152*(P-L)` — LEB128-style 7-bit groups with `0x80` continuation, scaled by `128^k` (1, 16384=128², 2097152=128³). I.e. **encrypted instruction stream of varints**, decoded with shifts/multiplies, not plain tables.
- Operands are stack/register indices and constant indices, remapped per build (handler numeric ids differ per file: `return 16…` vs `return 11…` for the same shape).

### 2.4 Constant / string / number encryption

- Strings: never literal in full samples except stdlib names. Payload blobs are high-entropy ASCII (`LPH?%&~ '"#(!>PyO…`), consistent with **XOR + base64-ish + fragmented** storage. The light sample keeps one `[=[…]=]` blob (~10–20 KB); full samples fragment it across decoder upvalues.
- Numbers: arithmetic masking. Fingerprints: `85*(L-P)`, `52200625*(S-33)` (=85³), `7225*(M-33)` (=85²) — base-85 digit decode; `a={[0]=1,2,4,8,…,4294967296}` powers-of-two table (bit reconstruction); `P%=4294967296; if P~=P then return 0 end; return P-P%1` (canonicalise NaN→0, floor to u32); `F,s=N(F,4294967295),N(s,4294967295)` (`bit32.band(x,0xFFFFFFFF)` normalisation) plus a custom `D` multiply emulation (`z*n+…`) for exact u32 mul on 5.1 doubles.
- Integers in emitted code are split: `(0x3F*2)+1`-style expressions appear as `(F-128)*2097152` etc. — **number-to-expression** is pervasive.
- Integrity: every sample keeps a checksum path (`__cs` accumulation / `if __cs ~= … then error…` analogue). Tampering with one blob byte breaks decode (avalanche via chained XOR/offset).

### 2.5 Control-flow flattening, block wrapping, function splitting

- Each original function becomes one or more `while true do local STATE=entry; while true do if STATE<=…` flattened loops. Observed state ranges 0–11, 0–20, etc.
- Functions are split: one Lua closure per VM function, plus shared decoder closures (`R.Z`, `U.m`, `U.xS` registries in `99ba…`). Upvalues become explicit box tables (`M[5]=M; M[6]=V[P]; M[4]=6` — box with tag/parent links).
- Calls preserve multi-return and tailcalls: trailer logic `if Q then if B then if b then return t[d](Y(R,1,R.n)) else return t[d](Y(t,d+1,R)) end; elseif d then …` handles `R.n`-packed returns (`Y`=unpack, `R`=packed).

### 2.6 Anti-decompile / anti-format / anti-beautify

- Single-line emission (2 lines total: header + one giant line). No newlines for beautifiers to anchor on; `;` and `,` separators only.
- No `loadstring(bytecode)` passthrough — `unluac`/decompilers see only the VM interpreter, not the user program. Payload is data, not code.
- Shadowing (`function(A,H,H,H)`), 1–2-char names, numeric table keys, `setmetatable` bootloader, and `buffer`+`bit32` interleaving defeat pattern-based formatters.
- Size growth: 280 KB–1.5 MB outputs for inputs that are typically 5–50 KB → **>10× growth** on heavy preset, as required.

### 2.7 How `game:GetService()`, `getgenv()`, upvalues, `...`, `task.wait()` survive

- No name mangling of **global/method names**: `game`, `task`, `getgenv`, `GetService`, `wait` etc. survive as **constant strings** (encrypted at rest, decrypted into the const table at load). `game:GetService("Players")` compiles to `GETGLOBAL game; LOADK "GetService"; SELF; LOADK "Players"; CALL` — the VM's `SELF`/`CALL`/`GETTABLE` handlers execute the real method on the real object. No stubbing needed.
- `getgenv`, `getfenv/setfenv`, `identifyexecutor` are just `GETGLOBAL`s routed through the chunk env (`__ENV` aliased to real `_G`), so executor-provided globals resolve identically.
- Upvalues/`...`: explicit box tables + `VARARG` packing (`table.pack(...)` / `unpack(...,1,n)`) with `n` preserved, so `...`, `select('#',...)`, and nested closures alias correctly.
- `task.wait()` etc. are ordinary calls; the VM does not yield itself, so executor schedulers are unaffected. `coroutine.*` imports are whitelisted so user coroutines pass through.

## 3. Target spec table

| feature | IronBrew2 how | Luraph v15.1 how (inferred) | our implementation plan |
|---|---|---|---|
| VM loop | single `while true` + `if op==N` dispatch on `Stk/Top` | threaded handlers returning next-id + flattened `while STATE` loops | single `while true` + `if op==N` dispatch (49 ops) **plus** L2+ jump-span flattening + opaque `EQ r,r` decoys; threaded-handler shape mimicked via junk funcs |
| instruction encoding | numeric opcode + operands, permuted ids | LEB128 varints, `128^k` scales, per-build permuted handler ids | varint body + 1-byte permuted opcode (`Fisher-Yates(LCG(seed^0x9E3779B9))`), zigzag jump offsets |
| string encryption | per-build XOR blob | XOR + fragmented high-entropy ASCII blob | LCG keystream `ks=(st>>16)&FF`, `enc=(plain+ks+(i*31)%256)%256`, decimal `000–255` encoding, 1 or 3 round-robin segments |
| number encoding | arith masking | base-85 digits, pow2 table, u32 canonicalise, split exprs | numbers as decimal strings in const table (exact round-trip) + emitted seed/checksum as `(p1+p2)%2^32` split exprs |
| function protos | `luac` protos | split closures + box tables + `R.n` multret | proto tree (`nparams/vararg/nregs/nown/consts/code/children/uvdescs/lines`), box model (`BX` own, `UX` inherited), `CAPTURE/CAPNIL/CLOSURE/GETUPVAL/SETUPVAL`, tailcall reframing |
| CF flattening | fake jumps | numeric-state `while` + range-split handlers | IR jump-span injection (uncond jump over junk + opaque-predicate edge) with full jump remapping; emitter decoy `if __d==k` blocks + junk funcs |
| integrity | checksum const | checksum-guarded decode | `checksum=sum(blob)%2^32` checked at L3 (`error("unexpected symbol near 'end'")`); header `LVM\x01` + version/level |
| anti-decompile | desync chunks | 1-line, shadowing, no `loadstring`, `buffer`+`bit32` mix | 1-line-ish emission (prelude+loader+VM, no user source), randomised handler order is via permuted ids, no `loadstring`, only `string/table/math/bit32` + stock globals |
| compat | Lua 5.1 | Luau + `buffer` (executor) | **stock Luau, no `buffer`** (string-based blob) so output runs on any `loadstring` executor + vanilla Lua 5.1/5.4 for tests; `bit32` only via guarded fallback to `&/\|/~` when present? No — we emit only `bit32`-free arithmetic + `string/table/math` core, `bit32` used only if present for speed (not required) |
| `game/getgenv/.../task` | env passthrough | import table + `SELF/CALL` | `GETGLOBAL` via `__ENV` (= real `_G`), `SELF/CALL` preserve methods, `VARARG` preserves `...`, `__iter` shim for generic-for |

## 4. Our VM opcode design (49 ops, comments inline in `runtime/vm.luau` / `src/compiler.py`)

Real ids (scrambled per build at encode time; loader inverts):

`0 NOP, 1 MOVE, 2 LOADK, 3 LOADNIL, 4 LOADBOOL, 5 ADD, 6 SUB, 7 MUL, 8 DIV, 9 MOD, 10 POW, 11 IDIV, 12 BAND, 13 BOR, 14 BXOR, 15 SHL, 16 SHR, 17 BNOT, 18 UNM, 19 NOT, 20 LEN, 21 CONCAT, 22 EQ, 23 LT, 24 LE, 25 TEST, 26 JMP, 27 CALL, 28 RETURN, 29 TAILCALL, 30 VARARG, 31 CLOSURE, 32 GETUPVAL, 33 SETUPVAL, 34 CAPTURE, 35 CAPNIL, 36 GETGLOBAL, 37 SETGLOBAL, 38 GETTABLE, 39 SETTABLE, 40 SELF, 41 NEWTABLE, 42 SETLIST, 43 FORPREP, 44 FORLOOP, 45 TFORPREP, 46 TFORCALL, 47 TFORLOOP, 48 CLOSE`

Choices: register VM (temporaries in `R`, named locals in boxes `BX/UX`) because it maps 1:1 to Luau semantics (multret `CALL/RETURN`, `SELF` for methods, `FORLOOP/TFORLOOP` exact float semantics, `CLOSE` no-op by construction since boxes persist). Jumps use zigzag `Bo` relative to next-pc so insertion passes stay correct. `TEST/EQ/LT/LE` skip-next-instruction convention matches Lua. `CAPTURE/CAPNIL` + `uvdescs (kind,idx)` give O(depth) aliasing without a capture pre-pass. `GETGLOBAL/SETGLOBAL` carry const-table string indices so user globals never appear literally.

## 5. v3 hardening pass (2026-10-12, all P0–P3 items addressed)

Audit findings against the v2 output (`example_obfuscated.lua` at the time:
plaintext `LVM2\0enc|perm|const|junk|magic` markers, stock SHA256 constants
`6a09e667…/428a2f98…` with textbook `rotr/xor` schedule, seed split from
segment lengths/first-bytes, hex-vs-decimal selection by one key byte,
reversible xorshift interleave/stream, 80-wire Fisher–Yates with a static
`DOUBLE` set, linear operand unmasking, `kw xor nw xor 2654435769` const
crypt with plaintext LEB128 + type tags, 1:1 VM handlers with `bad chunk /
bad opcode` labels, side-effect-free junk on scratch regs only, one clear
interpreter function to instrument) were all fixed:

- P0: no `LVM2`/stock-hash/error literals in output (runtime-built
  separators/messages); per-build ARX hash (random rots 56–80 rounds,
  random IVs, K in 2–4 shuffled chunks); salted KDF
  (`user_key=H(priv_salt+env)`, `seedmat=H(user_key+build_salt+seed4)`,
  `k_*=H(seedmat+sep)`, `--bind-env` for JobId binding); per-proto /
  per-instruction / per-chunk chained keys with `nil`+`collectgarbage`
  clearing; encrypt-then-MAC with wipe-on-tamper (fail closed).
- P1: 54 real ops (49 + 5 superoperators, 2–5 enabled per build:
  `LCONCAT_KK/RK/KR`, `TLOOP`, `TJMP` with jump-remapped fusion);
  68–90 wire ids (10–20 alias doubles + dead); bitstream (7b wire,
  10–14b fields + 32b escape, 0–2 keyed pad bits, overlapping low-byte
  fields, no LEB128); per-instruction bias `H(k_perm+q+i)` + prev chaining;
  threaded dispatch over 4 handler groups via per-build opaque ids with
  shuffled spec/handler order, 8–32 fault decoys + 255 fault, and a
  flattened `trans[state]+opaque+key` state; consts split 2–5, shuffled,
  per-chunk chained keys, encrypted tags, on-demand `__kget` (no string
  memoization), fake consts referenced by dead blocks.
- P2: live junk saves/touches/restores real registers with identity ops;
  alias/same-const/`x-x==0` opaque predicates (no `MOVE r,r; EQ r,r`
  template); shared rejoin targets; crash-safe junk protos + forwarding
  wrappers capturing real upvalues called from opaque branches; no NOPs on
  live paths (or in span code at all).
- P3: runtime behavior self-check of the hash (mismatch silently corrupts
  the key); char-arithmetic strings; clock-quantum key drift against slow
  debuggers; split dispatch (4 groups + fetch/run/mkclosure, all renamed
  per build).
- Two load-bearing bugs found by the new tests and fixed: wire-budget
  overflow (`54+n_alias > wire_n` crashed `many_locals`) and stale-JMP
  after 2-wide superop fusion (wrong `counter`; stale `TFORLOOP`).

Deliberately partial (documented, not silent): separators are random per
build rather than `sha(vm_source_slice)` (avoids a build/runtime circular
dependency with identical anti-fingerprint properties); `iv` feeds magic +
stream rekey rather than the seed material (same reason); time trap is
coarse anti-slow-debugger only (a fast static emulator still sees quantum
0 — full timing binding would break deterministic loads); `GETK` is an
on-demand helper, not a distinct opcode; dispatch-state update uses
addition rather than xor. Follow-ups: wider superoperator catalog,
byte-exact `vm_source_slice` separators, strict timing binding.

Acceptance (`tests/acceptance_test.py`): fingerprint 0 hits, naive-DCE
retention 91% (requirement >70%), 1-char tamper fails closed with no
partial output, cross-seed byte diff ~78% with dispatch-order diff
(requirements >40% + order/opcode diff), user strings never literal and
`example.lua` runs `Hello… / counter=85 / 5+7=12`. Roundtrips: 75/75 green
(25 cases × 3 presets).

## 6. v3.1 lean/performance pass (2026-10-13, verified 75/75 + 5/5 green)

Goal: less bloat, faster executor load+execute. Measured on `example.lua`
(583 B, seed 99): `luraph15` 143,987 → 50,658 chars (2.8× smaller, 247× →
87× growth); many-locals (2,794 B) 150× → 28×. Lupa load+execute
27.8 s → 0.30 s (~93×; ~32× per byte + 2.8× fewer bytes).

Size cuts:
- Hash rounds 56–80 → 32–48 (K-table ~40% smaller); K chunks 2–4 → 2–3.
- Bitstream widths 10–14 → 8–10 bit (32-bit escape covers large operands).
- Single hex segment always (was keyed 2–4-way byte interleave + mixed
  dec/hex); loader `__joinsegs` is a straight decode, `__dec3` removed.
- Junk: 1 small junk proto on root only (was 1–2 per real proto +
  wrappers, plus `insert_wrapper_refs`); span densities 14+12 → 4+3 with
  2–5-instr live/dead windows (was 6–15 / 4–12); junk protos 6–11 instrs.
- Consts ≤8 B unsplit, larger split 2–3 ways (was 2–5); lines table 4 B →
  2 B per instr; dropped `__NDECOY/__DISPM/__DISPA/__DISPX/__FLATKEY/
  __TRANS/__encmap` params with the old dispatcher.
- `cli.py` writes LF-canonical (`newline="\n"`) so same-seed files are
  byte-identical across OSes (Windows text mode previously added ~1 KB
  CRLF to the example artifact).

Speedups (executor load + run):
- Per-instruction `__bias3`/`__padlen` ARX hashes (2/instr) → 4-step
  `__xsstep` chain seeded from the existing per-proto `fsd` (byte-exact
  mirror in `ser_proto_v3`/`__parseproto`); per-proto/per-chunk hashes kept.
- Bit reader: per-bit `sbyte+pow+divide` loop → windowed multi-bit
  `__brget` (one divide per field, ~8× fewer `sbyte` calls).
- Threaded 4-group dispatcher (opaque ids + TRANS state + fallback scan +
  fault decoys, ~10 ops/instr + `__fetch_fn` call) → direct
  `__dispatch[op]` table + inlined fetch (shuffled spec kept for diversity).
- `__kget` memoizes strings as well as numbers (registers already hold
  plaintext, so no new exposure); hot loops over string consts avoid a
  multi-hash decrypt per iteration.

Security posture retained: per-build ARX hash/KDF/stream/MAC, wire
permutation + aliases + overlap/chaining, split-shuffled consts, superop
fusion, live-register-touching spans, encrypt-then-MAC fail-closed tamper,
no stock literals. Acceptance after the pass: fingerprint 0 hits, liveness
88.8% (>70%), tamper fail-closed, diversity 70.4% + spec-order diff
(>40%), secrecy + functional green.
