local function __hashfn(__msg)
    local __ml = #__msg
    local __hi = __mathfloor(__ml / 536870912)
    local __lo = (__ml * 8) % 4294967296
    local __padlen = (56 - ((__ml + 1) % 64)) % 64
    local __parts = {__msg, __schar(128)}
    for __i = 1, __padlen do __parts[#__parts + 1] = __schar(0) end
    __parts[#__parts + 1] = __schar(__mathfloor(__hi / 16777216) % 256, __mathfloor(__hi / 65536) % 256, __mathfloor(__hi / 256) % 256, __hi % 256, __mathfloor(__lo / 16777216) % 256, __mathfloor(__lo / 65536) % 256, __mathfloor(__lo / 256) % 256, __lo % 256)
    local __data = __tconcat(__parts)
    local __r0, __r1, __r2, __r3, __r4, __r5 = __H_R[1], __H_R[2], __H_R[3], __H_R[4], __H_R[5], __H_R[6]
    local __nr = __H_N
    local __r45 = (__r4 + __r5) % 32
    if __r45 == 0 then __r45 = 1 end
    local __h1, __h2, __h3, __h4, __h5, __h6, __h7, __h8 = __H_H[1], __H_H[2], __H_H[3], __H_H[4], __H_H[5], __H_H[6], __H_H[7], __H_H[8]
    local __w = {}
    for __off = 1, #__data, 64 do
        for __i = 0, 15 do
            local __b1, __b2, __b3, __b4 = __sbyte(__data, __off + __i * 4, __off + __i * 4 + 3)
            __w[__i + 1] = (__b1 * 16777216 + __b2 * 65536 + __b3 * 256 + __b4) % 4294967296
        end
        for __i = 17, __nr do
            if __i > 64 then __w[__i] = 0
            else
            local __x = __w[__i - 15] or 0
            local __s0 = __bxor(__bxor(__rotr(__x, __r0), __rotr(__x, __r1)), __shr(__x, 3))
            local __y = __w[__i - 2] or 0
            local __s1 = __bxor(__bxor(__rotr(__y, __r2), __rotr(__y, __r3)), __shr(__y, 10))
            __w[__i] = (__w[__i - 16] + __s0 + __w[__i - 7] + __s1) % 4294967296
            end
        end
        local __a, __b, __c, __d, __e, __f, __g, __hh = __h1, __h2, __h3, __h4, __h5, __h6, __h7, __h8
        for __i = 1, __nr do
            local __S1 = __bxor(__bxor(__rotr(__e, __r4), __rotr(__e, __r5)), __rotr(__e, __r45))
            local __ch = __bxor(__band(__e, __f), __band(__bnot(__e), __g))
            local __t1 = (__hh + __S1 + __ch + __H_K[((__i - 1) % __nr) + 1] + (__w[__i] or 0)) % 4294967296
            local __S0 = __bxor(__bxor(__rotr(__a, __r0), __rotr(__a, __r1)), __rotr(__a, __r2))
            local __mj = __bxor(__bxor(__band(__a, __b), __band(__a, __c)), __band(__b, __c))
            local __t2 = (__S0 + __mj) % 4294967296
            __hh = __g
            __g = __f
            __f = __e
            __e = (__d + __t1) % 4294967296
            __d = __c
            __c = __b
            __b = __a
            __a = (__t1 + __t2) % 4294967296
        end
        __h1 = (__h1 + __a) % 4294967296
        __h2 = (__h2 + __b) % 4294967296
        __h3 = (__h3 + __c) % 4294967296
        __h4 = (__h4 + __d) % 4294967296
        __h5 = (__h5 + __e) % 4294967296
        __h6 = (__h6 + __f) % 4294967296
        __h7 = (__h7 + __g) % 4294967296
        __h8 = (__h8 + __hh) % 4294967296
    end
    local __o = {}
    for _, __v in ipairs({__h1, __h2, __h3, __h4, __h5, __h6, __h7, __h8}) do
        __o[#__o + 1] = __schar(__mathfloor(__v / 16777216) % 256, __mathfloor(__v / 65536) % 256, __mathfloor(__v / 256) % 256, __v % 256)
    end
    return __tconcat(__o)
end
local function __hmacfn(__k, __msg)
    if #__k > 64 then __k = __hashfn(__k) end
    local __ip, __op = {}, {}
    for __i = 1, 64 do
        local __b = __sbyte(__k, __i) or 0
        __ip[__i] = __schar(__bxor(__b, 54))
        __op[__i] = __schar(__bxor(__b, 92))
    end
    return __hashfn(__tconcat(__op) .. __hashfn(__tconcat(__ip) .. __msg))
end
