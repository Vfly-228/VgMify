"""Mutator: identifier renaming, dead-code injection, number-to-expression,
seed-splitting and load-bearing decoy helpers used by the emitter.
All transforms are AST/bytecode-aware, never regex-based.
"""
import random

M32 = 4294967296


def lii_name(rng: random.Random, length=12, used=None) -> str:
    alphabet = "lI"
    while True:
        s = "l" + "".join(rng.choice(alphabet) for _ in range(length - 1))
        if used is None or s not in used:
            if used is not None:
                used.add(s)
            return s


def number_expr(rng: random.Random, v: int) -> str:
    """Encode unsigned 32-bit int as an expression: (0x3F*2)+1 style."""
    v = v & 0xFFFFFFFF
    style = rng.randrange(0, 4)
    if style == 0:
        p1 = rng.randrange(0, 2 ** 32)
        p2 = (v - p1) & 0xFFFFFFFF
        return f"(({p1}+{p2})%4294967296)"
    if style == 1:
        b = rng.randrange(2, 10000)
        q = rng.randrange(2, 100000)
        r = (v - (b * q & 0xFFFFFFFF)) & 0xFFFFFFFF
        return f"(({b}*{q}+{r})%4294967296)"
    if style == 2:
        return f"(0x{v:X})"
    half = v // 2
    rem = v - half * 2
    return f"((0x{half:X}*2)+{rem})"


def junk_string(rng: random.Random, ln: int) -> str:
    CH = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_!?.,;: "
    return "".join(rng.choice(CH) for _ in range(ln))


def _tot_expr(sg: str, nseg: int) -> str:
    return "(" + "+".join(f"#{sg}[{i}]" for i in range(1, nseg + 1)) + ")"


def _fb_expr(sg: str, sbyte: str, nseg: int) -> str:
    return "((" + "+".join(f"{sbyte}({sg}[{i}],1)" for i in range(1, nseg + 1)) + ")%256)"


def seed_block(rng: random.Random, nm: dict, seg_strs: list, seed: int, used=None):
    """Split the seed across runtime-derived parts. Returns (code, seedname).

    tot/first-byte sums are permutation-invariant, so this stays correct
    regardless of segment emission order. Never emits `local __SEED=(...)`.
    """
    seed &= 0xFFFFFFFF
    sg = nm["SG"]
    sbyte = nm["sbyte"]
    nseg = len(seg_strs)
    tot = sum(len(s) for s in seg_strs)
    fb = sum(ord(s[0]) for s in seg_strs) % 256
    tot_expr = _tot_expr(sg, nseg)
    fb_expr = _fb_expr(sg, sbyte, nseg)
    ln_tot = lii_name(rng, 10, used)
    ln_fb = lii_name(rng, 10, used)
    la = lii_name(rng, 10, used)
    lb = lii_name(rng, 10, used)
    lc = lii_name(rng, 10, used)
    seedname = lii_name(rng, 12, used)
    p1 = rng.randrange(0, 2 ** 32)
    p2 = rng.randrange(0, 2 ** 32)
    p3 = (seed - p1 - p2) & 0xFFFFFFFF
    x1 = rng.randrange(1, 100000) | 1
    y1 = (p1 - (tot * x1 & 0xFFFFFFFF)) & 0xFFFFFFFF
    x2 = rng.randrange(1, 100000) | 1
    y2 = (p2 - (fb * x2 & 0xFFFFFFFF)) & 0xFFFFFFFF
    p3e = number_expr(rng, p3)
    code = (
        f"local {ln_tot}={tot_expr}\n"
        f"local {ln_fb}={fb_expr}\n"
        f"local {la}=(({ln_tot}*{x1}+{y1})%4294967296)\n"
        f"local {lb}=(({ln_fb}*{x2}+{y2})%4294967296)\n"
        f"local {lc}=({p3e}+(({ln_tot})-({ln_tot})))\n"
        f"local {seedname}=(({la}+{lb}+{lc})%4294967296)\n"
    )
    return code, seedname


def decoy_block_v2(rng: random.Random, nm: dict, seg_strs: list, tag: str, used=None):
    """Load-bearing decoy: value mixes literals with the runtime segment-length
    total; the taken branch (25%) holds only harmless locals, so the branch is
    real but behavior-preserving. Returns (code, rname, value).

    The value feeds the segment-order bit, so deleting the block breaks ~50%
    of builds. Names are per-build random (no fixed __da/__db).
    """
    sg = nm["SG"]
    nseg = len(seg_strs)
    tot = sum(len(s) for s in seg_strs)
    a = rng.randrange(2, 100000)
    b = rng.randrange(2, 100000)
    c = rng.randrange(0, 1000000)
    m = rng.randrange(100003, 200000)
    v = (a * b + c + tot) % m
    taken = rng.randrange(0, 4) == 0
    if taken:
        k = v
    else:
        k = (v + 1 + rng.randrange(0, m - 1)) % m
    r = lii_name(rng, 11, used) + tag
    e = lii_name(rng, 9, used)
    tot_expr = _tot_expr(sg, nseg)
    body = ""
    for _ in range(rng.randrange(1, 4)):
        ln = lii_name(rng, 8, used)
        js = junk_string(rng, rng.randrange(8, 30))
        jn = rng.randrange(0, 2 ** 32)
        body += f"local {ln}=\"{js}\"\n{ln}={ln}..\"{jn % 97}\"\n"
    code = (
        f"local {r}=(({a}*{b}+{c}+{tot_expr})%{m})\n"
        f"if {r}=={k} then\n{body}end\n"
    )
    return code, r, v


def rev_block(rng: random.Random, nm: dict, nseg: int, ra: str, rb: str,
              fb_sum: int, rva: int, rvb: int, used=None):
    """Segment-order bit derived from both decoy values + first-byte sum.
    Python pre-reverses emission iff rev==1; the loader swaps back iff the
    same expression is 1. Returns (code, rev)."""
    c2 = rng.randrange(0, 1000)
    rev = (rva + rvb + fb_sum + c2) % 2
    sg = nm["SG"]
    sbyte = nm["sbyte"]
    rv = lii_name(rng, 11, used)
    fb_expr = _fb_expr(sg, sbyte, nseg)
    swaps = ""
    for i in range(1, nseg // 2 + 1):
        j = nseg + 1 - i
        swaps += f"{sg}[{i}],{sg}[{j}]={sg}[{j}],{sg}[{i}]\n"
    code = (
        f"local {rv}=(({ra}+{rb}+{fb_expr}+{c2})%2)\n"
        f"if {rv}==1 then\n{swaps}end\n"
    )
    return code, rev


def junk_funcs(rng: random.Random, count: int, used=None) -> str:
    s = ""
    for i in range(count):
        nm = f"__junk{rng.randrange(1000, 999999)}"
        pa = lii_name(rng, 8, used)
        pb = lii_name(rng, 8, used)
        tt = lii_name(rng, 8, used)
        n = rng.randrange(2, 6)
        s += f"local function {nm}({pa},{pb})\nlocal {tt}={{}}\n"
        for _ in range(n):
            js = junk_string(rng, rng.randrange(4, 20))
            jn = rng.randrange(0, 2 ** 32)
            pick = rng.randrange(0, 5)
            if pick == 0:
                s += f"{tt}[#{tt}+1]={jn % 1000} .. \"{js}\"\n"
            elif pick == 1:
                _lv = lii_name(rng, 8, used)
                s += (f"for {_lv}=1,{rng.randrange(2,9)} do {tt}[{_lv}]=({_lv}*{rng.randrange(2,50)}+{rng.randrange(0,50)})%{rng.randrange(100,9999)} end\n")
            elif pick == 2:
                s += f"if {pa}==\"{js}\" then {tt}[1]={jn % 777} end\n"
            elif pick == 3:
                s += (f"while {pb}~={jn % 100} do {pb}={pb}+1 if {pb}>{(jn % 100) + rng.randrange(1,50)} then break end end\n")
            else:
                s += f"{tt}.__k{jn % 10000}=\"{js}\"\n"
        s += f"return {tt} end\nlocal {lii_name(rng,8,used)}=0\n"
    return s


def v3_params_block(rng: random.Random, nm: dict, params: dict, encmap: list,
                    nseg: int, used=None) -> str:
    """Generate __PARAMS__ block: salts/seps/keys/widths/wire/disp/bad.

    No payload-length-derived key material. Seed split into 3 random
    shares; salts/seps random per build, built via schar arithmetic.
    """
    from . import hardhash as HH
    seed32 = params["seed64"] & 0xFFFFFFFF
    p1 = rng.randrange(0, 2 ** 32)
    p2 = rng.randrange(0, 2 ** 32)
    p3 = (seed32 - p1 - p2) & 0xFFFFFFFF
    seedname = lii_name(rng, 12, used)

    def schar_bytes(bs: bytes) -> str:
        parts = []
        for b in bs:
            parts.append(HH.obf_byte(rng, b))
        return f"{nm['schar']}({','.join(parts)})"

    L = []
    L.append(f"local {seedname}=(({number_expr(rng, p1)}+{number_expr(rng, p2)}+{number_expr(rng, p3)})%4294967296)")
    # salts + seps (runtime-built, never literals)
    L.append(f"local __BSALT={schar_bytes(params['build_salt'])}")
    L.append(f"local __PSALT={schar_bytes(params['priv_salt'])}")
    for k in ("enc", "perm", "const", "junk", "magic"):
        L.append(f"local __SEP_{k.upper()}={schar_bytes(params['seps'][k])}")
    # env binding: runtime JobId or fallback (fallback also schar-built)
    L.append("local __jid=" + schar_bytes(b"local-test"))
    L.append("do local __ok,__g=pcall(function() return rawget(" + nm["G"] + ",\"game\") end)")
    L.append("if __ok and __g ~= nil then local __ok2,__j=pcall(function() return __g.JobId end)")
    L.append("if __ok2 and __j ~= nil then __jid=__tostring(__j) end end end")
    # key derivation (mirrors v3core.build_params without iv in seedmat)
    L.append(f"local __sdb0={seedname}%256")
    L.append(f"local __sdb1={nm['mathfloor']}({seedname}/256)%256")
    L.append(f"local __sdb2={nm['mathfloor']}({seedname}/65536)%256")
    L.append(f"local __sdb3={nm['mathfloor']}({seedname}/16777216)%256")
    L.append(f"local __seed4={nm['schar']}(__sdb0,__sdb1,__sdb2,__sdb3)")
    L.append("local __ukey=" + nm["hashfn"] + "(__PSALT..__jid)")
    L.append("local __seedmat=" + nm["hashfn"] + "(__ukey..__BSALT..__seed4)")
    L.append("local __kenc=" + nm["hashfn"] + "(__seedmat..__SEP_ENC)")
    L.append("local __kprm=" + nm["hashfn"] + "(__seedmat..__SEP_PERM)")
    L.append("local __kcon=" + nm["hashfn"] + "(__seedmat..__SEP_CONST)")
    L.append("local __kjn=" + nm["hashfn"] + "(__seedmat..__SEP_JUNK)")
    L.append("local __sep_magic=__SEP_MAGIC")
    # widths / wire (direct dispatch: no DISPM/A/X, FLATKEY, TRANS,
    # NDECOY, encmap — those belonged to the threaded 4-group dispatcher
    # removed for size/speed; wire permutation + shuffled spec remain).
    L.append(f"local __WA={params['wa']}")
    L.append(f"local __WB={params['wb']}")
    L.append(f"local __WC={params['wc']}")
    L.append(f"local __M1={params['m1']}")
    L.append(f"local __M2={params['m2']}")
    L.append(f"local __OPBITS={params['op_bits']}")
    L.append(f"local __WN={params['wire_n']}")
    L.append(f"local __NREAL={54}")
    L.append(f"local __TQUANT={params['t_quant']}")
    # alias counts: real -> 1|2
    al = ",".join("2" if op in params["alias_ops"] else "1" for op in range(54))
    L.append(f"local __alcnt={{{al}}}")
    # generic integrity message (runtime-built, never a literal)
    bad = "__badmsg"
    L.append(f"local {bad}=" + schar_bytes("unexpected symbol".encode()[:12]))
    L.append("local __bad=" + bad)
    code = "\n".join(L) + "\n"
    # rename map for loader references
    ren = {
        "BSALT": "__BSALT", "PSALT": "__PSALT",
        "kenc": "__kenc", "kprm": "__kprm", "kcon": "__kcon", "kjn": "__kjn",
        "seedmat": "__seedmat", "sep_magic": "__sep_magic",
        "WA": "__WA", "WB": "__WB", "WC": "__WC", "M1": "__M1", "M2": "__M2",
        "OPBITS": "__OPBITS", "WN": "__WN", "NREAL": "__NREAL",
        "TQUANT": "__TQUANT",
        "alcnt": "__alcnt",
        "bad": "__bad",
    }
    return code, ren
