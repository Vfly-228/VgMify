#!/usr/bin/env node
// cli.js — Node shim for the Python VM obfuscator.
// The canonical implementation is Python (see cli.py + src/*.py), chosen per
// the spec's "Node.js + TypeScript OR Python, your choice".
// This shim forwards `obfuscate --input ... --output ... --preset ... --seed ...`
// to cli.py so Node users get the same interface.
const { spawnSync } = require("child_process");
const path = require("path");

const py = process.env.PYTHON || (process.platform === "win32" ? "python" : "python3");
const cliPy = path.join(__dirname, "..", "cli.py");
const args = process.argv.slice(2);
const r = spawnSync(py, [cliPy, ...args], { stdio: "inherit" });
process.exit(r.status === null ? 1 : r.status);
