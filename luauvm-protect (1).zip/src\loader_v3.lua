local __SG = { __SEGMENTS__ }

__PARAMS__

local function __decH(s)
    local out = {}
    local oi = 0
    for j = 1, #s, 2 do
        local a, b = __sbyte(s, j, j + 1)
        if a >= 97 then a = a - 87 elseif a >= 65 then a = a - 55 else a = a - 48 end
        if b >= 97 then b = b - 87 elseif b >= 65 then b = b - 55 else b = b - 48 end
        oi = oi + 1
        out[oi] = __schar(a * 16 + b)
    end
    return __tconcat(out)
end

local function __joinsegs(sg, ke, kj)
    -- Lean: single hex segment (no dec3, no encmap, no per-byte interleave).
    if #sg == 1 then return __decH(sg[1]) end
    local nseg = #sg
    local parts = {}
    for i = 1, nseg do parts[i] = __decH(sg[i]) end
    local total = 0
    for i = 1, nseg do total = total + #parts[i] end
    local j0, j1, j2, j3 = __sbyte(kj, 1, 4)
    local st = (j0 + j1 * 256 + j2 * 65536 + j3 * 16777216) % 4294967296
    if st == 0 then st = 2654435769 end
    local idx = {}
    for i = 1, nseg do idx[i] = 1 end
    local chunks = {}
    local ci = 0
    for pos = 0, total - 1 do
        local gi
        if pos < nseg then gi = (pos % nseg) + 1
        else
            st = __xsstep(st)
            gi = (st % nseg) + 1
        end
        ci = ci + 1
        chunks[ci] = __ssub(parts[gi], idx[gi], idx[gi])
        idx[gi] = idx[gi] + 1
    end
    return __tconcat(chunks)
end

local __t0 = (__clock and __clock()) or 0
local function __tquant()
    if not __clock then return 0 end
    local ok, c = pcall(__clock)
    if not ok or type(c) ~= "number" then return 0 end
    local d = c - __t0
    if d < 0 then d = 0 end
    local q = __mathfloor(d / __TQUANT)
    if q > 7 then q = 7 end
    return q
end

local function __xsdec(d, ke, iv)
    local n = #d
    local out = {}
    local oi = 0
    local pos = 1
    local chunk = 0
    local prev = 0
    local quant = __tquant()
    while pos <= n do
        local c0 = chunk % 256
        local c1 = __mathfloor(chunk / 256) % 256
        local c2 = __mathfloor(chunk / 65536) % 256
        local c3 = __mathfloor(chunk / 16777216) % 256
        local rk = __hashfn(ke .. iv .. __schar(c0, c1, c2, c3) .. __schar(quant))
        local r0, r1, r2, r3 = __sbyte(rk, 1, 4)
        local st = (r0 + r1 * 256 + r2 * 65536 + r3 * 16777216) % 4294967296
        if st == 0 then st = 2654435769 end
        local stop = pos + 255
        if stop > n then stop = n end
        while pos <= stop do
            st = __xsstep(st)
            local wv = st
            for k = 1, 4 do
                if pos > stop then break end
                oi = oi + 1
                local cb = __sbyte(d, pos)
                local pt = __bxor(__bxor(cb, wv % 256), prev % 256)
                out[oi] = __schar(pt)
                prev = pt
                wv = __mathfloor(wv / 256)
                pos = pos + 1
            end
        end
        chunk = chunk + 1
    end
    return __tconcat(out)
end

local function __brget(br, n)
    -- Windowed bit reader: buffers whole bytes and slices multi-bit
    -- fields with one divide per field (was one sbyte+pow+divide per
    -- BIT). Same MSB-first order as the writer; byte-exact equivalent.
    while br.bits < n do
        local b = __sbyte(br.s, br.pos) or 0
        br.pos = br.pos + 1
        br.buf = br.buf * 256 + b
        br.bits = br.bits + 8
    end
    local shift = br.bits - n
    local p = 2 ^ shift
    local v = __mathfloor(br.buf / p)
    br.buf = br.buf - v * p
    br.bits = shift
    return v
end
local function __bresc(br, w)
    local v = __brget(br, w)
    if v == (2 ^ w) - 1 then
        v = __brget(br, 32) % 4294967296
    end
    return v
end

local function __pfy(sd, wn)
    local p = {}
    for i = 1, wn do p[i] = i - 1 end
    local st = sd % 4294967296
    if st == 0 then st = 2654435769 end
    local i = wn
    while i > 1 do
        st = __xsstep(st)
        local j = st % i
        p[i], p[j + 1] = p[j + 1], p[i]
        i = i - 1
    end
    return p
end

__WIREMAP__

local function __kget(e, kc)
    -- Memoized for both numbers and strings (was numbers-only).
    -- Registers already hold plaintext after the first LOADK, so caching
    -- adds no new exposure; it avoids a multi-hash decrypt per use,
    -- which dominated hot loops over string consts.
    if e.v ~= nil then return e.v end
    local d = e[2]
    local pos = 1
    local nch = __sbyte(d, pos)
    pos = pos + 1
    local chunks = {}
    local prevh = kc
    for c = 1, nch do
        local w0, w1, w2, w3 = __sbyte(d, pos, pos + 3)
        pos = pos + 4
        local cidx = __sbyte(d, pos)
        pos = pos + 1
        local ln = __sbyte(d, pos)
        pos = pos + 1
        local kh = __hashfn(kc .. __schar(w0, w1, w2, w3) .. __schar(cidx) .. prevh)
        local h0, h1, h2, h3 = __sbyte(kh, 1, 4)
        local st = (h0 + h1 * 256 + h2 * 65536 + h3 * 16777216) % 4294967296
        if st == 0 then st = 2654435769 end
        local part = {}
        local pi = 0
        local got = 0
        while got < ln do
            st = __xsstep(st)
            local wv = st
            for k = 1, 4 do
                if got >= ln then break end
                pi = pi + 1
                part[pi] = __schar(__bxor(__sbyte(d, pos), wv % 256))
                wv = __mathfloor(wv / 256)
                pos = pos + 1
                got = got + 1
            end
        end
        chunks[cidx + 1] = __tconcat(part)
        prevh = __hashfn(prevh .. chunks[cidx + 1])
    end
    local s = __tconcat(chunks)
    if e[1] == 3 then
        local v = __tonumber(s)
        e.v = v
        return v
    end
    e.v = s
    return s
end

__PROTOPARSE__

__DISPATCH__

__SELFCHECK__
local __raw = __joinsegs(__SG, __kenc, __kjn)
local __iv = __ssub(__raw, 1, 16)
local __encd = __ssub(__raw, 17, -1)
local __body = __xsdec(__encd, __kenc, __iv)
local __mg = __hashfn(__seedmat .. __sep_magic .. __iv)
if __ssub(__body, 1, 4) ~= __ssub(__mg, 1, 4) then
    __raw = nil
    __encd = nil
    __body = nil
    __mg = nil
    pcall(collectgarbage, "collect")
    __error(__bad)
end
if __sbyte(__body, 5) ~= 2 then
    __raw = nil
    __encd = nil
    __body = nil
    pcall(collectgarbage, "collect")
    __error(__bad)
end
local __LV = __bxor(__sbyte(__body, 6), __band(__sbyte(__kenc, 17), 3))
if __LV > 3 then
    __raw = nil
    __body = nil
    pcall(collectgarbage, "collect")
    __error(__bad)
end
local __bl = #__body
local __macA = __ssub(__body, __bl - 31, __bl)
local __core = __ssub(__body, 1, __bl - 32)
if __hmacfn(__kenc, __core) ~= __macA then
    __raw = nil
    __encd = nil
    __body = nil
    __core = nil
    __macA = nil
    pcall(collectgarbage, "collect")
    __error(__bad)
end
local __ctx = { pi = 0, kp = __kprm }
local __root = (__parse_root(__core))
__raw = nil
__encd = nil
__body = nil
__core = nil
__macA = nil
__mg = nil
__kenc = nil
__kprm = nil
__kjn = nil
__seedmat = nil
pcall(collectgarbage, "collect")

local __entry = __mkclosure(__root, {})
local function __main(...) return __entry(...) end
local function __boot(...)
    local __args = __tpack(...)
    local function __go()
        return __main(__tunpack(__args, 1, __args.n))
    end
    local __ok = __tpack(__xpcall(__go, __eh))
    if __ok[1] then
        return __tunpack(__ok, 2, __ok.n)
    else
        __error(__ok[2], 0)
    end
end
return __boot(...)
