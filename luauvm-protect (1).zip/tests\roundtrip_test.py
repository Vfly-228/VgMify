#!/usr/bin/env python3
"""Roundtrip tests: obfuscate Luau src, execute in lupa with executor stub,
compare observable output. Covers 25 cases incl. Roblox Services, RemoteEvents,
metatables, and all required Luau features.

Run: python tests/roundtrip_test.py [--preset light|medium|luraph15]
"""
import pathlib
import sys

sys.path.insert(0, str(pathlib.Path(__file__).parent.parent))
from lupa import LuaRuntime
from src.api import obfuscate

STUB_PATH = pathlib.Path(__file__).parent / "executor_stub.lua"
STUB_EXTRA = r"""
test_out = {}
print = function(...) local t={...}; local s={}; for i=1,select('#',...) do s[i]=tostring(select(i,...)) end; test_out[#test_out+1]=table.concat(s, '\t') end
"""

def run_case(src, seed=0xC0FFEE, preset="medium"):
    stub = STUB_PATH.read_text(encoding="utf-8") + STUB_EXTRA
    ob = obfuscate(src, seed=seed, preset=preset)
    lua = LuaRuntime()
    lua.execute(stub)
    lua.execute(ob)
    n = lua.eval("#test_out")
    return [lua.eval(f"test_out[{i}]") for i in range(1, n + 1)], len(ob), len(src)

CASES = [
    # (name, src, expected)
    ("print_hi", 'print("hi")', ["hi"]),
    ("arith", "local x = 1+2*3 print(x)", ["7"]),
    ("compound", "local x=10 x+=5 x-=2 x*=3 x/=2 print(x)", ["19.5"]),
    ("types_stripped", "local x:number = 41 local y:string = 'a' print(x+1)", ["42"]),
    ("export_type", "export type Foo = { x: number } local v:Foo = { x = 1 } print(v.x)", ["1"]),
    ("continue", "local s=0 for i=1,5 do if i==3 then continue end s=s+i end print(s)", ["12"]),
    ("if_expr", "local x = if 1>2 then 10 else 20 print(x)", ["20"]),
    ("interp", "local n=42 local s=`val={n}!` print(s)", ["val=42!"]),
    ("varargs", "local function s(...) local t={...} local n=0 for i=1,#t do n=n+t[i] end return n end print(s(1,2,3,4))", ["10"]),
    ("many_locals", " ".join(f"local v{i}={i}" for i in range(200)) + " print(v0+v199)", ["199"]),
    ("nested_closures", "local a=1 local function f() local b=2 local function g() return function() return a+b end end return g()() end print(f())", ["3"]),
    ("upvalues_mutate", "local c=0 local function inc() c=c+1 return c end inc() inc() inc() print(c)", ["3"]),
    ("services", "local p = game:GetService('Players').LocalPlayer print(p.Name)", ["TestPlayer"]),
    ("remote_event", "local re = Instance.new('RemoteEvent') re:FireServer(1, 'two') print(#re._fired, re._fired[1][2])", ["1\ttwo"]),
    ("metatable_add", "local t=setmetatable({},{__add=function(a,b) return 99 end}) print(t+t)", ["99"]),
    ("metatable_index", "local t=setmetatable({},{__index=function(_,k) return 'idx:'..k end}) print(t.foo)", ["idx:foo"]),
    ("task_wait", "task.wait(0.5) print('waited')", ["waited"]),
    ("getgenv", "getgenv().my_test_val_xyz = 77 print(getgenv().my_test_val_xyz)", ["77"]),
    ("generic_for", "local t={10,20,30} local s=0 for i,v in ipairs(t) do s=s+v end print(s)", ["60"]),
    ("numfor_step", "local s=0 for i=10,1,-3 do s=s+i end print(s)", ["22"]),
    ("while_break", "local i=0 while true do i=i+1 if i>=4 then break end end print(i)", ["4"]),
    ("repeat_until", "local i=0 repeat i=i+1 until i>=5 print(i)", ["5"]),
    ("method_self", "local o={v=7} function o:get() return self.v*2 end print(o:get())", ["14"]),
    ("tailcall", "local function id(x) return x end local function f(x) return id(x+1) end print(f(41))", ["42"]),
    ("complex_roblox",
     "local Players = game:GetService('Players')\n"
     "local lp = Players.LocalPlayer\n"
     "local count = 0\n"
     "local function greet(name:string) return `hello, {name}!` end\n"
     "for i=1,3 do count += i end\n"
     "local re = Instance.new('RemoteEvent')\n"
     "re:FireServer('join', lp.Name)\n"
     "print(greet(lp.Name), count, #re._fired)",
     ["hello, TestPlayer!\t6\t1"]),
]

def main():
    preset = "medium"
    if len(sys.argv) > 2 and sys.argv[1] == "--preset":
        preset = sys.argv[2]
    fails = 0
    for name, src, exp in CASES:
        try:
            got, ob_len, src_len = run_case(src, preset=preset)
            ok = got == exp
            status = "PASS" if ok else "FAIL"
            if not ok:
                fails += 1
            print(f"{status} [{preset}] {name}: got={got} exp={exp} (src={src_len} ob={ob_len} x{ob_len/max(src_len,1):.1f})")
        except Exception as e:
            fails += 1
            print(f"ERROR [{preset}] {name}: {str(e)[:300]}")
    print(f"\n{fails} failures / {len(CASES)} cases (preset={preset})")
    sys.exit(1 if fails else 0)

if __name__ == "__main__":
    main()
