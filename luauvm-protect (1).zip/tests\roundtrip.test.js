// tests/roundtrip.test.js — Node entry point (shim).
// Canonical suite is tests/roundtrip_test.py (Python + lupa). This file lets
// `node --test` / jest-style runners invoke the same suite when Node exists.
const { spawnSync } = require("child_process");
const py = process.env.PYTHON || (process.platform === "win32" ? "python" : "python3");
for (const preset of ["light", "medium", "luraph15"]) {
  const r = spawnSync(py, ["tests/roundtrip_test.py", "--preset", preset], { stdio: "inherit" });
  if (r.status !== 0) process.exit(r.status);
}
