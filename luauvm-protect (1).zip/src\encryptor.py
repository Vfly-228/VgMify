"""Encryptor v3: superoperators + bitstream + chained keys + split consts.

Envelope:
- Per-build ARX hash (src/hardhash) with randomized rots/rounds/IV/K.
  No stock SHA256 literals in output; K split 2-4 shuffled chunks.
- Separators: 6 random bytes per domain per build, built at runtime via
  schar arithmetic. Never the literal LVM2.
- Keys: user_key = H(priv_salt + env) where env = runtime JobId or
  "local-test"; seed_material = H(user_key + build_salt + iv + seed4);
  k_* = H(seed_material + sep_*). Ship salt/iv/seps only (obfuscated);
  never ship user_key. Static dump alone insufficient when bound.
- Stream: per-byte chained (enc = plain ^ ks ^ prev_plain), rekey every
  256B via H(k_enc + iv + chunk + quant). Quant=0 at build; runtime mixes
  os.clock quantum (slow debugger drifts to garbage).
- Opcodes: wire_n 64..96 per build, 16..24 aliased, rest dead. Per-proto
  Fisher-Yates via xorshift on H(k_perm+q). Per-instruction bias from
  H(k_perm+q+i) + arithmetic chaining with prev (instr[i] keyed by
  keystream(i, prev_plaintext)). Overlapping fields (B+=A*m1, C+=B*m2).
- Bitstream: 7b wire + escaped operands (wa/wb/wc 10..14 + 32b escape)
  + 0..2 fake pad bits keyed by stream. No LEB128 beacon.
- Consts: tag byte encrypted (tag + k_con[1]); strings/numbers split
  2..5 chunks (1 if len<2), random sizes, shuffled order with index,
  per-chunk nonce + chained key H(k_con+nonce+idx+prevh). Reassembled
  on demand at use (GETK-style __kget, no string memoization).
  Fake consts appended and referenced by dead blocks.
- Superoperators 49..53 (subset 2..5 enabled per build): LCONCAT_KK,
  LCONCAT_RK, LCONCAT_KR, TLOOP, TJMP. Breaks 1:1 Lua mapping.
"""
import random
from .compiler import Proto, Instr, NOPS_V3, OP
from . import hardhash as HH
from . import v3core as V

VERSION = 2
MASK32 = 0xFFFFFFFF


def derive_all(seed: int, bind_env=None):
    return V.build_params(seed, bind_env)


def unzz(v: int) -> int:
    v &= MASK32
    return ((v >> 1) ^ -(v & 1))


def zz(v: int) -> int:
    return (((v << 1) ^ (v >> 31)) & MASK32)


def jump_target(code, at):
    op = code[at].op
    if op in (26, 53):
        return (at + 1 + unzz(code[at].b))
    if op in (44, 47, 52):
        # FORLOOP/TFORLOOP/TLOOP use B as offset like JMP
        return (at + 1 + unzz(code[at].b))
    return None


def set_jump(code, at, target):
    off = target - (at + 1)
    code[at].b = zz(off) & MASK32


# ---------- superoperator fusion ----------
def _reads(ins):
    op, a, b, c = ins.op, ins.a, ins.b, ins.c
    if op == 1:
        return {b}
    if op in (5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 21):
        return {b, c}
    if op in (17, 18, 19, 20):
        return {b}
    if op in (22, 23, 24):
        return {b, c}
    if op == 25:
        return {a}
    if op == 27 or op == 29:
        r = {a}
        if b == 0:
            r.update(range(a, a + 33))
        else:
            r.update(range(a + 1, a + b))
        return r
    if op == 28:
        if b == 0:
            return set(range(a, a + 33))
        if b == 1:
            return set()
        return set(range(a, a + b - 1))
    if op == 33:
        return {a}
    if op == 34:
        return {a}
    if op == 37:
        return {a}
    if op == 38:
        return {b, c}
    if op == 39:
        return {a, b, c}
    if op == 40:
        return {b, c}
    if op == 43 or op == 44:
        return {a, a + 1, a + 2}
    if op == 45:
        return {a}
    if op == 46 or op == 52:
        return {a, a + 1, a + 2}
    if op == 47:
        return {a + 3}
    if op == 50:
        return {b}
    if op == 51:
        return {c}
    if op == 53:
        return {a}
    return set()


def _writes(ins):
    op, a, b, c = ins.op, ins.a, ins.b, ins.c
    if op in (1, 2, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21):
        return {a}
    if op == 3:
        return set(range(a, a + max(b, 1)))
    if op == 27:
        if c == 1:
            return set()
        if c == 0:
            return set(range(a, a + 33))
        return set(range(a, a + c - 1))
    if op == 30:
        if b == 0:
            return set(range(a, a + 33))
        return set(range(a, a + b - 1))
    if op == 31:
        return {a}
    if op == 32:
        return {a}
    if op == 36:
        return {a}
    if op == 38:
        return {a}
    if op == 40:
        return {a, a + 1}
    if op == 41:
        return {a}
    if op == 43 or op == 44:
        if op == 43:
            return {a}
        return {a, a + 3}
    if op == 45:
        return {a, a + 1, a + 2}
    if op == 46:
        return set(range(a + 3, a + 3 + c))
    if op == 47:
        return {a + 2}
    if op in (49, 50, 51):
        return {a}
    if op == 52:
        s = {a + 2}
        s.update(range(a + 3, a + 3 + max(c, 1)))
        return s
    return set()


def _uses_after(code, start, regs):
    regs = set(regs)
    for i in range(start, len(code)):
        ins = code[i]
        if _reads(ins) & regs:
            return True
        if _writes(ins) & regs:
            return False
    return False


def fuse_superops(p: Proto, enabled: set):
    """Peephole fusion with full jump remap. Returns number fused."""
    nfused = 0
    # repeat until no more (chains like LOADK,LOADK,CONCAT need one pass)
    changed = True
    while changed:
        changed = False
        removals = []  # (at, new_instr)
        i = 0
        code = p.code
        while i < len(code):
            # TLOOP: TFORCALL A,Co + TFORLOOP A,Bo adjacent
            if 52 in enabled and i + 1 < len(code):
                a, b = code[i], code[i + 1]
                if a.op == 46 and b.op == 47 and a.a == b.a:
                    removals.append((i, Instr(52, a.a, b.b, a.c, a.line)))
                    removals.append((i + 1, None))
                    i += 2
                    nfused += 1
                    changed = True
                    continue
            # TJMP: TEST A,0,C + JMP 0,Bo,0 adjacent
            if 53 in enabled and i + 1 < len(code):
                a, b = code[i], code[i + 1]
                if a.op == 25 and b.op == 26 and b.a == 0:
                    removals.append((i, Instr(53, a.a, b.b, a.c, a.line)))
                    removals.append((i + 1, None))
                    i += 2
                    nfused += 1
                    changed = True
                    continue
            # LCONCAT_KK: LOADK t1,k1 + LOADK t2,k2 + CONCAT A,t1,t2
            if 49 in enabled and i + 2 < len(code):
                a, b, c = code[i], code[i + 1], code[i + 2]
                if (a.op == 2 and b.op == 2 and c.op == 21
                        and c.b == a.a and c.c == b.a and a.a != b.a
                        and c.a not in (a.a, b.a)):
                    if not _uses_after(code, i + 3, {a.a, b.a}):
                        removals.append((i, Instr(49, c.a, a.b, b.b, c.line)))
                        # mark consumed
                        removals.append((i + 1, None))
                        removals.append((i + 2, None))
                        i += 3
                        nfused += 1
                        changed = True
                        continue
            # LCONCAT_RK: LOADK t,k + CONCAT A,cur,t
            if 50 in enabled and i + 1 < len(code):
                a, b = code[i], code[i + 1]
                if (a.op == 2 and b.op == 21 and b.c == a.a
                        and b.a != a.a and b.b != a.a):
                    if not _uses_after(code, i + 2, {a.a}):
                        removals.append((i, Instr(50, b.a, b.b, a.b, b.line)))
                        removals.append((i + 1, None))
                        i += 2
                        nfused += 1
                        changed = True
                        continue
            # LCONCAT_KR: LOADK t,k + CONCAT A,t,cur
            if 51 in enabled and i + 1 < len(code):
                a, b = code[i], code[i + 1]
                if (a.op == 2 and b.op == 21 and b.b == a.a
                        and b.a != a.a and b.c != a.a):
                    if not _uses_after(code, i + 2, {a.a}):
                        removals.append((i, Instr(51, b.a, a.b, b.c, b.line)))
                        removals.append((i + 1, None))
                        i += 2
                        nfused += 1
                        changed = True
                        continue
            i += 1
        if removals:
            # apply with jump remap: build new code, map old->new
            by_at = {}
            for (at, ni) in removals:
                by_at.setdefault(at, ni)
            old_targets = [jump_target(p.code, k) for k in range(len(p.code))]
            new_code = []
            old2new = [0] * (len(p.code) + 1)
            skip = set()
            for (at, ni) in removals:
                if ni is None:
                    skip.add(at)
            # first entry per fused group holds new instr; Nones skipped
            fused_head = {}
            for (at, ni) in removals:
                if ni is not None and at not in fused_head:
                    # check if this head corresponds to multi-remove
                    fused_head[at] = ni
            for oi in range(len(p.code)):
                if oi in skip:
                    old2new[oi] = len(new_code)  # point at next (will adjust)
                    continue
                if oi in fused_head:
                    old2new[oi] = len(new_code)
                    new_code.append(fused_head[oi])
                    # extra consumed indices already in skip map to same
                else:
                    old2new[oi] = len(new_code)
                    o = p.code[oi]
                    new_code.append(Instr(o.op, o.a, o.b, o.c, o.line))
            old2new[len(p.code)] = len(new_code)
            # NOTE: consumed (skipped) indices map to the slot after their
            # fused head. Compiler invariant: no jump targets the interior
            # of a fusible pair (pairs are straight-line internals; jump
            # targets are block boundaries), so these mappings are
            # unreachable in practice.
            # remap via old targets
            new2old_head = {}
            # reconstruct mapping new->representative old
            # walk old in order assigning
            ni_ptr = 0
            for oi in range(len(p.code)):
                if oi in skip:
                    continue
                new2old_head[ni_ptr] = oi
                ni_ptr += 1
            for ni_idx in range(len(new_code)):
                oi = new2old_head.get(ni_idx, -1)
                if oi is None or oi < 0:
                    continue
                t = old_targets[oi]
                if t is not None:
                    set_jump(new_code, ni_idx, old2new[min(t, len(old2new) - 1)])
            # also fix fused TJMP/TLOOP offsets already preserved (same value works
            # because removal of exactly 1 instr before target shifts by 1 and
            # fused position shifts by 1 -> offset unchanged, verified above).
            # The generic remap above recomputes correctly anyway.
            p.code = new_code
    for ch in p.children:
        nfused += fuse_superops(ch, enabled)
    return nfused


# ---------- transforms ----------
def apply_transforms(root: Proto, params: dict, level: int, strip_debug: bool):
    hp = params["hp"]
    seed64 = params["seed64"]
    rng = random.Random((seed64 ^ 0x51AB3F77) & MASK32)
    scramble_lines(root, level, strip_debug, rng)
    add_fake_consts(root, rng, 1 if level >= 2 else 0)
    fuse_superops(root, params["super_enabled"])
    if level >= 3:
        # Lean: single junk proto on the root (was 1-2 per real proto +
        # wrappers). Junk protos serialize (consts+code+lines) and cost
        # per-instr hashes at load, so per-proto junk dominated bloat.
        attach_junks(root, params, rng)
    if level >= 2:
        # Lean densities: 4 (was 14). Spans insert ~10-20 live+dead
        # instrs each; 26% density meant ~5x code growth.
        insert_all(root, params, rng, 4)
    if level >= 3:
        insert_all(root, params, rng, 3)
        trampoline_jumps(root, rng, 30)
    sync_lines(root)


def scramble_lines(p: Proto, level, strip_debug, rng):
    if strip_debug:
        for ins in p.code:
            ins.line = 0
    elif level >= 1:
        off = rng.randrange(0, 1000)
        for ins in p.code:
            ins.line = (ins.line + off) & MASK32
    sync_lines(p)
    for ch in p.children:
        scramble_lines(ch, level, strip_debug, rng)
    sync_lines(p)


def sync_lines(p: Proto):
    p.lines = [i.line for i in p.code]
    for ch in p.children:
        sync_lines(ch)


def real_protos(root: Proto):
    out = []

    def walk(p):
        if not p.is_junk:
            out.append(p)
        for ch in p.children:
            walk(ch)

    walk(root)
    return out


def tree_strings(root: Proto):
    strs = []

    def walk(p):
        for c in p.consts:
            if c[0] == "str" and c[1]:
                strs.append(c[1])
        for ch in p.children:
            walk(ch)

    walk(root)
    return strs


def add_fake_consts(root: Proto, rng, per_proto: int):
    """Append fake consts (never referenced by real code; dead blocks
    reference them so const-use analysis keeps junk)."""
    if per_proto <= 0:
        return

    def walk(p):
        if not p.is_junk:
            for _ in range(rng.randrange(1, per_proto + 2)):
                if rng.randrange(0, 2):
                    ln = rng.randrange(3, 14)
                    p.consts.append(("str", bytes(rng.randrange(97, 123) for _ in range(ln))))
                else:
                    p.consts.append(("num", float(rng.randrange(-2000, 2000))))
        for ch in p.children:
            walk(ch)

    walk(root)


def junk_proto_v3(rng, line, pool) -> Proto:
    """Crash-safe junk (only MOVE/LOADK/LOADNIL/LOADBOOL/NOT/TEST/JMP/RETURN).
    Safe to *call*: never indexes nil, never arithmetics on unknown types.
    Lean size: 6..11 instrs (was 10..25)."""
    nregs = rng.randrange(4, 10)
    consts = [("nil",), ("bool", rng.randrange(2) == 1)]
    nstr = rng.randrange(2, 5)
    for _ in range(nstr):
        if pool and rng.randrange(0, 3):
            s = rng.choice(pool)
            if isinstance(s, bytes) and s:
                consts.append(("str", s))
                continue
        ln = rng.randrange(3, 14)
        consts.append(("str", bytes(rng.randrange(97, 123) for _ in range(ln))))
    for _ in range(rng.randrange(1, 3)):
        v = rng.randrange(-2000, 2000)
        consts.append(("num", float(v)))

    def R():
        return rng.randrange(0, nregs)

    def RK():
        return rng.randrange(0, len(consts))

    code = []
    for _ in range(rng.randrange(6, 12)):
        pick = rng.randrange(0, 8)
        if pick == 0:
            code.append(Instr(2, R(), RK(), 0, line))
        elif pick == 1:
            code.append(Instr(3, R(), 1 + rng.randrange(0, 2), 0, line))
        elif pick == 2:
            code.append(Instr(4, R(), rng.randrange(0, 2), 0, line))
        elif pick == 3:
            code.append(Instr(19, R(), R(), 0, line))
        elif pick == 4:
            code.append(Instr(1, R(), R(), 0, line))
        elif pick == 5:
            code.append(Instr(25, R(), 0, rng.randrange(0, 2), line))
        elif pick == 6:
            code.append(Instr(26, 0, 0, 0, line))  # patched below
        else:
            code.append(Instr(2, R(), RK(), 0, line))
    # fix internal jumps to stay inside (or fall through)
    for k in range(len(code)):
        if code[k].op == 26:
            tgt = rng.randrange(k + 1, len(code) + 1)
            set_jump(code, k, min(tgt, len(code)))
    term = rng.randrange(0, 3)
    if term == 0:
        code.append(Instr(28, 0, 1, 0, line))
    elif term == 1:
        code.append(Instr(28, R(), 0, 0, line))
    else:
        code.append(Instr(28, R(), 2, 0, line))
    uv = []
    for _ in range(rng.randrange(0, 2)):
        uv.append((rng.randrange(0, 2), rng.randrange(0, 3)))
    return Proto(nparams=rng.randrange(0, 3), vararg=rng.choice([True, False]),
                 nregs=nregs, nown=0, consts=consts, code=code,
                 children=[], uvdescs=uv, lines=[], is_junk=True)


def wrapper_proto_v3(rng, line, target_idx: int) -> Proto:
    """Fake closure that captures a real box and forwards (identity wrapper).

    Body reads one upvalue (real box), does crash-safe ops, tailcalls the
    captured function with its args. Both direct and wrapped paths compute
    the same visible result via different paths.
    """
    nregs = 4
    consts = [("nil",)]
    code = [
        Instr(32, 0, 0, 1, line),   # GETUPVAL R0 = UX[0] (real fn/box)
        Instr(1, 1, 0, 0, line),    # MOVE R1 = R0 (alias read, live)
        Instr(25, 1, 0, 1, line),   # TEST R1,1 (no skip if truthy; safe read)
        Instr(30, 2, 0, 0, line),   # VARARG R2... (forward ...)
        Instr(29, 0, 0, 0, line),   # TAILCALL R0 (forward)
    ]
    return Proto(nparams=0, vararg=True, nregs=nregs, nown=0, consts=consts,
                 code=code, children=[], uvdescs=[(1, 0)], lines=[], is_junk=True)


def attach_junks(root: Proto, params, rng):
    # Lean: one small junk child on the root only. Still gives the
    # dead-code + const-pool-mixing properties without O(protos) bloat.
    pool = tree_strings(root)
    root.children.append(junk_proto_v3(rng, 1, pool))


def insert_wrapper_refs(root: Proto, rng):
    """Conditional calls to junk wrappers: opaque-alias-false dead branch
    (never runs) + live path. Statically called, captures real upvalues."""
    for p in real_protos(root):
        if len(p.code) < 6 or not p.children:
            continue
        jn = [i for i, ch in enumerate(p.children) if ch.is_junk]
        if not jn:
            continue
        at = pick_safe_pos(p, rng)
        if at is None:
            continue
        s = p.nregs
        p.nregs += 2
        # alias-opaque-false: t1={} t2={} EQ 0,s,s+1 (distinct tables -> false)
        # Implemented with NEWTABLEs + EQ skip + JMP: dead branch holds the
        # wrapper call (statically present, never executed).
        items = [
            Instr(41, s, 0, 0, p.code[at].line),
            Instr(41, s + 1, 0, 0, p.code[at].line),
            Instr(22, 0, s, s + 1, p.code[at].line),  # EQ 0: skip iff equal (false -> no skip)
            Instr(26, 0, 0, 0, p.code[at].line),       # J_DB -> wrapper call block
            Instr(26, 0, 0, 0, p.code[at].line),       # J_REAL -> orig (live skips dead)
        ]
        # dead block: allocate wrapper closure capturing real box 0 + call it
        db = [
            Instr(31, s, rng.choice(jn), 0, p.code[at].line),
            Instr(27, s, 1, 1, p.code[at].line),
        ]
        links = [(3, ("local", len(items))), (4, ("orig", at)),
                 (len(items) + len(db), ("orig", at))]
        items.extend(db)
        items.append(Instr(26, 0, 0, 0, p.code[at].line))
        links.append((len(items) - 1, ("orig", at)))
        splice_with_remap(p, [(at, items, links)])


def pick_safe_pos(p: Proto, rng):
    cands = [i for i in range(len(p.code)) if not _prev_is_skip(p.code, i)]
    if not cands:
        return None
    return rng.choice(cands)


def _prev_is_skip(code, idx):
    if idx <= 0:
        return False
    prev = code[idx - 1]
    if prev.op in (22, 23, 24, 25):
        return True
    return prev.op == 4 and prev.c != 0


SKIP_OPS = {22, 23, 24, 25}


def make_spans_v3(p: Proto, params, rng, density):
    """Real-touching diamonds: save/restore live regs (identity), alias
    opaque predicates (3 templates), shared rejoin targets, no NOPs live,
    live block executes through junk decoder trampoline."""
    out = []
    code = list(p.code)
    jn = [i for i, ch in enumerate(p.children) if ch.is_junk]
    for idx, ins in enumerate(code):
        if _prev_is_skip(code, idx):
            continue
        if rng.randrange(0, 100) >= density:
            continue
        line = ins.line
        orig_nregs = p.nregs
        s = orig_nregs
        t = orig_nregs + 1
        # pick a real reg to touch (must exist)
        if orig_nregs <= 1:
            rt = 0
        else:
            rt = rng.randrange(0, orig_nregs)
        # opaque predicate template (always-true, needs solver/alias analysis)
        tpl = rng.randrange(0, 3)
        if tpl == 0:
            # alias tables: NEWTABLE s; MOVE t,s; EQ 1,s,t (same table -> true)
            pred = [
                Instr(41, s, 0, 0, line),
                Instr(1, t, s, 0, line),
                Instr(22, 1, s, t, line),
            ]
        elif tpl == 1 and p.consts:
            # string-len parity: LOADK s,"..."; LEN s,s; MOD? use EQ on numbers:
            # (len*2)%2==0 always true -> via BNOT/MBA? Use: LEN s,s; BAND t,s,1; EQ 0,t,zero?
            # Simpler type-safe: LOADK s,str; LEN s,s; EQ needs reg compare:
            # LOADK t,"" LEN? Keep simple: two LOADKs of same const + EQ (same string -> true,
            # but syntactically distinct const loads; needs value analysis, not register GVN).
            kk = rng.randrange(0, len(p.consts))
            pred = [
                Instr(2, s, kk, 0, line),
                Instr(2, t, kk, 0, line),
                Instr(22, 1, s, t, line),
            ]
        else:
            # arithmetic identity on small int const: (x - x)==0 always true.
            # LOADK s,k; LOADK t,k; SUB s,s,t; LOADK t,zero?; EQ 1,s,t0?
            # Needs zero reg: use LOADNIL? EQ nil? (x-x)=0, compare with 0 const.
            # Find or append zero const? Use existing const if numeric else alias fallback.
            nums = [i for i, c in enumerate(p.consts) if c[0] == "num" and float(c[1]).is_integer()]
            if nums:
                kk = rng.choice(nums)
                pred = [
                    Instr(2, s, kk, 0, line),
                    Instr(2, t, kk, 0, line),
                    Instr(6, s, s, t, line),  # SUB s = s - t (=0)
                    Instr(2, t, kk, 0, line),
                    Instr(6, t, t, t, line),  # SUB t = 0
                    Instr(22, 1, s, t, line),
                ]
            else:
                pred = [
                    Instr(41, s, 0, 0, line),
                    Instr(1, t, s, 0, line),
                    Instr(22, 1, s, t, line),
                ]
        items = list(pred)
        links = []
        items.append(Instr(26, 0, 0, 0, line))
        j_db = len(items) - 1
        # LIVE block (executes): save real -> junk reads of saved (type-safe:
        # MOVE/TEST only) -> identity restore. Touches real regs; middle ops
        # read live saved value so naive def-use keeps them.
        live_start = len(items)
        items.append(Instr(1, s, rt, 0, line))      # save real
        # Lean live window: 2..5 identity ops (was 6..15). Still touches
        # a real reg so naive def-use keeps the span, but costs ~3x less
        # at runtime (live block executes on every hit).
        nlive = rng.randrange(2, 6)
        for k in range(nlive):
            pick = rng.randrange(0, 5)
            if pick == 0:
                items.append(Instr(1, t, s, 0, line))      # MOVE t,s (read live)
            elif pick == 1:
                items.append(Instr(1, s, s, 0, line))      # MOVE s,s (live identity)
            elif pick == 2:
                items.append(Instr(25, s, 0, rng.randrange(0, 2), line))  # TEST s (read live)
            elif pick == 3:
                items.append(Instr(1, t, rt, 0, line))     # MOVE t,real (read live)
            else:
                items.append(Instr(19, t, s, 0, line))     # NOT t,s (safe, dead t)
        items.append(Instr(1, rt, s, 0, line))       # restore real (identity)
        # J_REAL -> original position (rejoin through shared target)
        items.append(Instr(26, 0, 0, 0, line))
        j_real = len(items) - 1
        db_start = len(items)
        # Lean dead window: 2..5 (was 4..12).
        for _ in range(rng.randrange(2, 6)):
            items.append(dead_instr_v3(p, rng, s, t, jn, line, orig_nregs))
        items.append(Instr(26, 0, 0, 0, line))
        j_back = len(items) - 1
        links.append((j_db, ("local", db_start)))
        links.append((j_real, ("orig", idx)))
        links.append((j_back, ("orig", idx)))
        for k in range(db_start, len(items) - 1):
            if items[k].op == 26 and items[k].b == 0xDEAD0000:
                tgt = rng.randrange(k + 1, len(items))
                links.append((k, ("local", tgt)))
        # inner live jumps: none emitted (straight-line) to stay crash-safe
        out.append((idx, items, links))
        _ = live_start
    if out:
        p.nregs = max(p.nregs, orig_nregs + 2)
    return out


def dead_instr_v3(p: Proto, rng, s: int, t: int, jn: list, line: int, orig_nregs: int):
    rr = [rng.randrange(0, max(p.nregs, 1)) for _ in range(3)]
    kk = rng.randrange(0, len(p.consts)) if p.consts else 0
    pick = rng.randrange(0, 16)
    if pick == 0 and jn:
        return Instr(31, s, rng.choice(jn), 0, line)
    if pick == 1:
        return Instr(27, rr[0], 1 + rng.randrange(0, 3), rng.randrange(0, 3), line)
    if pick == 2:
        return Instr(40, rr[0], rr[1], rng.randrange(0, len(p.consts)) if p.consts else 0, line)
    if pick == 3:
        return Instr(38, rr[0], rr[1], rr[2], line)
    if pick == 4:
        return Instr(39, rr[0], rr[1], rr[2], line)
    if pick == 5:
        return Instr(5 + rng.randrange(0, 7), rr[0], rr[1], rr[2], line)
    if pick == 6:
        return Instr(36, rr[0], kk, 0, line)
    if pick == 7:
        return Instr(22 + rng.randrange(0, 3), rng.randrange(0, 2), rr[1], rr[2], line)
    if pick == 8:
        return Instr(26, 0, 0xDEAD0000, 0, line)
    if pick == 9:
        return Instr(21, rr[0], rr[1], rr[2], line)
    if pick == 10:
        return Instr(30, rr[0], rng.randrange(0, 3), 0, line)
    if pick == 11:
        return Instr(20, rr[0], rr[1], 0, line)
    if pick == 12:
        return Instr(41, rr[0], 0, 0, line)
    if pick == 13:
        return Instr(2, rr[0], kk, 0, line)
    if pick == 14:
        return Instr(25, rr[0], 0, rng.randrange(0, 2), line)
    # superop-shaped dead code (breaks 1:1 mapping analysis)
    if pick == 15 and p.consts:
        return Instr(49 + rng.randrange(0, 5), rr[0], kk, kk, line)
    return Instr(2, rr[0], kk, 0, line)


def insert_all(p: Proto, params, rng, density):
    spans = make_spans_v3(p, params, rng, density)
    if spans:
        layout_inserts(p, spans)
    for ch in p.children:
        insert_all(ch, params, rng, density)


def trampoline_jumps(root: Proto, rng, pct: int):
    """Shared rejoin targets (see make_spans_v3 links + layout_inserts):
    every span's live/dead blocks rejoin at the same original position, so
    real control flow passes through junk blocks to fetch the next pc.
    A separate trampoline-retarget pass was folded into the span layout
    (it produced identical sharing with less offset churn). Kept as a
    documented no-op for pipeline stability."""
    return


# ---------- serialization ----------
class SerCtx:
    def __init__(self, params):
        self.p = params
        self.counter = 0
        self.rng = random.Random((params["seed64"] ^ 0xB10B5EED) & MASK32)

    def next_index(self) -> int:
        q = self.counter
        self.counter += 1
        return q

    def bias_for(self, q: int, i: int) -> bytes:
        hp = self.p["hp"]
        kp = self.p["keys"]["perm"]
        return HH.digest(kp + q.to_bytes(4, "little") + b"b" + i.to_bytes(4, "little"), hp)[0:3]


def chunk_const_v3(rng, pt: bytes):
    # Lean: short consts (method names, small strings, numbers) stay in
    # one chunk (no per-chunk nonce/hash overhead). Larger blobs split
    # 2..3 ways (was 2..5). Cuts const size and per-chunk hashes at load.
    if len(pt) <= 8:
        return [pt]
    nch = min(len(pt), rng.randrange(2, 4))
    # random cut points
    cuts = sorted(rng.sample(range(1, len(pt)), nch - 1))
    parts = []
    prev = 0
    for c in cuts + [len(pt)]:
        parts.append(pt[prev:c])
        prev = c
    return parts


def enc_const_entry_v3(ctx: SerCtx, tag: int, pt: bytes) -> bytes:
    p = ctx.p
    rng = ctx.rng
    kc = p["keys"]["const"]
    out = bytearray()
    out.append((tag + kc[1]) & 0xFF)
    if tag not in (3, 7):
        return bytes(out)
    chunks = chunk_const_v3(rng, pt)
    order = list(range(len(chunks)))
    rng.shuffle(order)
    out.append(len(chunks) & 0xFF)
    prevh = kc
    for pos in order:
        ch = chunks[pos]
        nonce = bytes(rng.randrange(0, 256) for _ in range(4))
        out += nonce
        out.append(pos & 0xFF)
        out.append(len(ch) & 0xFF)
        enc = V.const_chain_crypt(p["hp"], kc, nonce, pos, prevh, ch)
        out += enc
        prevh = HH.digest(prevh + ch, p["hp"])
    return bytes(out)


def ser_proto_v3(proto: Proto, out: bytearray, ctx: SerCtx):
    p = ctx.p
    q = ctx.next_index()
    slots, inv, dead = V.wire_tables(p, q)
    import struct as _st

    def w16(v):
        out.extend(_st.pack("<H", v & 0xFFFF))

    w16(proto.nparams)
    w16(1 if proto.vararg else 0)
    w16(proto.nregs)
    w16(proto.nown)
    w16(len(proto.consts))
    w16(len(proto.code))
    w16(len(proto.children))
    w16(len(proto.uvdescs))
    for c in proto.consts:
        if c[0] == "nil":
            out.append((0 + p["keys"]["const"][1]) & 0xFF)
        elif c[0] == "bool":
            out.append(((2 if c[1] else 1) + p["keys"]["const"][1]) & 0xFF)
        elif c[0] == "num":
            import math as _m
            v = float(c[1])
            if _m.isnan(v):
                out.append((6 + p["keys"]["const"][1]) & 0xFF)
            elif v == float("inf"):
                out.append((4 + p["keys"]["const"][1]) & 0xFF)
            elif v == float("-inf"):
                out.append((5 + p["keys"]["const"][1]) & 0xFF)
            else:
                if v.is_integer() and abs(v) < 2 ** 53:
                    s = str(int(v)).encode()
                else:
                    s = repr(v).encode()
                out += enc_const_entry_v3(ctx, 3, s)
        elif c[0] == "str":
            out += enc_const_entry_v3(ctx, 7, c[1])
        else:
            raise ValueError("bad const %r" % (c,))
    # code bitstream with chaining + overlap + pads.
    # Fast per-instruction bias/pad: a single xsstep chain seeded from
    # H(k_perm + q) (the same fsd the loader recomputes for the wire
    # permutation). Previously each instruction cost 2 full ARX hashes
    # (__bias3 + __padlen) at load; now 4 xssteps. Byte-exact mirror of
    # __parseproto's bst chain.
    bw = V.BitWriter()
    prev = 0
    kp = p["keys"]["perm"]
    fsd = int.from_bytes(HH.digest(kp + q.to_bytes(4, "little"), p["hp"])[0:4], "little")
    bst = fsd or 0x9E3779B9
    for pos, ins in enumerate(proto.code):
        wires = slots[ins.op]
        wire = wires[(q + pos) % len(wires)]
        bw.put(wire, p["op_bits"])
        bst = V.xs_step(bst)
        b0 = bst & 0xFF
        bst = V.xs_step(bst)
        b1 = bst & 0xFF
        bst = V.xs_step(bst)
        b2 = bst & 0xFF
        bst = V.xs_step(bst)
        pl = bst % 3
        pb = prev & 0xFF
        a_e = (ins.a + b0 + pb) & MASK32
        b_e = (ins.b + (ins.a * p["m1"] & 0xFF) + b1 + pb) & MASK32
        c_e = (ins.c + (ins.b * p["m2"] & 0xFF) + b2 + pb) & MASK32
        bw.put_escaped(a_e, p["wa"])
        bw.put_escaped(b_e, p["wb"])
        bw.put_escaped(c_e, p["wc"])
        if pl:
            bw.put((bst >> 8) & ((1 << pl) - 1), pl)
        prev = (a_e + b_e + c_e + (ins.op * 2654435761 & MASK32)) & MASK32
    cbytes = bw.bytes()
    out.extend(_st.pack("<I", len(cbytes) & MASK32))
    out += cbytes
    for (k, i) in proto.uvdescs:
        out.append(k & 0xFF)
        w16(i)
    for ch in proto.children:
        ser_proto_v3(ch, out, ctx)
    # Lean lines: 2 bytes each (was 4). Original lines are small
    # (<a few thousand even scrambled); truncation to u16 is load-bearing
    # consistent on both sides and halves the line-table size.
    for ln in proto.lines:
        out += _st.pack("<H", ln & 0xFFFF)


def build_payload(root: Proto, seed: int, level: int, strip_debug: bool, bind_env=None):
    params = derive_all(seed & 0xFFFFFFFFFFFFFFFF, bind_env)
    apply_transforms(root, params, level, strip_debug)
    ctx = SerCtx(params)
    body = bytearray()
    body += params["magic"]
    body.append(VERSION)
    body.append((level & 3) ^ (params["keys"]["enc"][16] & 3))
    padlen = 16 + ctx.rng.randrange(0, 48)
    pad = bytes(ctx.rng.randrange(0, 256) for _ in range(padlen))
    body.append(padlen & 0xFF)
    body += pad
    ser_proto_v3(root, body, ctx)
    mac = HH.hmac(params["keys"]["enc"], bytes(body), params["hp"])
    enc = V.stream_crypt(params["hp"], params["keys"]["enc"], params["iv"], bytes(body) + mac)
    raw = params["iv"] + enc
    # Lean segments: single hex segment. Multi-segment keyed interleaving
    # cost O(total) xssteps + per-byte string.sub/concat at load for no
    # load-bearing security (integrity is encrypt-then-MAC regardless).
    # Single-segment join is a straight decode with no interleave loop.
    # Hex (2x) is smaller than dec (3x) and decodes with byte arithmetic
    # instead of tonumber-per-triple.
    nseg = 1
    encmap = [0]
    segments = ["".join("%02x" % b for b in bytes(raw))]
    return {"segments": segments, "seed": seed & 0xFFFFFFFFFFFFFFFF,
            "params": params, "nseg": nseg, "encmap": encmap,
            "level": level}


def splice_with_remap(p: Proto, inserts):
    layout_inserts(p, inserts)


def layout_inserts(p: Proto, inserts):
    old_targets = [jump_target(p.code, i) for i in range(len(p.code))]
    by_at = {}
    for (at, items, links) in inserts:
        # links may contain ("retramp", at) markers (ignored here)
        links = [(k, t) for (k, t) in links if not (isinstance(t, tuple) and t[0] == "retramp")]
        by_at.setdefault(at, []).append((items, links))
    old2new = [0] * (len(p.code) + 1)
    new_code = []
    pending = []
    for oi in range(len(p.code)):
        if oi in by_at:
            for (items, links) in by_at[oi]:
                base = len(new_code)
                for it in items:
                    new_code.append(Instr(it.op, it.a, it.b, it.c, it.line))
                for (k, tgt) in links:
                    pending.append((base + k, tgt, base, len(items), oi))
        old2new[oi] = len(new_code)
        o = p.code[oi]
        new_code.append(Instr(o.op, o.a, o.b, o.c, o.line))
    old2new[len(p.code)] = len(new_code)
    for (pos, tgt, base, blen, oi) in pending:
        kind = tgt[0]
        if kind == "orig":
            dest = old2new[min(tgt[1], len(old2new) - 1)]
        elif kind == "after":
            dest = base + blen
        else:
            dest = base + tgt[1]
        set_jump(new_code, pos, dest)
    new2old = [-1] * len(new_code)
    for oi, nw in enumerate(old2new[:len(p.code)]):
        new2old[nw] = oi
    for ni in range(len(new_code)):
        oi = new2old[ni]
        if oi < 0:
            continue
        t = old_targets[oi]
        if t is not None:
            set_jump(new_code, ni, old2new[min(t, len(old2new) - 1)])
    p.code = new_code

