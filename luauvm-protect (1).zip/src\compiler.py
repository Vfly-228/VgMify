"""Compiler: AST -> register/box IR (Proto tree).
Design mirrors runtime/vm.luau: named source locals live in per-frame boxes
(BX own, UX inherited) so nested closures alias correctly; temps live in R.
Opcodes: 49 real ids, scrambled per build at encode time.

Opcode ids (real, pre-permutation):
0 NOP, 1 MOVE, 2 LOADK, 3 LOADNIL, 4 LOADBOOL, 5 ADD, 6 SUB, 7 MUL, 8 DIV,
9 MOD, 10 POW, 11 IDIV, 12 BAND, 13 BOR, 14 BXOR, 15 SHL, 16 SHR, 17 BNOT,
18 UNM, 19 NOT, 20 LEN, 21 CONCAT, 22 EQ, 23 LT, 24 LE, 25 TEST, 26 JMP,
27 CALL, 28 RETURN, 29 TAILCALL, 30 VARARG, 31 CLOSURE, 32 GETUPVAL,
33 SETUPVAL, 34 CAPTURE, 35 CAPNIL, 36 GETGLOBAL, 37 SETGLOBAL, 38 GETTABLE,
39 SETTABLE, 40 SELF, 41 NEWTABLE, 42 SETLIST, 43 FORPREP, 44 FORLOOP,
45 TFORPREP, 46 TFORCALL, 47 TFORLOOP, 48 CLOSE
"""
from dataclasses import dataclass, field
from typing import List, Tuple, Dict, Optional
from . import parser as P

NOPS = 49
# v3 superoperators (49..53). Base pipeline emits 0..48; v3 fuses
# common pairs into 49..53. NOPS_V3 is the full real space.
OP = {
    "NOP":0,"MOVE":1,"LOADK":2,"LOADNIL":3,"LOADBOOL":4,"ADD":5,"SUB":6,
    "MUL":7,"DIV":8,"MOD":9,"POW":10,"IDIV":11,"BAND":12,"BOR":13,"BXOR":14,
    "SHL":15,"SHR":16,"BNOT":17,"UNM":18,"NOT":19,"LEN":20,"CONCAT":21,
    "EQ":22,"LT":23,"LE":24,"TEST":25,"JMP":26,"CALL":27,"RETURN":28,
    "TAILCALL":29,"VARARG":30,"CLOSURE":31,"GETUPVAL":32,"SETUPVAL":33,
    "CAPTURE":34,"CAPNIL":35,"GETGLOBAL":36,"SETGLOBAL":37,"GETTABLE":38,
    "SETTABLE":39,"SELF":40,"NEWTABLE":41,"SETLIST":42,"FORPREP":43,
    "FORLOOP":44,"TFORPREP":45,"TFORCALL":46,"TFORLOOP":47,"CLOSE":48,
    "LCONCAT_KK":49,"LCONCAT_RK":50,"LCONCAT_KR":51,"TLOOP":52,"TJMP":53,
}
OPNAME = {v:k for k,v in OP.items()}
NOPS_V3 = 54
SUPER_OPS = (49, 50, 51, 52, 53)

class CompileError(Exception):
    pass

def zz(v: int) -> int:
    # zigzag encode signed -> unsigned (32-bit). Python >> is arithmetic, so
    # (v>>31) is 0 for v>=0 and -1 for v<0, matching Rust's (v>>31) on i32.
    return (((v << 1) ^ (v >> 31)) & 0xFFFFFFFF)

def zz_off(at: int, target: int) -> int:
    # at = index of the jumping instruction; target = destination index.
    # VM does pc+=1 then pc+=off, so off = target - (at+1).
    return (zz(target - at - 1)) & 0xFFFFFFFF

@dataclass
class Instr:
    op: int
    a: int
    b: int
    c: int
    line: int

@dataclass
class Proto:
    nparams: int = 0
    vararg: bool = False
    nregs: int = 1
    nown: int = 0
    consts: list = field(default_factory=list)  # ('nil',)/('bool',b)/('num',f)/('str',bytes)
    code: list = field(default_factory=list)    # Instr
    children: list = field(default_factory=list)
    uvdescs: list = field(default_factory=list)  # (kind, idx)
    lines: list = field(default_factory=list)
    is_junk: bool = False

    def dump(self, indent=0):
        s = "  "*indent + f"proto params={self.nparams} vararg={self.vararg} regs={self.nregs} own={self.nown} consts={len(self.consts)} code={len(self.code)} kids={len(self.children)}\n"
        for i,c in enumerate(self.consts):
            s += "  "*indent + f"  K{i}: {c!r}\n"
        for i,ins in enumerate(self.code):
            s += "  "*indent + f"  {i:04}: {OPNAME[ins.op]} {ins.a} {ins.b} {ins.c} ;:{ins.line}\n"
        for ch in self.children:
            s += ch.dump(indent+1)
        return s

class Frame:
    def __init__(self, parent, proto_idx, nparams, vararg):
        self.parent = parent
        self.proto = proto_idx
        self.slots: List[Tuple[str,int]] = []  # (name, boxidx)
        self.next_box = 0
        self.max_box = 0
        self.base_reg = nparams
        self.temp_floor = nparams
        self.next_reg = nparams
        self.max_reg = nparams + 1
        self.loops: list = []  # dicts
        self.gotos: list = []
        self.labels: Dict[str, Tuple[int,int]] = {}
        self.vararg = vararg
        self.str_map: Dict[bytes,int] = {}
        self.num_map: Dict[int,int] = {}

class Compiler:
    def __init__(self):
        self.protos: List[Proto] = []
        self.frames: List[int] = []
        self.arena: List[Frame] = []
        self.multi_flag = False
        self.up_names: Dict[Tuple[int,str], Tuple[int,int]] = {}

    # ---- setup ----
    def compile(self, block: P.Block) -> Proto:
        self.protos.append(Proto(nparams=0, vararg=True))
        f = Frame(None, 0, 0, True)
        self.arena.append(f)
        self.frames.append(0)
        has_ret = block.ret is not None
        self.block(block, True)
        if not has_ret:
            self.emit(OP["RETURN"], 0, 1, 0, block.line)
        self.resolve_gotos(0, block.line)
        if self.arena[0].loops:
            raise CompileError(f"unclosed loop at line {block.line}")
        self.finish_frame(0)
        return self.protos[0]

    def fi(self):
        return self.frames[-1]

    def cur_pc(self):
        return len(self.protos[self.arena[self.fi()].proto].code)

    def emit(self, op, a, b, c, line):
        p = self.arena[self.fi()].proto
        self.protos[p].code.append(Instr(op,a,b,c,line))
        self.protos[p].lines.append(line)
        return len(self.protos[p].code)-1

    def emit_jump(self, op, a, line):
        return self.emit(op, a, 0, 0, line)

    def patch(self, at, target):
        p = self.arena[self.fi()].proto
        off = target - (at + 1)
        self.protos[p].code[at].b = zz(off) & 0xFFFFFFFF

    def alloc_temp(self, n):
        f = self.arena[self.fi()]
        r = f.next_reg
        f.next_reg += n
        if f.next_reg > f.max_reg:
            f.max_reg = f.next_reg
        return r

    def temp_reset(self):
        f = self.arena[self.fi()]
        f.next_reg = f.temp_floor

    def set_floor(self, v):
        f = self.arena[self.fi()]
        f.temp_floor = v
        if f.next_reg < v:
            f.next_reg = v

    def floor(self):
        return self.arena[self.fi()].temp_floor

    def const_nil(self):
        p = self.arena[self.fi()].proto
        self.protos[p].consts.append(("nil",))
        return len(self.protos[p].consts)-1

    def const_bool(self, v):
        p = self.arena[self.fi()].proto
        self.protos[p].consts.append(("bool", bool(v)))
        return len(self.protos[p].consts)-1

    def const_num(self, v: float):
        import struct
        fi = self.fi()
        bits = struct.unpack("<Q", struct.pack("<d", float(v)))[0]
        if bits in self.arena[fi].num_map:
            return self.arena[fi].num_map[bits]
        p = self.arena[fi].proto
        self.protos[p].consts.append(("num", float(v)))
        i = len(self.protos[p].consts)-1
        self.arena[fi].num_map[bits] = i
        return i

    def const_str(self, s: bytes):
        fi = self.fi()
        if s in self.arena[fi].str_map:
            return self.arena[fi].str_map[s]
        p = self.arena[fi].proto
        self.protos[p].consts.append(("str", bytes(s)))
        i = len(self.protos[p].consts)-1
        self.arena[fi].str_map[s] = i
        return i

    def open_scope(self):
        f = self.arena[self.fi()]
        return (len(f.slots), f.next_box)

    def close_scope(self, m):
        f = self.arena[self.fi()]
        del f.slots[m[0]:]
        f.next_box = m[1]

    def decl_named(self, name, line):
        f = self.arena[self.fi()]
        b = f.next_box
        f.next_box += 1
        if f.next_box > f.max_box:
            f.max_box = f.next_box
        f.slots.append((name, b))
        return b

    def live_count(self):
        return len(self.arena[self.fi()].slots)

    # resolve: returns ('own',box) / ('up',sel,idx) / ('global',)
    def resolve_named(self, name, line):
        fi = self.fi()
        for (nm, bx) in reversed(self.arena[fi].slots):
            if nm == name:
                return ("own", bx)
        # walk outward
        chain = [fi]
        cur = fi
        decl_frame = None
        decl_box = None
        decl_up = None
        while True:
            par = self.arena[cur].parent
            if par is None:
                break
            fb = None
            for (nm, bx) in reversed(self.arena[par].slots):
                if nm == name:
                    fb = bx
                    break
            if fb is not None:
                decl_frame = par
                decl_box = fb
                break
            if (par, name) in self.up_names:
                decl_frame = par
                decl_up = self.up_names[(par, name)]
                break
            chain.append(par)
            cur = par
        if decl_frame is None:
            return ("global",)
        # build descs from declarer down to fi
        # chain = [fi, P1, ...cur]; declarer = parent of cur
        down = list(chain)  # [fi..cur]
        down.reverse()  # [cur..fi], all strictly below declarer
        if decl_box is not None:
            prov = (0, decl_box)
        else:
            assert decl_up is not None
            prov = (decl_up[0], decl_up[1])
        for h in down:
            p = self.arena[h].proto
            dl = self.protos[p].uvdescs
            slot = None
            for k, d in enumerate(dl):
                if d[0]==prov[0] and d[1]==prov[1]:
                    slot = k
                    break
            if slot is None:
                dl.append(prov)
                slot = len(dl)-1
            self.up_names[(h, name)] = (1, slot)
            prov = (1, slot)
        sel, idx = self.up_names[(fi, name)]
        return ("up", sel, idx)

    def resolve_gotos(self, fl, line):
        gotos = self.arena[fl].gotos[:]
        self.arena[fl].gotos = []
        for g in gotos:
            if g["label"] in self.arena[fl].labels:
                pc, llive = self.arena[fl].labels[g["label"]]
                if llive > g["live"]:
                    raise CompileError(f"line {g['line']}: goto `{g['label']}` jumps into scope of a local")
                p = self.arena[fl].proto
                off = pc - (g["pc"] + 1)
                self.protos[p].code[g["pc"]].b = zz(off) & 0xFFFFFFFF
            else:
                raise CompileError(f"line {g['line']}: no visible label `{g['label']}`")

    def finish_frame(self, fl):
        p = self.arena[fl].proto
        pr = self.protos[p]
        f = self.arena[fl]
        pr.nregs = max(f.max_reg, max(f.base_reg, 1))
        pr.nown = f.max_box

    # ---- blocks ----
    def block(self, b: P.Block, is_func_body):
        mark = self.open_scope()
        for s in b.stmts:
            self.stmt(s)
            self.temp_reset()
        if b.ret is not None:
            self.do_return(b.ret, is_func_body)
        self.close_scope(mark)

    def block_inner(self, b: P.Block):
        for s in b.stmts:
            self.stmt(s)
            self.temp_reset()
        if b.ret is not None:
            self.do_return(b.ret, False)

    def do_return(self, r: P.Ret, _is_func_body):
        line = r.line
        # tailcall: return f(args)
        if len(r.exprs) == 1 and isinstance(r.exprs[0], (P.E_Call, P.E_Method)):
            e = r.exprs[0]
            if isinstance(e, P.E_Call):
                self.call_expr(e.func, e.args, e.line, want="tail")
            else:
                self.method_call(e.obj, e.method, e.args, e.line, want="tail")
            return
        if not r.exprs:
            self.emit(OP["CLOSE"], 0,0,0, line)
            self.emit(OP["RETURN"], 0,1,0, line)
            return
        base = self.alloc_temp(len(r.exprs)+4)
        n = len(r.exprs)
        for i, e in enumerate(r.exprs):
            if i+1 == n:
                self.expr_multi(e, base+i)
                if not self.multi_flag:
                    self.emit(OP["CLOSE"],0,0,0,line)
                    self.emit(OP["RETURN"], base, n+1, 0, line)
                else:
                    self.emit(OP["CLOSE"],0,0,0,line)
                    self.emit(OP["RETURN"], base, 0, 0, line)
                return
            else:
                rr = self.expr_single(e)
                if rr != base+i:
                    self.emit(OP["MOVE"], base+i, rr, 0, line)

    def stmt(self, s):
        if isinstance(s, P.S_TypeDecl) or isinstance(s, P.S_Nop):
            return
        if isinstance(s, P.S_Local):
            return self.stmt_local(s.names, s.exprs, s.line)
        if isinstance(s, P.S_Assign):
            return self.stmt_assign(s.lhs, s.rhs, s.line)
        if isinstance(s, P.S_Compound):
            return self.stmt_compound(s.op, s.lhs, s.rhs, s.line)
        if isinstance(s, P.S_Call):
            e = s.expr
            if isinstance(e, P.E_Call):
                self.call_expr(e.func, e.args, e.line, want="none")
                return
            if isinstance(e, P.E_Method):
                self.method_call(e.obj, e.method, e.args, e.line, want="none")
                return
            raise CompileError(f"line {e.line}: not a call")
        if isinstance(s, P.S_Do):
            m = self.open_scope()
            self.block_inner(s.body)
            self.close_scope(m)
            return
        if isinstance(s, P.S_While):
            return self.stmt_while(s.cond, s.body, s.line)
        if isinstance(s, P.S_Repeat):
            return self.stmt_repeat(s.body, s.cond, s.line)
        if isinstance(s, P.S_If):
            return self.stmt_if(s.arms, s.else_, s.line)
        if isinstance(s, P.S_NumFor):
            return self.stmt_numfor(s.var, s.start, s.limit, s.step, s.body, s.line)
        if isinstance(s, P.S_GenFor):
            return self.stmt_genfor(s.names, s.iters, s.body, s.line)
        if isinstance(s, P.S_FuncDef):
            return self.stmt_funcdef(s.base, s.fields, s.method, s.body, s.line)
        if isinstance(s, P.S_LocalFunc):
            return self.stmt_localfunc(s.name, s.body, s.line)
        if isinstance(s, P.S_Break):
            if not self.arena[self.fi()].loops:
                raise CompileError(f"line {s.line}: break outside loop")
            pc = self.emit_jump(OP["JMP"], 0, s.line)
            self.arena[self.fi()].loops[-1]["breaks"].append(pc)
            return
        if isinstance(s, P.S_Continue):
            if not self.arena[self.fi()].loops:
                raise CompileError(f"line {s.line}: continue outside loop")
            loop = self.arena[self.fi()].loops[-1]
            if loop["cont"] is not None:
                self.emit(OP["JMP"], 0, zz_off(self.cur_pc(), loop["cont"]) & 0xFFFFFFFF, 0, s.line)
            else:
                pc = self.emit_jump(OP["JMP"], 0, s.line)
                loop["conts"].append(pc)
            return
        if isinstance(s, P.S_Goto):
            live = self.live_count()
            fi = self.fi()
            if s.label in self.arena[fi].labels:
                pc, llive = self.arena[fi].labels[s.label]
                if llive > live:
                    raise CompileError(f"line {s.line}: goto jumps into scope")
                self.emit(OP["JMP"], 0, zz_off(self.cur_pc(), pc) & 0xFFFFFFFF, 0, s.line)
            else:
                pc = self.emit_jump(OP["JMP"], 0, s.line)
                self.arena[fi].gotos.append({"label": s.label, "pc": pc, "live": live, "line": s.line})
            return
        if isinstance(s, P.S_Label):
            fi = self.fi()
            if s.name in self.arena[fi].labels:
                raise CompileError(f"line {s.line}: duplicate label")
            pc = self.cur_pc()
            live = self.live_count()
            self.arena[fi].labels[s.name] = (pc, live)
            self.emit(OP["NOP"], 0,0,0, s.line)
            return
        raise CompileError(f"unknown stmt {s!r}")

    # ---- locals/assign ----
    def stmt_local(self, names, exprs, line):
        boxes = []
        for n in names:
            b = self.decl_named(n, line)
            self.emit(OP["CAPNIL"], b, 0, 0, line)
            boxes.append(b)
        if not exprs:
            return
        m = len(names); n = len(exprs)
        base = self.alloc_temp(m+4)
        for i, e in enumerate(exprs):
            if i+1==n and i < m:
                want = m - i
                self.expr_fixed_multi(e, base+i, want)
            elif i < m:
                rr = self.expr_single(e)
                if rr != base+i:
                    self.emit(OP["MOVE"], base+i, rr, 0, line)
            else:
                self.expr_single(e)
        for j, b in enumerate(boxes):
            self.emit(OP["SETUPVAL"], base+j, b, 0, line)

    def stmt_assign(self, lhs, rhs, line):
        # lhs: list of V_* ; rhs: list of expr
        addrs = []  # ('own',b)/('up',s,i)/('global',k)/('tab',tab,key)
        for v in lhs:
            if isinstance(v, P.V_Name):
                r = self.resolve_named(v.name, line)
                if r[0]=="own":
                    addrs.append(("own", r[1]))
                elif r[0]=="up":
                    addrs.append(("up", r[1], r[2]))
                else:
                    k = self.const_str(v.name.encode())
                    addrs.append(("global", k))
            elif isinstance(v, P.V_Field):
                t = self.expr_single(v.tab)
                tt = self.alloc_temp(1)
                self.emit(OP["MOVE"], tt, t, 0, line)
                k = self.const_str(v.field.encode())
                kk = self.alloc_temp(1)
                self.emit(OP["LOADK"], kk, k, 0, line)
                addrs.append(("tab", tt, kk))
            elif isinstance(v, P.V_Index):
                t = self.expr_single(v.tab)
                tt = self.alloc_temp(1)
                self.emit(OP["MOVE"], tt, t, 0, line)
                k = self.expr_single(v.key)
                kk = self.alloc_temp(1)
                self.emit(OP["MOVE"], kk, k, 0, line)
                addrs.append(("tab", tt, kk))
            else:
                raise CompileError(f"line {line}: bad lhs")
        m = len(lhs); n = len(rhs)
        base = self.alloc_temp(m+4)
        for i, e in enumerate(rhs):
            if i+1==n and i < m:
                self.expr_fixed_multi(e, base+i, m-i)
            elif i < m:
                rr = self.expr_single(e)
                if rr != base+i:
                    self.emit(OP["MOVE"], base+i, rr, 0, line)
            else:
                self.expr_single(e)
        nilr = None
        if m > n:
            t = self.alloc_temp(1)
            k = self.const_nil()
            self.emit(OP["LOADK"], t, k, 0, line)
            nilr = t
        for j, a in enumerate(addrs):
            src = base+j if j < n else nilr
            if a[0]=="own":
                self.emit(OP["SETUPVAL"], src, a[1], 0, line)
            elif a[0]=="up":
                self.emit(OP["SETUPVAL"], src, a[2], a[1], line)
            elif a[0]=="global":
                self.emit(OP["SETGLOBAL"], src, a[1], 0, line)
            else:
                self.emit(OP["SETTABLE"], a[1], a[2], src, line)

    def stmt_compound(self, op, lhs, rhs, line):
        if isinstance(lhs, P.V_Name):
            v = self.expr_single(P.E_Var(lhs, line))
            r = self.expr_single(rhs)
            d = self.alloc_temp(1)
            self.emit_binop(op, d, v, r, line)
            rs = self.resolve_named(lhs.name, line)
            if rs[0]=="own":
                self.emit(OP["SETUPVAL"], d, rs[1], 0, line)
            elif rs[0]=="up":
                self.emit(OP["SETUPVAL"], d, rs[2], rs[1], line)
            else:
                k = self.const_str(lhs.name.encode())
                self.emit(OP["SETGLOBAL"], d, k, 0, line)
            return
        if isinstance(lhs, P.V_Field):
            t = self.expr_single(lhs.tab)
            tt = self.alloc_temp(1)
            self.emit(OP["MOVE"], tt, t, 0, line)
            k = self.const_str(lhs.field.encode())
            kk = self.alloc_temp(1)
            self.emit(OP["LOADK"], kk, k, 0, line)
            v = self.alloc_temp(1)
            self.emit(OP["GETTABLE"], v, tt, kk, line)
            r = self.expr_single(rhs)
            d = self.alloc_temp(1)
            self.emit_binop(op, d, v, r, line)
            self.emit(OP["SETTABLE"], tt, kk, d, line)
            return
        if isinstance(lhs, P.V_Index):
            t = self.expr_single(lhs.tab)
            tt = self.alloc_temp(1)
            self.emit(OP["MOVE"], tt, t, 0, line)
            k0 = self.expr_single(lhs.key)
            kk = self.alloc_temp(1)
            self.emit(OP["MOVE"], kk, k0, 0, line)
            v = self.alloc_temp(1)
            self.emit(OP["GETTABLE"], v, tt, kk, line)
            r = self.expr_single(rhs)
            d = self.alloc_temp(1)
            self.emit_binop(op, d, v, r, line)
            self.emit(OP["SETTABLE"], tt, kk, d, line)
            return
        raise CompileError(f"line {line}: bad compound target")

    # ---- control flow ----
    def stmt_while(self, cond, body, line):
        head = self.cur_pc()
        c = self.expr_single(cond)
        self.emit(OP["TEST"], c, 0, 1, line)
        j_end = self.emit_jump(OP["JMP"], 0, line)
        li = self.push_loop("while", head)
        m = self.open_scope()
        self.block_inner(body)
        self.close_scope(m)
        self.emit(OP["JMP"], 0, zz_off(self.cur_pc(), head) & 0xFFFFFFFF, 0, line)
        end = self.cur_pc()
        self.patch(j_end, end)
        self.pop_loop(li, end)

    def stmt_repeat(self, body, cond, line):
        li = self.push_loop("repeat", None)
        m = self.open_scope()
        head = self.cur_pc()
        for s in body.stmts:
            self.stmt(s)
            self.temp_reset()
        if body.ret is not None:
            self.do_return(body.ret, False)
        cond_pc = self.cur_pc()
        self.arena[self.fi()].loops[li]["cont"] = cond_pc
        for pc in self.arena[self.fi()].loops[li]["conts"][:]:
            self.patch(pc, cond_pc)
        self.arena[self.fi()].loops[li]["conts"] = []
        c = self.expr_single(cond)
        self.emit(OP["TEST"], c, 0, 0, line)
        self.emit(OP["JMP"], 0, zz_off(self.cur_pc(), head) & 0xFFFFFFFF, 0, line)
        # fix TEST to C=1 (see Rust comments): TEST c,1 skips JMP when truthy -> exit
        p = self.arena[self.fi()].proto
        self.protos[p].code[-2].c = 1
        end = self.cur_pc()
        self.pop_loop(li, end)
        self.close_scope(m)

    def stmt_if(self, arms, else_, line):
        ends = []
        for i, (c, b) in enumerate(arms):
            cv = self.expr_single(c)
            self.emit(OP["TEST"], cv, 0, 1, line)
            j_next = self.emit_jump(OP["JMP"], 0, line)
            m = self.open_scope()
            self.block_inner(b)
            self.close_scope(m)
            if i+1 < len(arms) or else_ is not None:
                ends.append(self.emit_jump(OP["JMP"], 0, line))
            self.patch(j_next, self.cur_pc())
        if else_ is not None:
            m = self.open_scope()
            self.block_inner(else_)
            self.close_scope(m)
        end = self.cur_pc()
        for pc in ends:
            self.patch(pc, end)

    def stmt_numfor(self, var, start, limit, step, body, line):
        saved = self.floor()
        a = self.alloc_temp(4)
        self.set_floor(a+4)
        s = self.expr_single(start)
        self.emit(OP["MOVE"], a, s, 0, line)
        l = self.expr_single(limit)
        self.emit(OP["MOVE"], a+1, l, 0, line)
        if step is not None:
            v = self.expr_single(step)
            self.emit(OP["MOVE"], a+2, v, 0, line)
        else:
            k = self.const_num(1.0)
            self.emit(OP["LOADK"], a+2, k, 0, line)
        self.emit(OP["FORPREP"], a, 0, 0, line)
        loop_pc = self.cur_pc()
        j_exit = self.emit_jump(OP["FORLOOP"], a, line)
        li = self.push_loop("numfor", loop_pc)
        m = self.open_scope()
        bx = self.decl_named(var, line)
        self.emit(OP["CAPTURE"], a+3, bx, 0, line)
        self.block_inner(body)
        self.close_scope(m)
        self.emit(OP["JMP"], 0, zz_off(self.cur_pc(), loop_pc) & 0xFFFFFFFF, 0, line)
        end = self.cur_pc()
        self.patch(j_exit, end)
        self.pop_loop(li, end)
        self.set_floor(saved)
        self.temp_reset()

    def stmt_genfor(self, names, iters, body, line):
        if not iters or len(iters) > 3:
            raise CompileError(f"line {line}: generic for needs 1-3 iterators")
        saved = self.floor()
        nv = max(len(names), 1)
        a = self.alloc_temp(3+nv)
        self.set_floor(a+3+nv)
        if len(iters) == 1:
            # Single iterator expression expands to (func, state, control),
            # e.g. `for k,v in pairs(t)` — pairs(t) returns 3 values.
            self.expr_fixed_multi(iters[0], a, 3)
        else:
            for i, e in enumerate(iters):
                r = self.expr_single(e)
                if r != a+i:
                    self.emit(OP["MOVE"], a+i, r, 0, line)
            for i in range(len(iters), 3):
                k = self.const_nil()
                self.emit(OP["LOADK"], a+i, k, 0, line)
        if len(iters) == 1:
            self.emit(OP["TFORPREP"], a, 0, 0, line)
        loop_pc = self.cur_pc()
        self.emit(OP["TFORCALL"], a, 0, nv, line)
        j_exit = self.emit_jump(OP["TFORLOOP"], a, line)
        li = self.push_loop("genfor", loop_pc)
        m = self.open_scope()
        bxs = []
        for nm in names:
            bxs.append(self.decl_named(nm, line))
        for i, bx in enumerate(bxs):
            self.emit(OP["CAPTURE"], a+3+i, bx, 0, line)
        self.block_inner(body)
        self.close_scope(m)
        self.emit(OP["JMP"], 0, zz_off(self.cur_pc(), loop_pc) & 0xFFFFFFFF, 0, line)
        end = self.cur_pc()
        self.patch(j_exit, end)
        self.pop_loop(li, end)
        self.set_floor(saved)
        self.temp_reset()

    def push_loop(self, kind, cont):
        fi = self.fi()
        self.arena[fi].loops.append({"kind": kind, "breaks": [], "conts": [], "cont": cont})
        return len(self.arena[fi].loops)-1

    def pop_loop(self, li, end):
        fi = self.fi()
        ctx = self.arena[fi].loops.pop(li)
        for pc in ctx["breaks"]:
            self.patch(pc, end)
        for pc in ctx["conts"]:
            self.patch(pc, ctx["cont"])

    # ---- funcs ----
    def stmt_funcdef(self, base, fields, method, body, line):
        import copy
        b2 = P.FuncBody(list(body.params), body.vararg, body.body, body.line)
        if method is not None:
            b2.params.insert(0, "self")
        tmp = self.alloc_temp(1)
        self.compile_closure_into(tmp, b2, line)
        if not fields and method is None:
            r = self.resolve_named(base, line)
            if r[0]=="own":
                self.emit(OP["SETUPVAL"], tmp, r[1], 0, line)
            elif r[0]=="up":
                self.emit(OP["SETUPVAL"], tmp, r[2], r[1], line)
            else:
                k = self.const_str(base.encode())
                self.emit(OP["SETGLOBAL"], tmp, k, 0, line)
        else:
            bt = self.expr_single(P.E_Var(P.V_Name(base), line))
            par = self.alloc_temp(1)
            self.emit(OP["MOVE"], par, bt, 0, line)
            if method is not None:
                for f in fields:
                    nx = self.alloc_temp(1)
                    k = self.const_str(f.encode())
                    kk = self.alloc_temp(1)
                    self.emit(OP["LOADK"], kk, k, 0, line)
                    self.emit(OP["GETTABLE"], nx, par, kk, line)
                    par = nx
                k = self.const_str(method.encode())
                kk = self.alloc_temp(1)
                self.emit(OP["LOADK"], kk, k, 0, line)
                self.emit(OP["SETTABLE"], par, kk, tmp, line)
            else:
                last = fields[-1]
                for f in fields[:-1]:
                    nx = self.alloc_temp(1)
                    k = self.const_str(f.encode())
                    kk = self.alloc_temp(1)
                    self.emit(OP["LOADK"], kk, k, 0, line)
                    self.emit(OP["GETTABLE"], nx, par, kk, line)
                    par = nx
                k = self.const_str(last.encode())
                kk = self.alloc_temp(1)
                self.emit(OP["LOADK"], kk, k, 0, line)
                self.emit(OP["SETTABLE"], par, kk, tmp, line)

    def stmt_localfunc(self, name, body, line):
        bx = self.decl_named(name, line)
        self.emit(OP["CAPNIL"], bx, 0, 0, line)
        tmp = self.alloc_temp(1)
        self.compile_closure_into(tmp, body, line)
        self.emit(OP["SETUPVAL"], tmp, bx, 0, line)

    def compile_closure_into(self, dest, body: P.FuncBody, line):
        me = self.fi()
        pi = len(self.protos)
        self.protos.append(Proto(nparams=len(body.params), vararg=body.vararg))
        parent_proto = self.arena[me].proto
        nf = Frame(me, pi, len(body.params), body.vararg)
        self.arena.append(nf)
        nf_idx = len(self.arena)-1
        self.frames.append(nf_idx)
        for i, p in enumerate(body.params):
            bx = self.decl_named(p, line)
            self.emit(OP["CAPTURE"], i, bx, 0, line)
        has_ret = body.body.ret is not None
        self.block(body.body, True)
        if not has_ret:
            self.emit(OP["RETURN"], 0, 1, 0, line)
        self.resolve_gotos(nf_idx, line)
        if self.arena[nf_idx].loops:
            raise CompileError(f"line {line}: unclosed loop")
        self.finish_frame(nf_idx)
        self.frames.pop()
        child = self.protos[pi]
        # reset dummy
        self.protos[pi] = Proto()
        self.protos[parent_proto].children.append(child)
        bx_idx = len(self.protos[parent_proto].children)-1
        self.emit(OP["CLOSURE"], dest, bx_idx, 0, line)

    # ---- expressions ----
    def expr_single(self, e):
        if isinstance(e, P.E_Call):
            return self.call_expr(e.func, e.args, e.line, want="one")
        if isinstance(e, P.E_Method):
            return self.method_call(e.obj, e.method, e.args, e.line, want="one")
        if isinstance(e, P.E_Vararg):
            if not self.arena[self.fi()].vararg:
                raise CompileError(f"line {e.line}: cannot use `...` outside vararg function")
            r = self.alloc_temp(2)
            self.emit(OP["VARARG"], r, 2, 0, e.line)
            return r
        return self.expr_value(e)

    def expr_fixed_multi(self, e, base, want):
        line = expr_line(e)
        if isinstance(e, P.E_Call):
            self.call_expr_at(e.func, e.args, line, base, want)
            return
        if isinstance(e, P.E_Method):
            self.method_call_at(e.obj, e.method, e.args, line, base, want)
            return
        if isinstance(e, P.E_Vararg):
            if not self.arena[self.fi()].vararg:
                raise CompileError(f"line {line}: cannot use `...` outside vararg")
            self.emit(OP["VARARG"], base, want+1, 0, line)
            return
        r = self.expr_single(e)
        if want == 0:
            return
        if r != base:
            self.emit(OP["MOVE"], base, r, 0, line)
        if want > 1:
            self.emit(OP["LOADNIL"], base+1, want-1, 0, line)

    def expr_multi(self, e, base):
        line = expr_line(e)
        if isinstance(e, P.E_Call):
            self.call_expr_multi(e.func, e.args, line, base)
            self.multi_flag = True
            return
        if isinstance(e, P.E_Method):
            self.method_call_multi(e.obj, e.method, e.args, line, base)
            self.multi_flag = True
            return
        if isinstance(e, P.E_Vararg):
            if not self.arena[self.fi()].vararg:
                raise CompileError(f"line {line}: cannot use `...` outside vararg")
            self.emit(OP["VARARG"], base, 0, 0, line)
            self.multi_flag = True
            return
        r = self.expr_single(e)
        if r != base:
            self.emit(OP["MOVE"], base, r, 0, line)
        self.multi_flag = False

    def expr_value(self, e):
        line = expr_line(e)
        if isinstance(e, P.E_Nil):
            k = self.const_nil()
            r = self.alloc_temp(1)
            self.emit(OP["LOADK"], r, k, 0, line)
            return r
        if isinstance(e, P.E_Bool):
            r = self.alloc_temp(1)
            self.emit(OP["LOADBOOL"], r, 1 if e.v else 0, 0, line)
            return r
        if isinstance(e, P.E_Num):
            k = self.const_num(e.v)
            r = self.alloc_temp(1)
            self.emit(OP["LOADK"], r, k, 0, line)
            return r
        if isinstance(e, P.E_Str):
            k = self.const_str(e.data)
            r = self.alloc_temp(1)
            self.emit(OP["LOADK"], r, k, 0, line)
            return r
        if isinstance(e, P.E_Interp):
            if not e.segs:
                k = self.const_str(b"")
                r = self.alloc_temp(1)
                self.emit(OP["LOADK"], r, k, 0, line)
                return r
            cur = None
            for kind, val in e.segs:
                if kind == "lit":
                    k = self.const_str(val)
                    r = self.alloc_temp(1)
                    self.emit(OP["LOADK"], r, k, 0, line)
                    part = r
                else:
                    part = self.expr_single(val)
                if cur is None:
                    cur = part
                else:
                    d = self.alloc_temp(1)
                    self.emit(OP["CONCAT"], d, cur, part, line)
                    cur = d
            # tostring() coercion happens in VM CONCAT via .. ; numbers auto-coerce. Good.
            return cur
        if isinstance(e, P.E_Var):
            return self.var_value(e.var, line)
        if isinstance(e, P.E_Table):
            return self.table_ctor(e.fields, line)
        if isinstance(e, P.E_Binop):
            op = e.op
            if op in ("and","or"):
                a = self.expr_single(e.l)
                t = self.alloc_temp(1)
                self.emit(OP["MOVE"], t, a, 0, line)
                cbit = 1 if op=="or" else 0
                self.emit(OP["TEST"], t, 0, cbit, line)
                j_dob = self.emit_jump(OP["JMP"], 0, line)
                j_done = self.emit_jump(OP["JMP"], 0, line)
                self.patch(j_dob, self.cur_pc())
                b = self.expr_single(e.r)
                self.emit(OP["MOVE"], t, b, 0, line)
                self.patch(j_done, self.cur_pc())
                return t
            if op in ("eq","ne","lt","ge","le","gt"):
                a = self.expr_single(e.l)
                b = self.expr_single(e.r)
                t = self.alloc_temp(1)
                cmap = {"eq":(OP["EQ"],1),"ne":(OP["EQ"],0),"lt":(OP["LT"],1),
                        "ge":(OP["LT"],0),"le":(OP["LE"],1),"gt":(OP["LE"],0)}[op]
                self.emit(cmap[0], cmap[1], a, b, line)
                j_f = self.emit_jump(OP["JMP"], 0, line)
                self.emit(OP["LOADBOOL"], t, 1, 0, line)
                j_d = self.emit_jump(OP["JMP"], 0, line)
                self.patch(j_f, self.cur_pc())
                self.emit(OP["LOADBOOL"], t, 0, 0, line)
                self.patch(j_d, self.cur_pc())
                return t
            a = self.expr_single(e.l)
            b = self.expr_single(e.r)
            d = self.alloc_temp(1)
            self.emit_binop(op, d, a, b, line)
            return d
        if isinstance(e, P.E_Unop):
            a = self.expr_single(e.e)
            d = self.alloc_temp(1)
            m = {"neg":OP["UNM"],"not":OP["NOT"],"len":OP["LEN"],"bnot":OP["BNOT"]}[e.op]
            self.emit(m, d, a, 0, line)
            return d
        if isinstance(e, P.E_Func):
            d = self.alloc_temp(1)
            self.compile_closure_into(d, e.body, expr_line(e))
            return d
        if isinstance(e, P.E_IfExpr):
            t = self.alloc_temp(1)
            k = self.const_nil()
            self.emit(OP["LOADK"], t, k, 0, line)
            ends = []
            for (c, v) in e.arms:
                cv = self.expr_single(c)
                self.emit(OP["TEST"], cv, 0, 1, line)
                jn = self.emit_jump(OP["JMP"], 0, line)
                vv = self.expr_single(v)
                self.emit(OP["MOVE"], t, vv, 0, line)
                ends.append(self.emit_jump(OP["JMP"], 0, line))
                self.patch(jn, self.cur_pc())
            ev = self.expr_single(e.else_)
            self.emit(OP["MOVE"], t, ev, 0, line)
            for pc in ends:
                self.patch(pc, self.cur_pc())
            return t
        if isinstance(e, (P.E_Call, P.E_Method, P.E_Vararg)):
            return self.expr_single(e)
        raise CompileError(f"line {line}: bad expr {e!r}")

    def emit_binop(self, op, d, a, b, line):
        m = {"add":OP["ADD"],"sub":OP["SUB"],"mul":OP["MUL"],"div":OP["DIV"],
             "mod":OP["MOD"],"pow":OP["POW"],"idiv":OP["IDIV"],"concat":OP["CONCAT"],
             "band":OP["BAND"],"bor":OP["BOR"],"bxor":OP["BXOR"],
             "shl":OP["SHL"],"shr":OP["SHR"]}[op]
        self.emit(m, d, a, b, line)

    def var_value(self, v, line):
        if isinstance(v, P.V_Name):
            d = self.alloc_temp(1)
            r = self.resolve_named(v.name, line)
            if r[0]=="own":
                self.emit(OP["GETUPVAL"], d, r[1], 0, line)
            elif r[0]=="up":
                self.emit(OP["GETUPVAL"], d, r[2], 1, line)
            else:
                k = self.const_str(v.name.encode())
                self.emit(OP["GETGLOBAL"], d, k, 0, line)
            return d
        if isinstance(v, P.V_Field):
            t = self.expr_single(v.tab)
            k = self.const_str(v.field.encode())
            kk = self.alloc_temp(1)
            self.emit(OP["LOADK"], kk, k, 0, line)
            d = self.alloc_temp(1)
            self.emit(OP["GETTABLE"], d, t, kk, line)
            return d
        if isinstance(v, P.V_Index):
            t = self.expr_single(v.tab)
            k = self.expr_single(v.key)
            d = self.alloc_temp(1)
            self.emit(OP["GETTABLE"], d, t, k, line)
            return d
        raise CompileError(f"line {line}: bad var")

    def table_ctor(self, fs, line):
        d = self.alloc_temp(1)
        self.emit(OP["NEWTABLE"], d, 0, 0, line)
        # array part buffering for SETLIST
        arr = []  # regs
        arr_start = 1  # 1-based for SETLIST C
        def flush():
            nonlocal arr, arr_start
            if not arr:
                return
            base = arr[0]
            # arr regs must be contiguous? They are if allocated sequentially for elems.
            # Our elems allocate temps scattered; instead emit individual SETTABLEs? Simpler & correct:
            # But for multret last-elem we need SETLIST. Handle: if last flush contains multret, use SETLIST.
            # Here flush() is for fixed elems only.
            for i, r in enumerate(arr):
                # t[arr_start+i-1] = r  -> use SETTABLE with key const? No, use SETLIST with Bo=1 each? SETLIST Bo=count,Co=start.
                pass
        # Simplest correct: emit per-element stores (hash + array alike), plus multret handling for last elem.
        n = len(fs)
        array_i = 1
        for idx, f in enumerate(fs):
            is_last = (idx+1==n)
            if isinstance(f, P.F_Rec):
                v = self.expr_single(f.val)
                k = self.const_str(f.key.encode())
                kk = self.alloc_temp(1)
                self.emit(OP["LOADK"], kk, k, 0, line)
                self.emit(OP["SETTABLE"], d, kk, v, line)
            elif isinstance(f, P.F_Idx):
                k = self.expr_single(f.key)
                if is_last:
                    # value could be multret? No — table values truncate to 1 (Lua). So single.
                    v = self.expr_single(f.val)
                else:
                    v = self.expr_single(f.val)
                self.emit(OP["SETTABLE"], d, k, v, line)
            else:  # elem
                if is_last:
                    # Multret expansion: CALL f() / VARARG as last elem expands.
                    # SETLIST expects values at R[d+1..top], so evaluate the
                    # multret directly into the d+1 window (only d is live here;
                    # earlier elem temps are dead after their SETTABLE).
                    import copy as _copy
                    v = f.val
                    if isinstance(v, (P.E_Call, P.E_Method, P.E_Vararg)):
                        base = d + 1
                        # ensure max_reg covers the window (informational only;
                        # the VM uses a dynamic table for R).
                        need = base + 2
                        cur = self.arena[self.fi()].max_reg
                        if need > cur:
                            self.arena[self.fi()].max_reg = need
                        self.expr_multi(v, base)
                        assert self.multi_flag
                        self.emit(OP["SETLIST"], d, 0, array_i, line)
                    else:
                        base = self.alloc_temp(1)
                        self.expr_multi(v, base)
                        assert not self.multi_flag
                        k = self.const_num(float(array_i))
                        kk = self.alloc_temp(1)
                        self.emit(OP["LOADK"], kk, k, 0, line)
                        self.emit(OP["SETTABLE"], d, kk, base, line)
                else:
                    v = self.expr_single(f.val)
                    k = self.const_num(float(array_i))
                    kk = self.alloc_temp(1)
                    self.emit(OP["LOADK"], kk, k, 0, line)
                    self.emit(OP["SETTABLE"], d, kk, v, line)
                array_i += 1
                # NOTE: array_i only counts Elem entries; Rec/Idx don't affect it. Above increments per elem only. Good.
                # But SETLIST C for multret case uses current array_i — correct.
        return d

    # --- concrete implementations (layout-first) ---
    def call_expr(self, func, args, line, want):
        f = self.expr_single(func)
        n = len(args)
        cb = self.alloc_temp(n + 3)
        self.emit(OP["MOVE"], cb, f, 0, line)
        # args into cb+1..
        B = self._emit_args_at(args, cb+1, line)
        if want == "one":
            self.emit(OP["CALL"], cb, B, 2, line)
            return cb
        if want == "none":
            self.emit(OP["CALL"], cb, B, 1, line)
            return cb
        if want == "tail":
            self.emit(OP["TAILCALL"], cb, B, 0, line)
            # unreachable; emit dummy return
            self.emit(OP["RETURN"], 0, 1, 0, line)
            return cb
        raise CompileError("bad want")

    def method_call(self, obj, method, args, line, want):
        o = self.expr_single(obj)
        k = self.const_str(method.encode())
        kk = self.alloc_temp(1)
        self.emit(OP["LOADK"], kk, k, 0, line)
        n = len(args)
        cb = self.alloc_temp(n + 4)
        self.emit(OP["SELF"], cb, o, kk, line)
        B = self._emit_args_at(args, cb+2, line)
        # SELF puts func at cb, obj at cb+1; args start at cb+2. CALL B counts args+1? No:
        # CALL A,B,C: func=R[A], args=R[A+1..A+B-1] (B==0 multret). With SELF, func=R[cb], self=R[cb+1], args=R[cb+2..].
        # Our B from _emit_args_at counts only explicit args. Total nargs = 1 + explicit (or multret).
        if B == 0:
            Bt = 0
        else:
            Bt = B + 1  # +self
        if want == "one":
            self.emit(OP["CALL"], cb, Bt, 2, line)
            return cb
        if want == "none":
            self.emit(OP["CALL"], cb, Bt, 1, line)
            return cb
        if want == "tail":
            self.emit(OP["TAILCALL"], cb, Bt, 0, line)
            self.emit(OP["RETURN"], 0, 1, 0, line)
            return cb
        raise CompileError("bad want")

    def _emit_args_at(self, args, base, line):
        # emit args into base.. ; return B (count+1) or 0 if multret (sets top)
        if not args:
            return 1
        n = len(args)
        for i, a in enumerate(args):
            if i+1 == n:
                self.expr_multi(a, base+i)
                if self.multi_flag:
                    return 0
            else:
                r = self.expr_single(a)
                if r != base+i:
                    self.emit(OP["MOVE"], base+i, r, 0, line)
        return n+1

    def call_expr_at(self, func, args, line, base, want):
        # want = fixed slot count; call with results into base..base+want-1 (nil-fill extras)
        f = self.expr_single(func)
        n = len(args)
        cb = self.alloc_temp(n + 3)
        self.emit(OP["MOVE"], cb, f, 0, line)
        B = self._emit_args_at(args, cb+1, line)
        if want == 0:
            self.emit(OP["CALL"], cb, B, 1, line)
            return
        # C = want+1 (results count+1); B as above
        self.emit(OP["CALL"], cb, B, want+1, line)
        # move results to base
        for i in range(want):
            self.emit(OP["MOVE"], base+i, cb+i, 0, line)

    def method_call_at(self, obj, method, args, line, base, want):
        o = self.expr_single(obj)
        k = self.const_str(method.encode())
        kk = self.alloc_temp(1)
        self.emit(OP["LOADK"], kk, k, 0, line)
        n = len(args)
        cb = self.alloc_temp(n + 4)
        self.emit(OP["SELF"], cb, o, kk, line)
        B0 = self._emit_args_at(args, cb+2, line)
        B = 0 if B0==0 else B0+1
        if want == 0:
            self.emit(OP["CALL"], cb, B, 1, line)
            return
        self.emit(OP["CALL"], cb, B, want+1, line)
        for i in range(want):
            self.emit(OP["MOVE"], base+i, cb+i, 0, line)

    def call_expr_multi(self, func, args, line, base):
        f = self.expr_single(func)
        n = len(args)
        # need func at base, args at base+1.. directly (multret: top set)
        self.emit(OP["MOVE"], base, f, 0, line)
        # careful: f might BE base? then move is self-move, harmless.
        B = self._emit_args_at(args, base+1, line)
        self.emit(OP["CALL"], base, B, 0, line)

    def method_call_multi(self, obj, method, args, line, base):
        o = self.expr_single(obj)
        k = self.const_str(method.encode())
        kk = self.alloc_temp(1)
        self.emit(OP["LOADK"], kk, k, 0, line)
        self.emit(OP["SELF"], base, o, kk, line)
        B0 = self._emit_args_at(args, base+2, line)
        B = 0 if B0==0 else B0+1
        self.emit(OP["CALL"], base, B, 0, line)

    def arg_b(self, args):
        # legacy helper (unused)
        return len(args)+1


def expr_line(e):
    for attr in ("line",):
        if hasattr(e, attr):
            v = getattr(e, attr)
            if isinstance(v, int):
                return v
    # recurse for wrappers
    if isinstance(e, P.E_Binop):
        return expr_line(e.l)
    if isinstance(e, P.E_Unop):
        return expr_line(e.e)
    if isinstance(e, P.E_Call):
        return e.line
    if isinstance(e, P.E_Method):
        return e.line
    if isinstance(e, P.E_Var):
        return e.line
    if isinstance(e, P.E_Table):
        return e.line
    if isinstance(e, P.E_Func):
        return e.body.line
    if isinstance(e, P.E_IfExpr):
        return e.line
    if isinstance(e, P.E_Vararg):
        return e.line
    return 1

def compile_block(block: P.Block) -> Proto:
    return Compiler().compile(block)
