#!/usr/bin/env python3
"""Acceptance tests for the v3 hardened builder.

- Fingerprint: no stock markers in output.
- Liveness: naive def-use DCE must retain >70% (junk not filterable).
- Tamper: flipping 1 segment char must fail closed (no partial output).
- Diversity: same input, different seeds -> byte diff >40%, dispatch
  order diff, wire/opaque numbers diff.
- Secrecy proxy for the LLM-reimplement test: user strings/numbers must
  not appear literally in output.
Run: python tests/acceptance_test.py
"""
import pathlib
import re
import sys

sys.path.insert(0, str(pathlib.Path(__file__).parent.parent))
from lupa import LuaRuntime
from src.api import obfuscate

STUB = (pathlib.Path(__file__).parent / "executor_stub.lua").read_text() + """
test_out = {}
print = function(...) local t={...}; local s={}; for i=1,select('#',...) do s[i]=tostring(select(i,...)) end; test_out[#test_out+1]=table.concat(s, '\\t') end
"""

SRC = pathlib.Path("example.lua").read_text(encoding="utf-8")


def run_ob(src, seed, preset="luraph15"):
    return obfuscate(src, seed=seed, preset=preset)


def run_lua(ob, budget=2000000):
    lua = LuaRuntime()
    lua.execute(STUB)
    # watchdog: abort runaway loops (tampered offsets can jump anywhere)
    lua.execute("local __n=0; debug.sethook(function() __n=__n+1; "
                "if __n>%d then error('timeout') end end, '', 10000)" % budget)
    try:
        lua.execute(ob)
    finally:
        try:
            lua.execute("debug.sethook()")
        except Exception:
            pass
    n = lua.eval("#test_out")
    return [lua.eval("test_out[%d]" % i) for i in range(1, n + 1)]


def t_fingerprint():
    ob = run_ob(SRC, 0xA11CE, "luraph15")
    pats = ["6a09e667", "428a2f98", "LVM2", "bad opcode", "bad chunk",
            "bb67ae85", "3c6ef372", "a54ff53a", "71374491", "b5c0fbcf"]
    hits = {p: ob.count(p) for p in pats if p in ob}
    # case-insensitive sweep for hex constants of stock SHA256
    low = ob.lower()
    for h in ("6a09e667", "bb67ae85", "3c6ef372", "a54ff53a", "510e527f",
              "9b05688c", "1f83d9ab", "5be0cd19", "428a2f98", "71374491"):
        if h in low and h not in hits:
            hits[h] = low.count(h)
    ok = not hits
    print(("PASS" if ok else "FAIL"), "fingerprint hits=%s" % (hits,))
    return ok


def naive_dce_retention():
    """Replicate builder transforms in Python and run a naive attacker's
    def-use DCE: drop NOPs, scratch-only chains (defs never reaching a
    real use), and trivial MOVE x,x / EQ-with-same-source tautologies.
    Retention must be >70% (junk survives because it touches live regs)."""
    from src import parser as P, compiler as C, encryptor as E
    block = P.parse(SRC)
    proto = C.Compiler().compile(block)
    params = E.derive_all(0xDCE, None)
    E.apply_transforms(proto, params, 3, False)

    total = 0
    kept = 0

    def regs_read(ins):
        return E._reads(ins)

    def regs_written(ins):
        return E._writes(ins)

    def walk(p):
        nonlocal total, kept
        # live-out: regs read by "real" code = regs read anywhere after
        # (conservative attacker under-approximates; we simulate the
        # attacker's best naive pass: iterate to fixpoint removing dead defs)
        code = list(p.code)
        live = set()
        # seed live with regs read by control ops + last-instr reads
        for ins in code:
            if ins.op in (27, 28, 29):
                live.update(regs_read(ins))
        # backward pass
        keep = [True] * len(code)
        live = set()
        for i in range(len(code) - 1, -1, -1):
            ins = code[i]
            w = regs_written(ins)
            r = regs_read(ins)
            if ins.op == 0:
                keep[i] = False
                continue
            if ins.op == 1 and ins.a == ins.b:
                keep[i] = False
                continue
            if w and not (w & live) and ins.op not in (27, 28, 29, 31, 39, 37, 33):
                # dead def (no side effects) -> attacker removes
                keep[i] = False
                continue
            live.update(r)
            live.update(w)
        for i, ins in enumerate(code):
            total += 1
            if keep[i]:
                kept += 1
        for ch in p.children:
            walk(ch)

    walk(proto)
    ratio = kept / max(total, 1)
    ok = ratio > 0.70
    print(("PASS" if ok else "FAIL"), "liveness retention=%.1f%% (%d/%d)" % (100 * ratio, kept, total))
    return ok


def t_tamper():
    ob = run_ob(SRC, 0x7A9, "luraph15")
    # flip one hex/digit char inside the first long segment literal
    m = re.search(r'"([0-9a-f]{200,})"', ob)
    if not m:
        m = re.search(r'"([0-9]{200,})"', ob)
    assert m, "no segment literal found"
    s = m.group(1)
    pos = len(s) // 2
    ch = s[pos]
    rep = "0" if ch != "0" else "1"
    bad = ob[:m.start(1) + pos] + rep + ob[m.start(1) + pos + 1:]
    try:
        out = run_lua(bad)
        print("FAIL tamper: tampered output ran Zan=%r" % (out,))
        return False
    except Exception as e:
        print("PASS tamper: flip rejected (%s: %s)" % (type(e).__name__, str(e)[:80]))
        return True


def handler_order(ob):
    # dispatch spec entries {{real,handler},...} in source order (spec is
    # shuffled per build; handlers are renamed so match on shape)
    spec = re.findall(r"\{(\d+),l[Ii][IiIl]{5,}\}", ob)
    if spec:
        return spec
    hs = re.findall(r"local function (__h_[a-z0-9_]+)", ob)
    if hs:
        return hs
    return re.findall(r"__(h_[a-z0-9_]+)", ob)


def byte_diff(a: str, b: str) -> float:
    """O(n) dissimilarity in [0,1]: aligned Hamming + length term."""
    n = min(len(a), len(b))
    if n == 0:
        return 1.0 if a != b else 0.0
    step = max(1, n // 20000)
    same = sum(1 for i in range(0, n, step) if a[i] == b[i])
    ham = 1.0 - same / ((n + step - 1) // step)
    lenterm = abs(len(a) - len(b)) / max(len(a), len(b), 1)
    return 0.8 * ham + 0.2 * lenterm


def t_diversity():
    a = run_ob(SRC, 111, "luraph15")
    b = run_ob(SRC, 222, "luraph15")
    assert a != b, "identical outputs for different seeds"
    diff = byte_diff(a, b)
    ha, hb = handler_order(a), handler_order(b)
    order_diff = (ha != hb)
    # opcode numbers: wire width + first segment bytes differ
    print("diversity diff=%.1f%% handler_order_diff=%s" % (100 * diff, order_diff))
    ok = diff > 0.40 and order_diff and len(a) > 10000 and len(b) > 10000
    print(("PASS" if ok else "FAIL"), "diversity")
    return ok


def t_secrecy():
    ob = run_ob(SRC, 0xBEEF, "luraph15")
    leaks = [s for s in ("Alice", "Bob", "Charlie", "Hello") if s in ob]
    ok = not leaks
    print(("PASS" if ok else "FAIL"), "secrecy leaks=%s" % (leaks,))
    # functional check: output still runs correctly
    out = run_lua(ob)
    exp = ["Hello, Alice! (#1)", "Hello, Bob! (#2)", "Hello, Charlie! (#3)",
           "counter=85", "5+7=12"]
    ok2 = out == exp
    print(("PASS" if ok2 else "FAIL"), "functional %r" % (out,))
    return ok and ok2


def main():
    results = [
        ("fingerprint", t_fingerprint()),
        ("liveness", naive_dce_retention()),
        ("tamper", t_tamper()),
        ("diversity", t_diversity()),
        ("secrecy+functional", t_secrecy()),
    ]
    fails = sum(1 for _, ok in results if not ok)
    print("%d failures / %d acceptance tests" % (fails, len(results)))
    sys.exit(1 if fails else 0)


if __name__ == "__main__":
    main()
