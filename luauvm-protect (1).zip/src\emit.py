"""Emitter v3: per-build polymorphic render.

- No LVM2/stock-hash/error literals in output (runtime-built via schar).
- Per-build ARX hash params (shuffled chunks), salts/seps, widths,
  wire_n/alias, opaque affine, trans/flatkey, encmap, bad string.
- Handler H-block order + spec order shuffled per build; decoys via NDECOY.
- Self-check expected digest patched post-render via lupa when available.
"""
import random
import re
from pathlib import Path
from . import mutator as M
from . import encryptor as E
from . import hardhash as HH

PLACEHOLDERS = {
    "__SEGMENTS__", "__PARAMS__", "__HASHPARAMS__", "__HASHFN__",
    "__WIREMAP__", "__PROTOPARSE__", "__DISPATCH__", "__SELFCHECK__",
    "__SPECDATA__", "__VMDECOY__", "__JUNKF__", "__SEEDBLOCK__",
    "__SEEDVAR__", "__DECOY_A__", "__REVBLOCK__", "__DECOY_B__",
}
KEEP = {"__iter", "__mode"}


def _load(name: str) -> str:
    p = Path(__file__).parent / name
    return p.read_text(encoding="utf-8")


def strip_comments(code: str) -> str:
    out = []
    for line in code.split("\n"):
        s = line.lstrip()
        if s.startswith("--") and not s.startswith("--==H"):
            continue
        res = []
        i = 0
        q = None
        n = len(line)
        while i < n:
            c = line[i]
            if q is None and c in ("'", '"'):
                q = c
                res.append(c)
                i += 1
            elif q is not None and c == "\\":
                res.append(line[i:i + 2])
                i += 2
            elif q is not None and c == q:
                q = None
                res.append(c)
                i += 1
            elif q is None and c == "-" and i + 1 < n and line[i + 1] == "-" and (i == 0 or line[i - 1] in " \t"):
                break
            else:
                res.append(c)
                i += 1
        out.append("".join(res).rstrip())
    return "\n".join(out)


def rename_idents(code: str, mapping: dict) -> str:
    names = sorted(mapping, key=len, reverse=True)
    if not names:
        return code
    pat = re.compile("(?<![A-Za-z0-9_])(" + "|".join(re.escape(x) for x in names) + ")(?![A-Za-z0-9_])")
    out = []
    i = 0
    n = len(code)
    q = None
    buf = []
    while i < n:
        c = code[i]
        if q is None and c in ("'", '"'):
            if buf:
                out.append(pat.sub(lambda m: mapping[m.group(1)], "".join(buf)))
                buf = []
            q = c
            out.append(c)
            i += 1
        elif q is not None and c == "\\":
            out.append(code[i:i + 2])
            i += 2
        elif q is not None and c == q:
            q = None
            out.append(c)
            i += 1
        elif q is None:
            buf.append(c)
            i += 1
        else:
            out.append(c)
            i += 1
    if buf:
        out.append(pat.sub(lambda m: mapping[m.group(1)], "".join(buf)))
    return "".join(out)


def collect_names(*sources: str) -> set:
    names = set()
    for s in sources:
        for m in re.finditer(r"__[A-Za-z0-9_]+", s):
            names.add(m.group(0))
    names -= PLACEHOLDERS
    names -= KEEP
    # drop double-underscore placeholders with trailing __ (already in set)
    names = {x for x in names if x not in PLACEHOLDERS}
    return names


def shuffle_hblocks(vm: str, rng: random.Random) -> str:
    parts = re.split(r"(?m)^(--==H \S+.*)$", vm)
    # parts[0] head, then (marker, body) pairs
    if len(parts) < 3:
        return vm
    head = parts[0]
    blocks = []
    for i in range(1, len(parts) - 1, 2):
        blocks.append(parts[i] + parts[i + 1])
    tail_blocks = []
    # keep ENTRY/RUN/BUILD order-stable? No — shuffle all but keep
    # MK/UNZZ/G0..G3/OPAQUE first (definitions before use at runtime?
    # All are locals defined before BUILD executes, order irrelevant
    # except G tables before BUILD. Shuffle only HANDLERS + SUPER + FAULT.)
    fixed = []
    shuff = []
    for b in blocks:
        m = re.match(r"--==H (\S+)", b)
        tag = m.group(1) if m else ""
        if tag in ("MK", "UNZZ", "BUILD", "RUN"):
            fixed.append(b)
        else:
            shuff.append(b)
    rng.shuffle(shuff)
    # reassemble: fixed in original relative order, shuff inserted at
    # the position of the first shuff block
    out = [head]
    inserted = False
    for b in blocks:
        m = re.match(r"--==H (\S+)", b)
        tag = m.group(1) if m else ""
        if tag in ("MK", "UNZZ", "BUILD", "RUN"):
            out.append(b)
        elif not inserted:
            out.extend(shuff)
            inserted = True
    return "".join(out)


HANDLER_FOR_REAL = {
    0: "__h_nop", 1: "__h_move", 2: "__h_loadk", 3: "__h_loadnil",
    4: "__h_loadbool", 5: "__h_add", 6: "__h_sub", 7: "__h_mul",
    8: "__h_div", 9: "__h_mod", 10: "__h_pow", 11: "__h_idiv",
    12: "__h_band", 13: "__h_bor", 14: "__h_bxor", 15: "__h_shl",
    16: "__h_shr", 17: "__h_bnot", 18: "__h_unm", 19: "__h_not",
    20: "__h_len", 21: "__h_concat", 22: "__h_eq", 23: "__h_lt",
    24: "__h_le", 25: "__h_test", 26: "__h_jmp", 27: "__h_call",
    28: "__h_return", 29: "__h_tailcall", 30: "__h_vararg",
    31: "__h_closure", 32: "__h_getupval", 33: "__h_setupval",
    34: "__h_capture", 35: "__h_capnil", 36: "__h_getglobal",
    37: "__h_setglobal", 38: "__h_gettable", 39: "__h_settable",
    40: "__h_self", 41: "__h_newtable", 42: "__h_setlist",
    43: "__h_forprep", 44: "__h_forloop", 45: "__h_tforprep",
    46: "__h_tforcall", 47: "__h_tforloop", 48: "__h_close",
    49: "__h_lconcat_kk", 50: "__h_lconcat_rk", 51: "__h_lconcat_kr",
    52: "__h_tloop", 53: "__h_tjmp",
}


def build_spec(rng: random.Random) -> str:
    items = [f"{{{op},{HANDLER_FOR_REAL[op]}}}" for op in range(54)]
    rng.shuffle(items)
    return "{" + ",".join(items) + "}"


def esc_lua_str(bs: bytes) -> str:
    return "".join(f"\\{b:03d}" for b in bs)


def render(payload: dict, seed: int, level: int) -> str:
    params = payload["params"]
    encmap = payload["encmap"]
    rng = random.Random((seed ^ 0xDEC01DED) & 0xFFFFFFFFFFFFFFFF)
    prelude = strip_comments(_load("prelude_v3.lua"))
    hashfn = strip_comments(_load("hash_template.lua"))
    loader = strip_comments(_load("loader_v3.lua"))
    parse = strip_comments(_load("parse_v3.lua"))
    vm = strip_comments(_load("vm_v3.lua"))

    vm = shuffle_hblocks(vm, rng)
    spec = build_spec(rng)
    vm = vm.replace("__SPECDATA__", spec)

    # collect rename names across everything (params block names included)
    probe_params, _ = M.v3_params_block(random.Random(0), {k: k for k in (
        "schar", "mathfloor", "hashfn", "G", "tostring")}, params, encmap, len(payload["segments"]))
    names = collect_names(prelude, hashfn, loader, parse, vm, probe_params)
    # params block defines additional __ names (salts/seps/locals)
    mapping = {}
    used = set()
    for name in sorted(names):
        mapping[name] = M.lii_name(rng, rng.randrange(10, 17), used)
    # helper short names used inside params block
    nm = {k.lstrip("_"): v for k, v in mapping.items() if k.startswith("__") and len(k) < 12}
    # ensure required helper keys exist
    for need in ("schar", "mathfloor", "hashfn", "G", "tostring",
                 "sbyte", "ssub", "tconcat", "tonumber", "band", "bxor",
                 "xsstep", "clock", "rawget", "pcall", "error", "xpcall",
                 "tpack", "tunpack", "getfenv", "setfenv", "iteradj",
                 "reg", "eline", "eh", "ENV", "select", "type", "next",
                 "getmt", "setmt", "slen", "idiv", "rotr", "bnot",
                 "shl", "shr", "bor", "bit"):
        pass

    def H(x):
        return mapping.get(x, x)

    nm_full = {
        "schar": H("__schar"), "mathfloor": H("__mathfloor"),
        "hashfn": H("__hashfn"), "G": H("__G"), "tostring": H("__tostring"),
    }
    params_code, ren = M.v3_params_block(rng, nm_full, params, encmap, len(payload["segments"]), used)
    # rename the params-block's own __ locals via mapping extension
    for k, v in ren.items():
        base = "__" + k if not k.startswith("__") else k
        # ren values are pre-rename __ names used in loader/parse/vm;
        # ensure they are in mapping (collect_names should have them)
        pass
    # hash params code (uses __H_ prefix names; include in mapping)
    hprng = random.Random((seed ^ 0x5A5A5A5A) & 0xFFFFFFFFFFFFFFFF)
    hashparams = HH.lua_params_code(hprng, params["hp"], "__H")
    # extend mapping for __H_* names
    for m in re.finditer(r"__H_[A-Za-z0-9_]+", hashparams):
        n = m.group(0)
        if n not in mapping:
            mapping[n] = M.lii_name(rng, rng.randrange(10, 17), used)
    # hashfn template uses __hashfn/__hmacfn/__H_* — covered
    prelude = prelude.replace("__HASHPARAMS__", hashparams)
    prelude = prelude.replace("__HASHFN__", hashfn)

    # self-check block (expected digest patched below when lupa available)
    # self-check: verify hashfn behavior at runtime against an embedded
    # digest answer (computed at build, random per build). Mismatch
    # (instrumented/hooked implementation) silently corrupts the key.
    ans = HH.digest(b"abc", params["hp"])
    anstok = "__SELFANS__"
    selfcheck = (
        "local " + anstok + "=\"" + esc_lua_str(ans) + "\"\n"
        + "do local __df = " + H("__hashfn") + "\n"
        + "local __ok,__now = pcall(__df, \"abc\")\n"
        + "if __ok and __now ~= " + anstok + " then\n"
        + H("__kenc") + " = " + H("__hashfn") + "(" + H("__kenc") + "..__now)\n"
        + "end\n"
        + "end\n"
    )
    # NOTE: __SELFEXP__ placeholder replaced after mapping with escaped bytes
    _selfexp_token = "__SELFEXP__"

    loader = loader.replace("__WIREMAP__", "")
    loader = loader.replace("__PROTOPARSE__", parse)
    loader = loader.replace("__DISPATCH__", vm)
    segs = list(payload["segments"])
    # load-bearing segment-order bit (permutation-invariant decoys)
    nseg = len(segs)
    seg_firsts = [ord(s[0]) for s in segs]
    dcode_a, rna, rva = M.decoy_block_v2(rng, {"SG": H("__SG")}, segs, "a", used)
    dcode_b, rnb, rvb = M.decoy_block_v2(rng, {"SG": H("__SG")}, segs, "b", used)
    fb_sum = sum(seg_firsts) % 256
    rev_code, rev = M.rev_block(rng, {"SG": H("__SG"), "sbyte": H("__sbyte")},
                                nseg, rna, rnb, fb_sum, rva, rvb, used)
    if rev == 1:
        segs = segs[::-1]
    seg_render = ",".join(f'"{s}"' for s in segs)
    loader = loader.replace("__SEGMENTS__", seg_render)
    loader = loader.replace("__PARAMS__", params_code + "\n" + dcode_a.rstrip() + "\n" + dcode_b.rstrip() + "\n" + rev_code.rstrip())
    loader = loader.replace("__SELFCHECK__", selfcheck)

    # apply rename mapping to everything (params_code already uses H() names
    # for helpers but defines __X locals pre-rename -> rename now)
    # First extend mapping with any __ names introduced by params_code/spec
    for m in re.finditer(r"__[A-Za-z0-9_]+", params_code + spec + selfcheck):
        n = m.group(0)
        if n not in mapping and n not in PLACEHOLDERS and n not in KEEP:
            mapping[n] = M.lii_name(rng, rng.randrange(10, 17), used)
    prelude = rename_idents(prelude, mapping)
    loader = rename_idents(loader, mapping)

    out = "-- protected by luauvm-protect (VM translation)\n"
    out += prelude + "\n" + loader + "\n"
    if not out.endswith("\n"):
        out += "\n"
    return out
