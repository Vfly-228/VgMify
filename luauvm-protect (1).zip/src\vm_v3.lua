--==H MK
local function __mkclosure(P, U)
    local f = function(...)
        return __runvm(P, U, ...)
    end
    __reg[f] = { P, U }
    return f
end

--==H UNZZ
local function __unzz(x)
    local q = __mathfloor(x / 2)
    if x % 2 == 1 then return -q - 1 else return q end
end

--==H HANDLERS
local function __h_nop(vm, A, Bo, Co) end

local function __h_move(vm, A, Bo, Co)
    vm.R[A] = vm.R[Bo]
end

local function __h_loadk(vm, A, Bo, Co)
    local e = vm.K[Bo + 1]
    if __type(e) == "table" then vm.R[A] = __kget(e, __kcon) else vm.R[A] = e end
end

local function __h_loadnil(vm, A, Bo, Co)
    for i = A, A + Bo - 1 do vm.R[i] = nil end
end

local function __h_loadbool(vm, A, Bo, Co)
    vm.R[A] = Bo ~= 0
    if Co ~= 0 then vm.pc = vm.pc + 1 end
end

local function __h_add(vm, A, Bo, Co) vm.R[A] = vm.R[Bo] + vm.R[Co] end
local function __h_sub(vm, A, Bo, Co) vm.R[A] = vm.R[Bo] - vm.R[Co] end
local function __h_mul(vm, A, Bo, Co) vm.R[A] = vm.R[Bo] * vm.R[Co] end
local function __h_div(vm, A, Bo, Co) vm.R[A] = vm.R[Bo] / vm.R[Co] end
local function __h_mod(vm, A, Bo, Co) vm.R[A] = vm.R[Bo] % vm.R[Co] end
local function __h_pow(vm, A, Bo, Co) vm.R[A] = vm.R[Bo] ^ vm.R[Co] end
local function __h_idiv(vm, A, Bo, Co) vm.R[A] = __idiv(vm.R[Bo], vm.R[Co]) end
local function __h_band(vm, A, Bo, Co) vm.R[A] = __band(vm.R[Bo], vm.R[Co]) end
local function __h_bor(vm, A, Bo, Co) vm.R[A] = __bor(vm.R[Bo], vm.R[Co]) end
local function __h_bxor(vm, A, Bo, Co) vm.R[A] = __bxor(vm.R[Bo], vm.R[Co]) end
local function __h_shl(vm, A, Bo, Co) vm.R[A] = __shl(vm.R[Bo], vm.R[Co]) end
local function __h_shr(vm, A, Bo, Co) vm.R[A] = __shr(vm.R[Bo], vm.R[Co]) end
local function __h_bnot(vm, A, Bo, Co) vm.R[A] = __bnot(vm.R[Bo]) end
local function __h_unm(vm, A, Bo, Co) vm.R[A] = -vm.R[Bo] end
local function __h_not(vm, A, Bo, Co) vm.R[A] = not vm.R[Bo] end
local function __h_len(vm, A, Bo, Co) vm.R[A] = #vm.R[Bo] end

local function __h_concat(vm, A, Bo, Co)
    vm.R[A] = vm.R[Bo] .. vm.R[Co]
end

local function __h_eq(vm, A, Bo, Co)
    if ((vm.R[Bo] == vm.R[Co]) == (A == 1)) then vm.pc = vm.pc + 1 end
end
local function __h_lt(vm, A, Bo, Co)
    if ((vm.R[Bo] < vm.R[Co]) == (A == 1)) then vm.pc = vm.pc + 1 end
end
local function __h_le(vm, A, Bo, Co)
    if ((vm.R[Bo] <= vm.R[Co]) == (A == 1)) then vm.pc = vm.pc + 1 end
end
local function __h_test(vm, A, Bo, Co)
    if ((vm.R[A] and true or false) == (Co ~= 0)) then vm.pc = vm.pc + 1 end
end
local function __h_jmp(vm, A, Bo, Co)
    vm.pc = vm.pc + __unzz(Bo)
end

local function __h_call(vm, A, Bo, Co)
    local func = vm.R[A]
    local nargs
    if Bo == 0 then
        nargs = vm.top - A
        if nargs < 0 then nargs = 0 end
    else
        nargs = Bo - 1
    end
    local args = {}
    for i = 1, nargs do args[i] = vm.R[A + i] end
    if Co == 0 then
        local res = __tpack(func(__tunpack(args, 1, nargs)))
        vm.top = A + res.n - 1
        for i = 1, res.n do vm.R[A + i - 1] = res[i] end
    elseif Co == 1 then
        func(__tunpack(args, 1, nargs))
    else
        local res = __tpack(func(__tunpack(args, 1, nargs)))
        for i = 1, Co - 1 do vm.R[A + i - 1] = res[i] end
    end
end

local function __h_return(vm, A, Bo, Co)
    vm.done = true
    if Bo == 0 then
        local n = vm.top - A + 1
        if n <= 0 then vm.ret = { n = 0 } return end
        local r = { n = n }
        for i = 1, n do r[i] = vm.R[A + i - 1] end
        vm.ret = r
    elseif Bo == 1 then
        vm.ret = { n = 0 }
    else
        local r = { n = Bo - 1 }
        for i = 1, Bo - 1 do r[i] = vm.R[A + i - 1] end
        vm.ret = r
    end
end

local function __h_tailcall(vm, A, Bo, Co)
    local func = vm.R[A]
    local nargs
    if Bo == 0 then
        nargs = vm.top - A
        if nargs < 0 then nargs = 0 end
    else
        nargs = Bo - 1
    end
    local args = {}
    for i = 1, nargs do args[i] = vm.R[A + i] end
    local entry = __reg[func]
    if entry == nil then
        vm.done = true
        local r = __tpack(func(__tunpack(args, 1, nargs)))
        vm.ret = r
        return
    end
    local P = entry[1]
    local UX = entry[2]
    vm.P = P
    vm.UX = UX
    vm.R = {}
    vm.BX = {}
    vm.code = P.code
    vm.K = P.consts
    vm.L = P.lines
    vm.nparams = P.nparams
    for i = 1, vm.nparams do vm.R[i - 1] = args[i] end
    local nva = nargs - vm.nparams
    if nva < 0 then nva = 0 end
    vm.VA = { n = nva }
    for i = 1, nva do vm.VA[i] = args[vm.nparams + i] end
    vm.top = 0
    vm.pc = 1
end

local function __h_vararg(vm, A, Bo, Co)
    if Bo == 0 then
        for i = 1, vm.VA.n do vm.R[A + i - 1] = vm.VA[i] end
        vm.top = A + vm.VA.n - 1
    else
        for i = 1, Bo - 1 do vm.R[A + i - 1] = vm.VA[i] end
    end
end

local function __h_closure(vm, A, Bo, Co)
    local child = vm.P.children[Bo + 1]
    local boxes = {}
    local descs = child.uv
    for i = 1, #descs do
        local d = descs[i]
        if d[1] == 0 then boxes[i] = vm.BX[d[2] + 1] else boxes[i] = vm.UX[d[2] + 1] end
    end
    vm.R[A] = __mkclosure(child, boxes)
end

local function __h_getupval(vm, A, Bo, Co)
    if Co == 0 then vm.R[A] = vm.BX[Bo + 1].v else vm.R[A] = vm.UX[Bo + 1].v end
end
local function __h_setupval(vm, A, Bo, Co)
    if Co == 0 then vm.BX[Bo + 1].v = vm.R[A] else vm.UX[Bo + 1].v = vm.R[A] end
end
local function __h_capture(vm, A, Bo, Co)
    vm.BX[Bo + 1] = { v = vm.R[A] }
end
local function __h_capnil(vm, A, Bo, Co)
    vm.BX[A + 1] = {}
end

local function __h_getglobal(vm, A, Bo, Co)
    local e = vm.K[Bo + 1]
    local name = e
    if __type(e) == "table" then name = __kget(e, __kcon) end
    local v = __ENV[name]
    if v == nil then
        if name == "getfenv" then v = __getfenv
        elseif name == "setfenv" then v = __setfenv end
    end
    vm.R[A] = v
end
local function __h_setglobal(vm, A, Bo, Co)
    local e = vm.K[Bo + 1]
    if __type(e) == "table" then __ENV[__kget(e, __kcon)] = vm.R[A] else __ENV[e] = vm.R[A] end
end
local function __h_gettable(vm, A, Bo, Co)
    vm.R[A] = vm.R[Bo][vm.R[Co]]
end
local function __h_settable(vm, A, Bo, Co)
    vm.R[A][vm.R[Bo]] = vm.R[Co]
end
local function __h_self(vm, A, Bo, Co)
    vm.R[A + 1] = vm.R[Bo]
    vm.R[A] = vm.R[Bo][vm.R[Co]]
end
local function __h_newtable(vm, A, Bo, Co)
    vm.R[A] = {}
end
local function __h_setlist(vm, A, Bo, Co)
    local t = vm.R[A]
    if Bo == 0 then
        local n = vm.top - A
        for i = 1, n do t[Co + i - 1] = vm.R[A + i] end
    else
        for i = 1, Bo do t[Co + i - 1] = vm.R[A + i] end
    end
end
local function __h_forprep(vm, A, Bo, Co)
    vm.R[A] = vm.R[A] - vm.R[A + 2]
end
local function __h_forloop(vm, A, Bo, Co)
    local st = vm.R[A] + vm.R[A + 2]
    vm.R[A] = st
    local lim = vm.R[A + 1]
    local step = vm.R[A + 2]
    local go
    if step > 0 then go = st <= lim else go = lim <= st end
    if go then vm.R[A + 3] = st else vm.pc = vm.pc + __unzz(Bo) end
end
local function __h_tforprep(vm, A, Bo, Co)
    if __type(vm.R[A]) ~= "function" then
        vm.R[A], vm.R[A + 1], vm.R[A + 2] = __iteradj(vm.R[A])
    end
end
local function __h_tforcall(vm, A, Bo, Co)
    local res = __tpack(vm.R[A](vm.R[A + 1], vm.R[A + 2]))
    for i = 1, Co do vm.R[A + 2 + i] = res[i] end
end
local function __h_tforloop(vm, A, Bo, Co)
    if vm.R[A + 3] == nil then vm.pc = vm.pc + __unzz(Bo) else vm.R[A + 2] = vm.R[A + 3] end
end
local function __h_close(vm, A, Bo, Co) end

--==H SUPER
local function __h_lconcat_kk(vm, A, Bo, Co)
    local e1 = vm.K[Bo + 1]
    local e2 = vm.K[Co + 1]
    local s1 = e1
    local s2 = e2
    if __type(e1) == "table" then s1 = __kget(e1, __kcon) end
    if __type(e2) == "table" then s2 = __kget(e2, __kcon) end
    vm.R[A] = s1 .. s2
end
local function __h_lconcat_rk(vm, A, Bo, Co)
    local e2 = vm.K[Co + 1]
    local s2 = e2
    if __type(e2) == "table" then s2 = __kget(e2, __kcon) end
    vm.R[A] = vm.R[Bo] .. s2
end
local function __h_lconcat_kr(vm, A, Bo, Co)
    local e1 = vm.K[Bo + 1]
    local s1 = e1
    if __type(e1) == "table" then s1 = __kget(e1, __kcon) end
    vm.R[A] = s1 .. vm.R[Co]
end
local function __h_tloop(vm, A, Bo, Co)
    local res = __tpack(vm.R[A](vm.R[A + 1], vm.R[A + 2]))
    for i = 1, Co do vm.R[A + 2 + i] = res[i] end
    if vm.R[A + 3] == nil then vm.pc = vm.pc + __unzz(Bo) else vm.R[A + 2] = vm.R[A + 3] end
end
local function __h_tjmp(vm, A, Bo, Co)
    if ((vm.R[A] and true or false) == (Co ~= 0)) then
    else vm.pc = vm.pc + __unzz(Bo) end
end

--==H BUILD
-- Direct dispatch: spec stays shuffled per build (diversity), but the VM
-- indexes handlers in one table lookup. The threaded 4-group dispatcher
-- (opaque ids + TRANS state + fallback scan + fault decoys) cost ~10 Lua
-- ops per instruction and extra template/params size for no load-bearing
-- security (wire permutation + per-build keys remain).
local __spec = __SPECDATA__
local __dispatch = {}
for __si = 1, #__spec do
    local __e = __spec[__si]
    __dispatch[__e[1]] = __e[2]
end

--==H RUN
function __runvm(P, UX, ...)
    local vm = {}
    vm.R = {}
    vm.BX = {}
    vm.VA = __tpack(...)
    vm.top = 0
    vm.P = P
    vm.UX = UX
    vm.nparams = P.nparams
    for __pi = 1, vm.nparams do vm.R[__pi - 1] = vm.VA[__pi] end
    vm.code = P.code
    vm.K = P.consts
    vm.L = P.lines
    vm.pc = 1
    vm.done = false
    while true do
        local I = vm.code[vm.pc]
        local op = I[1]
        local A = I[2]
        local Bo = I[3]
        local Co = I[4]
        vm.pc = vm.pc + 1
        __eline = vm.L[vm.pc - 1]
        if vm.done then break end
        local __h = __dispatch[op]
        if __h == nil then __error(__bad) end
        __h(vm, A, Bo, Co)
        if vm.done then
            if vm.ret == nil then return end
            if vm.ret.n == 0 then return end
            return __tunpack(vm.ret, 1, vm.ret.n)
        end
    end
end
