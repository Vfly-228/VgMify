"""Luau lexer: tokenizes source without regex transforms.
Handles comments, strings, backtick interpolation, numbers, idents, symbols.
Type annotations are handled by the parser (stripped, not regex-replaced).
"""
from dataclasses import dataclass
from typing import List, Optional

KEYWORDS = {
    "and","break","do","else","elseif","end","false","for","function","goto",
    "if","in","local","nil","not","or","repeat","return","then","true",
    "until","while","continue","type","export","self",
}

@dataclass
class Tok:
    kind: str   # 'eof','ident','kw','num','str','interp','sym'
    val: str
    line: int
    col: int
    # for strings: raw bytes
    data: Optional[bytes] = None
    # for numbers: float value + raw
    num: Optional[float] = None

class LexError(Exception):
    pass

class Lexer:
    def __init__(self, src: str):
        self.src = src
        self.n = len(src)
        self.i = 0
        self.line = 1
        self.col = 1

    def peek(self, k=0):
        j = self.i + k
        if j >= self.n:
            return "\0"
        return self.src[j]

    def adv(self, k=1):
        for _ in range(k):
            if self.i >= self.n:
                return
            c = self.src[self.i]
            self.i += 1
            if c == "\n":
                self.line += 1
                self.col = 1
            else:
                self.col += 1

    def error(self, msg):
        raise LexError(f"lex error at {self.line}:{self.col}: {msg}")

    def tokenize(self) -> List[Tok]:
        out: List[Tok] = []
        while True:
            t = self.next_tok()
            out.append(t)
            if t.kind == "eof":
                break
        return out

    def skip_space_comments(self):
        while True:
            c = self.peek()
            if c in " \t\r\n":
                self.adv()
            elif c == "-" and self.peek(1) == "-":
                # comment
                self.adv(2)
                if self.peek() == "[" and self.peek(1) == "[":
                    # long comment --[[ ]]
                    self.adv(2)
                    # check for = signs: --[=[ etc
                    # simplified: find closing ]]
                    # handle level
                    # rewind: we consumed '--[[' already; need level detection
                    # redo properly:
                    pass
                # Actually handle long comments properly:
                # (we already consumed '--'; check long bracket)
                # To keep simple, re-handle: step back is messy, so handle below.
                # Instead: consume until end of line unless long bracket.
                # We need to detect long bracket: after '--', if '[' *n + '[' then long.
                # Since we consumed '--', peek is '[' or '='...
                # Simplify: scan for long bracket open.
                # Undo: easiest is to check before consuming. Rework:
                break
            else:
                break

    def next_tok(self) -> Tok:
        # manual skip (with proper long-comment handling)
        while True:
            c = self.peek()
            if c == "\0":
                return Tok("eof", "", self.line, self.col)
            if c in " \t\r\n":
                self.adv()
                continue
            if c == "-" and self.peek(1) == "-":
                # comment
                # check long bracket
                j = self.i + 2
                level = 0
                while j < self.n and self.src[j] == "=":
                    level += 1
                    j += 1
                if j < self.n and self.src[j] == "[" and j+1 < self.n and self.src[j+1] == "[":
                    # long comment
                    self.i = j + 2
                    # update col approx (no newlines counted precisely here; fix by scanning)
                    # scan for close
                    close = "]" + ("="*level) + "]"
                    # find
                    k = self.src.find(close, self.i)
                    if k < 0:
                        self.error("unfinished long comment")
                    # count lines
                    seg = self.src[self.i:k]
                    self.line += seg.count("\n")
                    if "\n" in seg:
                        self.col = len(seg.rsplit("\n",1)[1]) + 1
                    else:
                        self.col += (k + len(close) - self.i)
                    self.i = k + len(close)
                    continue
                else:
                    # short comment to end of line
                    self.adv(2)
                    while self.peek() not in ("\0", "\n"):
                        self.adv()
                    continue
            # shebang at file start? treat #! as comment
            if c == "#" and self.i == 0 and self.peek(1) == "!":
                while self.peek() not in ("\0","\n"):
                    self.adv()
                continue
            break

        c = self.peek()
        line, col = self.line, self.col
        if c == "\0":
            return Tok("eof", "", line, col)
        # strings
        if c in ("'", '"'):
            return self.lex_short_string()
        if c == "`":
            return self.lex_interp()
        if c == "[":
            # long string [[ ]] or [=[ ]=]
            j = self.i + 1
            level = 0
            while j < self.n and self.src[j] == "=":
                level += 1
                j += 1
            if j < self.n and self.src[j] == "[":
                return self.lex_long_string(level)
        # numbers
        if c.isdigit() or (c == "." and self.peek(1).isdigit()):
            return self.lex_number()
        # ident / keyword
        if c.isalpha() or c == "_":
            return self.lex_ident()
        # symbols (multi-char first)
        return self.lex_sym()

    def lex_ident(self):
        line, col = self.line, self.col
        j = self.i
        while j < self.n and (self.src[j].isalnum() or self.src[j] == "_"):
            j += 1
        word = self.src[self.i:j]
        self.adv(j - self.i)
        if word in KEYWORDS:
            return Tok("kw", word, line, col)
        return Tok("ident", word, line, col)

    def lex_number(self):
        line, col = self.line, self.col
        j = self.i
        s = self.src
        n = self.n
        # hex / binary
        if s[j] == "0" and j+1 < n and s[j+1] in "xX":
            j += 2
            while j < n and (s[j] in "0123456789abcdefABCDEF_"):
                j += 1
            raw = self.src[self.i:j].replace("_","")
            self.adv(j - self.i)
            try:
                v = float(int(raw, 16))
            except ValueError:
                raise LexError(f"bad hex number at {line}:{col}")
            return Tok("num", raw, line, col, num=v)
        if s[j] == "0" and j+1 < n and s[j+1] in "bB":
            j += 2
            while j < n and s[j] in "01_":
                j += 1
            raw = self.src[self.i:j].replace("_","")
            self.adv(j - self.i)
            try:
                v = float(int(raw[2:], 2))
            except ValueError:
                raise LexError(f"bad binary number at {line}:{col}")
            return Tok("num", raw, line, col, num=v)
        # decimal
        while j < n and (s[j].isdigit() or s[j] == "_"):
            j += 1
        if j < n and s[j] == "." and not (j+1 < n and s[j+1] == "."):
            j += 1
            while j < n and (s[j].isdigit() or s[j] == "_"):
                j += 1
        if j < n and s[j] in "eE":
            k = j+1
            if k < n and s[k] in "+-":
                k += 1
            if k < n and s[k].isdigit():
                j = k+1
                while j < n and (s[j].isdigit() or s[j]=="_"):
                    j += 1
        raw = self.src[self.i:j]
        self.adv(j - self.i)
        clean = raw.replace("_","")
        try:
            v = float(clean)
        except ValueError:
            raise LexError(f"bad number at {line}:{col}")
        return Tok("num", raw, line, col, num=v)

    def lex_short_string(self):
        line, col = self.line, self.col
        q = self.peek()
        self.adv()  # open quote
        buf = bytearray()
        while True:
            c = self.peek()
            if c == "\0":
                raise LexError(f"unfinished string at {line}:{col}")
            if c == "\n":
                raise LexError(f"unfinished string (newline) at {line}:{col}")
            if c == q:
                self.adv()
                break
            if c == "\\":
                self.adv()
                e = self.peek()
                if e == "\0":
                    raise LexError("unfinished escape")
                if e == "n":
                    buf.append(10); self.adv()
                elif e == "t":
                    buf.append(9); self.adv()
                elif e == "r":
                    buf.append(13); self.adv()
                elif e in ("'", '"', "\\"):
                    buf.append(ord(e)); self.adv()
                elif e == "n":
                    buf.append(10); self.adv()
                elif e == "x":
                    # \xHH
                    h = self.src[self.i+1:self.i+3]
                    if len(h) < 2 or any(ch not in "0123456789abcdefABCDEF" for ch in h):
                        raise LexError("bad \\x escape")
                    buf.append(int(h,16)); self.adv(3)
                elif e.isdigit():
                    # \ddd decimal (up to 3 digits, <=255)
                    k = self.i
                    digits = ""
                    while len(digits) < 3 and k < self.n and self.src[k].isdigit():
                        digits += self.src[k]; k += 1
                    v = int(digits)
                    if v > 255:
                        raise LexError("decimal escape too large")
                    buf.extend(bytes([v]))
                    self.adv(len(digits))
                elif e == "\n":
                    buf.append(10); self.adv()
                elif e == "z":
                    self.adv()
                    while self.peek() in " \t\r\n":
                        self.adv()
                else:
                    # unknown escape: keep char as-is (Luau compat: \u{...}, \a etc.)
                    if e == "a":
                        buf.append(7); self.adv()
                    elif e == "b":
                        buf.append(8); self.adv()
                    elif e == "f":
                        buf.append(12); self.adv()
                    elif e == "v":
                        buf.append(11); self.adv()
                    elif e == "u":
                        # \u{HEX}
                        self.adv()
                        if self.peek() != "{":
                            raise LexError("bad \\u escape")
                        self.adv()
                        h = ""
                        while self.peek() != "}":
                            if self.peek() == "\0":
                                raise LexError("bad \\u escape")
                            h += self.peek(); self.adv()
                        self.adv()  # }
                        cp = int(h, 16)
                        buf.extend(chr(cp).encode("utf-8"))
                    else:
                        buf.append(ord(e)); self.adv()
            else:
                # raw utf-8 bytes
                buf.extend(c.encode("utf-8"))
                self.adv()
        return Tok("str", q, line, col, data=bytes(buf))

    def lex_long_string(self, level):
        line, col = self.line, self.col
        # consume '[' + '='*level + '['
        self.adv(2 + level)
        # skip first newline
        if self.peek() == "\n":
            self.adv()
        buf = bytearray()
        while True:
            if self.peek() == "\0":
                raise LexError(f"unfinished long string at {line}:{col}")
            if self.peek() == "]":
                # check close
                j = self.i + 1
                l = 0
                while j < self.n and self.src[j] == "=":
                    l += 1; j += 1
                if l == level and j < self.n and self.src[j] == "]":
                    self.i = j + 1
                    # fix line/col approx
                    # recount: simpler to scan buf? just bump col
                    self.col += (j + 1 - self.i)
                    break
                else:
                    buf.append(ord("]"))
                    self.adv()
            else:
                c = self.peek()
                if c == "\n":
                    buf.append(10)
                    self.adv()
                    self.line += 0  # adv already counted
                else:
                    buf.extend(c.encode("utf-8"))
                    self.adv()
        return Tok("str", "[[", line, col, data=bytes(buf))

    def lex_interp(self):
        # backtick interpolated string: return as single token with raw source span;
        # parser will re-lex inner expressions. Store raw inner text.
        line, col = self.line, self.col
        self.adv()  # `
        parts = []  # list of ('lit', bytes) / ('expr', str)
        lit = bytearray()
        while True:
            c = self.peek()
            if c == "\0":
                raise LexError(f"unfinished interpolated string at {line}:{col}")
            if c == "`":
                self.adv()
                break
            if c == "\\":
                self.adv()
                e = self.peek()
                if e == "`":
                    lit.append(ord("`")); self.adv()
                elif e == "{":
                    lit.append(ord("{")); self.adv()
                elif e == "n":
                    lit.append(10); self.adv()
                elif e == "t":
                    lit.append(9); self.adv()
                else:
                    lit.append(ord(e)); self.adv()
                continue
            if c == "{":
                # start expr: find matching } respecting nesting/strings
                if lit:
                    parts.append(("lit", bytes(lit))); lit = bytearray()
                self.adv()  # {
                depth = 1
                expr_chars = []
                while depth > 0:
                    d = self.peek()
                    if d == "\0":
                        raise LexError("unfinished interpolation expr")
                    if d in ("'", '"'):
                        # copy string literal verbatim
                        q = d
                        expr_chars.append(d); self.adv()
                        while self.peek() != q:
                            if self.peek() == "\0":
                                raise LexError("unfinished string in interpolation")
                            if self.peek() == "\\":
                                expr_chars.append(self.peek()); self.adv()
                                expr_chars.append(self.peek()); self.adv()
                            else:
                                expr_chars.append(self.peek()); self.adv()
                        expr_chars.append(q); self.adv()
                        continue
                    if d == "{":
                        depth += 1
                    elif d == "}":
                        depth -= 1
                        if depth == 0:
                            self.adv()
                            break
                    expr_chars.append(d)
                    self.adv()
                parts.append(("expr", "".join(expr_chars)))
                continue
            if c == "}":
                raise LexError("unmatched } in interpolated string")
            lit.extend(c.encode("utf-8"))
            self.adv()
        if lit:
            parts.append(("lit", bytes(lit)))
        t = Tok("interp", "`", line, col)
        t.data = None
        # stash parts on token object dynamically
        t.parts = parts  # type: ignore
        return t

    def lex_sym(self):
        line, col = self.line, self.col
        s = self.src
        # 3-char symbols
        three = s[self.i:self.i+3]
        if three in ("...",):
            self.adv(3)
            return Tok("sym", three, line, col)
        two = s[self.i:self.i+2]
        if two in ("==", "~=", "<=", ">=", "..", "//", "<<", ">>", "+=", "-=",
                   "*=", "/=", "%=", "^=", "..=", "::", "->"):
            self.adv(2)
            return Tok("sym", two, line, col)
        # single (including ':' '.' ',' ';' etc.)
        c = self.peek()
        if c in "+-*/%^#&~|<>=(){}[];:,.?!@$":
            self.adv()
            return Tok("sym", c, line, col)
        # handle parens etc explicitly (above class includes them)
        self.error(f"unexpected character {c!r}")
