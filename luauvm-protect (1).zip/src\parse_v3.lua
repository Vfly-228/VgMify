local function __r16(s, pos)
    local a, b = __sbyte(s, pos, pos + 1)
    return (a + b * 256) % 65536, pos + 2
end
local function __r32(s, pos)
    local a, b, c, d = __sbyte(s, pos, pos + 3)
    return (a + b * 256 + c * 65536 + d * 16777216) % 4294967296, pos + 4
end

local function __bldinv(pf, q)
    local inv = {}
    for i = 1, __WN do inv[i] = 255 end
    local pos = 1
    for op = 0, __NREAL - 1 do
        local cnt = __alcnt[op + 1] or 1
        for k = 1, cnt do
            inv[pf[pos] + 1] = op
            pos = pos + 1
        end
    end
    return inv
end

-- NOTE: per-instruction bias/pad use a fast xsstep chain seeded from the
-- same fsd as the wire permutation (see __parseproto). Previously
-- __bias3/__padlen cost 2 ARX hashes per instruction at load.

local function __parseproto(s, pos, ctx)
    local q = ctx.pi
    ctx.pi = ctx.pi + 1
    local q0 = q % 256
    local q1 = __mathfloor(q / 256) % 256
    local q2 = __mathfloor(q / 65536) % 256
    local q3 = __mathfloor(q / 16777216) % 256
    local fseed = __hashfn(ctx.kp .. __schar(q0, q1, q2, q3))
    local f0, f1, f2, f3 = __sbyte(fseed, 1, 4)
    local fsd = (f0 + f1 * 256 + f2 * 65536 + f3 * 16777216) % 4294967296
    local inv = __bldinv(__pfy(fsd, __WN), q)
    local nparams, vararg, nregs, nown, nconsts, ncode, nchild, nuv
    nparams, pos = __r16(s, pos)
    vararg, pos = __r16(s, pos)
    nregs, pos = __r16(s, pos)
    nown, pos = __r16(s, pos)
    nconsts, pos = __r16(s, pos)
    ncode, pos = __r16(s, pos)
    nchild, pos = __r16(s, pos)
    nuv, pos = __r16(s, pos)
    local kcb = __sbyte(__kcon, 2)
    local K = {}
    for i = 1, nconsts do
        local tagenc = __sbyte(s, pos)
        pos = pos + 1
        local tag = (tagenc - kcb) % 256
        if tag == 0 then
            K[i] = nil
        elseif tag == 1 then
            K[i] = false
        elseif tag == 2 then
            K[i] = true
        elseif tag == 4 then
            K[i] = 1 / 0
        elseif tag == 5 then
            K[i] = -1 / 0
        elseif tag == 6 then
            K[i] = 0 / 0
        elseif tag == 3 or tag == 7 then
            local estart = pos
            local nch = __sbyte(s, pos)
            pos = pos + 1
            for c = 1, nch do
                pos = pos + 4
                pos = pos + 1
                local ln = __sbyte(s, pos)
                pos = pos + 1
                pos = pos + ln
            end
            local raw = __ssub(s, estart, pos - 1)
            K[i] = { tag, raw }
        else
            __error(__bad)
        end
    end
    local cblen
    cblen, pos = __r32(s, pos)
    local cb = __ssub(s, pos, pos + cblen - 1)
    pos = pos + cblen
    local br = { s = cb, pos = 1, buf = 0, bits = 0 }
    local code = {}
    local prev = 0
    local bst = fsd
    if bst == 0 then bst = 2654435769 end
    for i = 1, ncode do
        local wire = __brget(br, __OPBITS)
        if wire >= __WN then __error(__bad) end
        local real = inv[wire + 1]
        if real == nil or real == 255 then __error(__bad) end
        local ae = __bresc(br, __WA)
        local be = __bresc(br, __WB)
        local ce = __bresc(br, __WC)
        bst = __xsstep(bst)
        local b0 = bst % 256
        bst = __xsstep(bst)
        local b1 = bst % 256
        bst = __xsstep(bst)
        local b2 = bst % 256
        bst = __xsstep(bst)
        local pl = bst % 3
        if pl > 0 then __brget(br, pl) end
        local pb = prev % 256
        local A = (ae - b0 - pb) % 4294967296
        local B = (be - (A * __M1 % 256) - b1 - pb) % 4294967296
        local C = (ce - (B * __M2 % 256) - b2 - pb) % 4294967296
        code[i] = { real, A, B, C }
        prev = (ae + be + ce + (real * 2654435761 % 4294967296)) % 4294967296
    end
    local uv = {}
    for i = 1, nuv do
        local k = __sbyte(s, pos)
        pos = pos + 1
        local id
        id, pos = __r16(s, pos)
        uv[i] = { k, id }
    end
    local children = {}
    for i = 1, nchild do
        local ch
        ch, pos = __parseproto(s, pos, ctx)
        children[i] = ch
    end
    local lines = {}
    for i = 1, ncode do
        local v
        v, pos = __r16(s, pos)
        lines[i] = v
    end
    return {
        nparams = nparams, vararg = (vararg ~= 0), nregs = nregs, nown = nown,
        consts = K, code = code, uv = uv, children = children, lines = lines,
    }, pos
end

local function __parse_root(core)
    local padlen = __sbyte(core, 7)
    local pos = 8 + padlen
    local ctx = { pi = 0, kp = __kprm }
    local root
    root, pos = __parseproto(core, pos, ctx)
    return root
end
