"""v3 core: KDF, bitstream, chained stream crypt, const crypt, wire tables.

All parameterized per build; Lua loader mirrors byte-exactly.
"""
import random
from . import hardhash as HH

MASK32 = 0xFFFFFFFF


def build_params(seed: int, bind_env=None):
    """Derive all per-build params deterministically from seed.

    Returns dict with hash params, salts, seps, widths, wire spec,
    superop subset, keys. bind_env: expected JobId string or None.
    """
    seed64 = seed & 0xFFFFFFFFFFFFFFFF
    rng = random.Random(seed64 ^ 0x3EE5A1D7)
    hp = HH.gen_params(rng)
    build_salt = bytes(rng.randrange(0, 256) for _ in range(8))
    priv_salt = bytes(rng.randrange(0, 256) for _ in range(8))
    iv = bytes(rng.randrange(0, 256) for _ in range(16))
    seps = {
        "enc": bytes(rng.randrange(0, 256) for _ in range(6)),
        "perm": bytes(rng.randrange(0, 256) for _ in range(6)),
        "const": bytes(rng.randrange(0, 256) for _ in range(6)),
        "junk": bytes(rng.randrange(0, 256) for _ in range(6)),
        "magic": bytes(rng.randrange(0, 256) for _ in range(6)),
    }
    env_str = bind_env if bind_env is not None else "local-test"
    user_key = HH.digest(priv_salt + env_str.encode(), hp)
    seed_material = HH.digest(user_key + build_salt + (seed64 & MASK32).to_bytes(4, "little"), hp)
    keys = {
        "enc": HH.digest(seed_material + seps["enc"], hp),
        "perm": HH.digest(seed_material + seps["perm"], hp),
        "const": HH.digest(seed_material + seps["const"], hp),
        "junk": HH.digest(seed_material + seps["junk"], hp),
    }
    magic = HH.digest(seed_material + seps["magic"] + iv, hp)[0:4]
    # bitstream widths: lean 8..10 (was 10..14). Most operands are small
    # (regs/const-idx <64, short jumps); large values use the 32-bit
    # escape. Saves ~2-4 bits per operand (~15% code size) and fewer
    # bit-reader iterations at load.
    wa = rng.randrange(8, 11)
    wb = rng.randrange(8, 11)
    wc = rng.randrange(8, 11)
    # overlap multipliers (odd, nonzero)
    m1 = (rng.randrange(1, 256) | 1)
    m2 = (rng.randrange(1, 256) | 1)
    # wire spec: live slots = 54 reals + n_alias extra; wire_n covers + dead
    from .compiler import NOPS_V3
    hot_pool = list(range(NOPS_V3))
    rng.shuffle(hot_pool)
    n_alias = rng.randrange(10, 21)  # 10..20
    alias_ops = set(hot_pool[:n_alias])
    wire_n = NOPS_V3 + n_alias + rng.randrange(4, 17)  # +4..16 dead => 68..90
    # superop subset: enable 2..5 of 5
    all_super = [49, 50, 51, 52, 53]
    rng.shuffle(all_super)
    n_super = rng.randrange(2, 6)
    super_enabled = set(all_super[:n_super])
    # vm decoys: extra fault ids count 8..32 (real ids beyond NOPS_V3)
    n_decoy = rng.randrange(8, 33)
    # dispatch opaque affine
    disp_mult = rng.randrange(1, 256) | 1
    disp_add = rng.randrange(0, 256)
    disp_xor = rng.randrange(0, 256)
    # flattening trans table (8 states)
    trans = list(range(8))
    rng.shuffle(trans)
    flat_key = rng.randrange(0, 256)
    # time quantum (seconds, coarse to avoid flakes)
    t_quant = 2
    # bitstream op bits (wire_n <= 96 needs 7 bits)
    op_bits = 7
    return {
        "seed64": seed64, "rng_state": None, "hp": hp,
        "build_salt": build_salt, "priv_salt": priv_salt, "iv": iv,
        "seps": seps, "env_str": env_str, "bind_env": bind_env,
        "user_key": user_key, "seed_material": seed_material,
        "keys": keys, "magic": magic,
        "wa": wa, "wb": wb, "wc": wc, "m1": m1, "m2": m2,
        "op_bits": op_bits,
        "wire_n": wire_n, "alias_ops": alias_ops,
        "super_enabled": super_enabled, "n_decoy": n_decoy,
        "disp_mult": disp_mult, "disp_add": disp_add, "disp_xor": disp_xor,
        "trans": trans, "flat_key": flat_key, "t_quant": t_quant,
    }


class BitWriter:
    def __init__(self):
        self.bits = []  # list of 0/1, MSB-first

    def put(self, v: int, n: int):
        for i in range(n - 1, -1, -1):
            self.bits.append((v >> i) & 1)

    def put_escaped(self, v: int, w: int):
        """Small values in w bits; large via all-ones escape + 32-bit."""
        if v < (1 << w) - 1:
            self.put(v, w)
        else:
            self.put((1 << w) - 1, w)
            self.put(v & MASK32, 32)

    def bytes(self) -> bytes:
        while len(self.bits) % 8:
            self.bits.append(0)
        out = bytearray()
        for i in range(0, len(self.bits), 8):
            b = 0
            for k in range(8):
                b = (b << 1) | self.bits[i + k]
            out.append(b)
        return bytes(out)


class BitReader:
    def __init__(self, data: bytes):
        self.data = data
        self.pos = 0  # bit pos
        self.nbits = len(data) * 8

    def get(self, n: int) -> int:
        v = 0
        for _ in range(n):
            if self.pos >= self.nbits:
                raise ValueError("bitstream overrun")
            b = self.data[self.pos >> 3]
            bit = (b >> (7 - (self.pos & 7))) & 1
            v = (v << 1) | bit
            self.pos += 1
        return v

    def get_escaped(self, w: int) -> int:
        v = self.get(w)
        if v == (1 << w) - 1:
            v = self.get(32) & MASK32
        return v


def _rekey(hp: dict, k_enc: bytes, iv: bytes, chunk: int, quant: int = 0) -> int:
    d = HH.digest(k_enc + iv + (chunk & MASK32).to_bytes(4, "little")
                  + (quant & 0xFF).to_bytes(1, "little"), hp)
    return int.from_bytes(d[0:4], "little") or 0x9E3779B9


def xs_step(s: int) -> int:
    s &= MASK32
    s ^= (s << 13) & MASK32
    s ^= s >> 17
    s ^= (s << 5) & MASK32
    return s & MASK32 or 0x9E3779B9


def stream_crypt(hp: dict, k_enc: bytes, iv: bytes, data: bytes) -> bytes:
    """Chained stream crypt: enc[i] = plain[i] ^ ks ^ (prev_plain & FF).

    Rekey every 256 bytes via per-build hash (quant=0 at build time;
    runtime mixes os.clock quantum — normal runs stay in quantum 0).
    Byte-exact mirror of loader __xsdec.
    """
    out = bytearray()
    n = len(data)
    pos = 0
    chunk = 0
    prev = 0
    while pos < n:
        st = _rekey(hp, k_enc, iv, chunk, 0)
        end = min(pos + 256, n)
        while pos < end:
            st = xs_step(st)
            wv = st
            for _ in range(4):
                if pos >= end:
                    break
                ks = wv & 0xFF
                out.append(data[pos] ^ ks ^ (prev & 0xFF))
                prev = data[pos]
                wv >>= 8
                pos += 1
        chunk += 1
    return bytes(out)


def stream_decrypt(hp: dict, k_enc: bytes, iv: bytes, data: bytes, quant: int = 0) -> bytes:
    out = bytearray()
    n = len(data)
    pos = 0
    chunk = 0
    prev = 0
    while pos < n:
        st = _rekey(hp, k_enc, iv, chunk, quant)
        end = min(pos + 256, n)
        while pos < end:
            st = xs_step(st)
            wv = st
            for _ in range(4):
                if pos >= end:
                    break
                ks = wv & 0xFF
                pt = data[pos] ^ ks ^ (prev & 0xFF)
                out.append(pt)
                prev = pt
                wv >>= 8
                pos += 1
        chunk += 1
    return bytes(out)


def const_chain_crypt(hp: dict, k_con: bytes, nonce: bytes, idx: int,
                      prev_hash: bytes, data: bytes) -> bytes:
    """Per-chunk const crypt with chaining: keystream from
    H(k_con + nonce + idx + prev_hash). Different key per chunk."""
    kh = HH.digest(k_con + nonce + bytes([idx & 0xFF]) + prev_hash, hp)
    st = int.from_bytes(kh[0:4], "little") or 0x9E3779B9
    out = bytearray()
    pos = 0
    n = len(data)
    while pos < n:
        st = xs_step(st)
        wv = st
        for _ in range(4):
            if pos >= n:
                break
            out.append(data[pos] ^ (wv & 0xFF))
            wv >>= 8
            pos += 1
    return bytes(out)


def wire_tables(params: dict, q: int):
    """Per-proto Fisher-Yates over wire_n ids; alias set from params.

    Returns (slots: real-> [wire...], inv: wire->real or 255, dead set).
    """
    from .compiler import NOPS_V3
    hp = params["hp"]
    kp = params["keys"]["perm"]
    # fy seed: H(k_perm + q)[0:4] as int + q*const, avoids stock LCG
    sd = int.from_bytes(HH.digest(kp + q.to_bytes(4, "little"), hp)[0:4], "little")
    wn = params["wire_n"]
    perm = list(range(wn))
    st = sd or 0x9E3779B9
    i = wn
    while i > 1:
        st = xs_step(st)
        j = st % i
        i -= 1
        perm[i], perm[j] = perm[j], perm[i]
    slots = {}
    it = iter(perm)
    for op in range(NOPS_V3):
        if op in params["alias_ops"]:
            slots[op] = [next(it), next(it)]
        else:
            slots[op] = [next(it)]
    dead = set(it)
    inv = [255] * wn
    for op, wires in slots.items():
        for w in wires:
            inv[w] = op
    return slots, inv, dead


def pad_len_for(params: dict, i: int) -> int:
    """Fake padding bits per instruction (0..2), keyed by stream."""
    hp = params["hp"]
    kj = params["keys"]["junk"]
    d = HH.digest(kj + b"pad" + i.to_bytes(4, "little"), hp)
    return d[0] % 3


def pad_bits_for(params: dict, i: int, n: int) -> int:
    if n == 0:
        return 0
    hp = params["hp"]
    kj = params["keys"]["junk"]
    d = HH.digest(kj + b"padbits" + i.to_bytes(4, "little"), hp)
    return d[1] & ((1 << n) - 1)
