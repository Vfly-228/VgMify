-- protected by luauvm-protect (VM translation)
local lIlIllIlIII = _G
local llIIIIlIlIIIl = select
local lIlIlIllIIIl = type
local lIllIlIIllllIlII = next
local lllIIIllllIlIIll = getmetatable
local lIlIIlIIIllllIII = setmetatable
local llIIIIlllIIII = tostring
local lIIIIIIlllIlIll = tonumber
local lIIIIlIIIllIIl = error
local llIIIlIllllI = xpcall
local lllIIllIlIIlllIl = table.pack or function(...)
    local t = { n = llIIIIlIlIIIl("#", ...) }
    for i = 1, t.n do t[i] = llIIIIlIlIIIl(i, ...) end
    return t
end
local lIIIlIIIIII = table.unpack or unpack
local lllllllIlII = table.concat
local lIIIIIlIIIlIl = string.byte
local lIlIIllIlIlIII = string.char
local llIIIllIIlIl = string.sub
local lllIllIlIlll = string.len
local lllIllIIIIlIlIIl = math.floor
local lIIllIIlllIIllIl = os and os.clock

local llIIllllIlIIIl = lIlIllIlIII
do
    local ok, e = pcall(function() return getfenv(0) end)
    if ok and lIlIlIllIIIl(e) == "table" then
        llIIllllIlIIIl = e
    else
        local ok1, e1 = pcall(function() return getfenv() end)
        if ok1 and lIlIlIllIIIl(e1) == "table" then
            llIIllllIlIIIl = e1
        else
            local ok2, g = pcall(function() return (getgenv and getgenv()) or nil end)
            if ok2 and lIlIlIllIIIl(g) == "table" then
                llIIllllIlIIIl = g
            else
                local ok3, r = pcall(function() return (getrenv and getrenv()) or nil end)
                if ok3 and lIlIlIllIIIl(r) == "table" then
                    llIIllllIlIIIl = r
                end
            end
        end
    end
    if lIlIlIllIIIl(llIIllllIlIIIl) ~= "table" then llIIllllIlIIIl = lIlIllIlIII end
    if lIlIlIllIIIl(llIIllllIlIIIl) ~= "table" then llIIllllIlIIIl = {} end
end

local lIllllIlIlI = llIIllllIlIIIl["bit32"]
if lIllllIlIlI == nil then lIllllIlIlI = rawget(lIlIllIlIII, "bit32") end
local lIIlIIIlIIIlII, lllIIIllII, lIllIllIlII, lIIlIllIIIIl, llllIlIIIll, lIlIIIlllIII
if lIllllIlIlI then
    lIIlIIIlIIIlII, lllIIIllII, lIllIllIlII, lIIlIllIIIIl, llllIlIIIll, lIlIIIlllIII =
        lIllllIlIlI.band, lIllllIlIlI.bor, lIllllIlIlI.bxor, lIllllIlIlI.lshift, lIllllIlIlI.rshift, lIllllIlIlI.bnot
else
    local lllllIIIlIIlII, lIIIIIIIlIlllIll, llIIllIIIIllll = {}, {}, {}
    for llIlIIlIIll = 0, 15 do
        for lIIlIlIIll = 0, 15 do
            local lIlllIIIIllIlI, llIIIlIIIIllllll, lIllllIlIllIl, lllllIllIllIl, lIIIIIlIIII, lIlIIIlllllIllI = llIlIIlIIll, lIIlIlIIll, 0, 0, 0, 1
            for lIllIIlIllIlIlIl = 1, 4 do
                local llIllIllIlllllII, lIllllllIIlIll = lIlllIIIIllIlI % 2, llIIIlIIIIllllll % 2
                if llIllIllIlllllII ~= lIllllllIIlIll then lIllllIlIllIl = lIllllIlIllIl + lIlIIIlllllIllI end
                if llIllIllIlllllII == 1 and lIllllllIIlIll == 1 then lllllIllIllIl = lllllIllIllIl + lIlIIIlllllIllI end
                if llIllIllIlllllII == 1 or lIllllllIIlIll == 1 then lIIIIIlIIII = lIIIIIlIIII + lIlIIIlllllIllI end
                lIlllIIIIllIlI = lllIllIIIIlIlIIl(lIlllIIIIllIlI / 2)
                llIIIlIIIIllllll = lllIllIIIIlIlIIl(llIIIlIIIIllllll / 2)
                lIlIIIlllllIllI = lIlIIIlllllIllI * 2
            end
            lllllIIIlIIlII[llIlIIlIIll * 16 + lIIlIlIIll] = lIllllIlIllIl
            lIIIIIIIlIlllIll[llIlIIlIIll * 16 + lIIlIlIIll] = lllllIllIllIl
            llIIllIIIIllll[llIlIIlIIll * 16 + lIIlIlIIll] = lIIIIIlIIII
        end
    end
    local function lIlIIIlllll(llIllllIIlIlIlI, llIlIIlIIll, lIIlIlIIll)
        llIlIIlIIll = llIlIIlIIll % 4294967296
        lIIlIlIIll = lIIlIlIIll % 4294967296
        local lIllIllIlIIIIII, lIlIIIlllllIllI = 0, 1
        for llIIIlIIlIl = 1, 8 do
            lIllIllIlIIIIII = lIllIllIlIIIIII + llIllllIIlIlIlI[(llIlIIlIIll % 16) * 16 + (lIIlIlIIll % 16)] * lIlIIIlllllIllI
            lIlIIIlllllIllI = lIlIIIlllllIllI * 16
            llIlIIlIIll = lllIllIIIIlIlIIl(llIlIIlIIll / 16)
            lIIlIlIIll = lllIllIIIIlIlIIl(lIIlIlIIll / 16)
        end
        return lIllIllIlIIIIII
    end
    lIIlIIIlIIIlII = function(llIlIIlIIll, lIIlIlIIll) return lIlIIIlllll(lIIIIIIIlIlllIll, llIlIIlIIll, lIIlIlIIll) end
    lllIIIllII = function(llIlIIlIIll, lIIlIlIIll) return lIlIIIlllll(llIIllIIIIllll, llIlIIlIIll, lIIlIlIIll) end
    lIllIllIlII = function(llIlIIlIIll, lIIlIlIIll) return lIlIIIlllll(lllllIIIlIIlII, llIlIIlIIll, lIIlIlIIll) end
    lIIlIllIIIIl = function(llIlIIlIIll, lllIIIIlIllIllll)
        lllIIIIlIllIllll = lllIIIIlIllIllll % 32
        if lllIIIIlIllIllll == 0 then return llIlIIlIIll % 4294967296 end
        return ((llIlIIlIIll % (2 ^ (32 - lllIIIIlIllIllll))) * (2 ^ lllIIIIlIllIllll)) % 4294967296
    end
    llllIlIIIll = function(llIlIIlIIll, lllIIIIlIllIllll)
        lllIIIIlIllIllll = lllIIIIlIllIllll % 32
        if lllIIIIlIllIllll == 0 then return llIlIIlIIll % 4294967296 end
        return lllIllIIIIlIlIIl((llIlIIlIIll % 4294967296) / (2 ^ lllIIIIlIllIllll))
    end
    lIlIIIlllIII = function(llIlIIlIIll) return 4294967295 - (llIlIIlIIll % 4294967296) end
end
local function llllIIlIII(a, b) return lllIllIIIIlIlIIl(a / b) end
local function llIllIIIll(lIlllIIIIllIlI, lllIIIIlIllIllll)
    lllIIIIlIllIllll = lllIIIIlIllIllll % 32
    if lllIIIIlIllIllll == 0 then return lIlllIIIIllIlI % 4294967296 end
    return (llllIlIIIll(lIlllIIIIllIlI, lllIIIIlIllIllll) + lIIlIllIIIIl(lIlllIIIIllIlI, 32 - lllIIIIlIllIllll)) % 4294967296
end
local function lIIIllIIIlIIlll(llllIIIlIIlIII)
    llllIIIlIIlIII = llllIIIlIIlIII % 4294967296
    llllIIIlIIlIII = lIllIllIlII(llllIIIlIIlIII, lIIlIllIIIIl(llllIIIlIIlIII, 13))
    llllIIIlIIlIII = lIllIllIlII(llllIIIlIIlIII, llllIlIIIll(llllIIIlIIlIII, 17))
    llllIIIlIIlIII = lIllIllIlII(llllIIIlIIlIII, lIIlIllIIIIl(llllIIIlIIlIII, 5))
    if llllIIIlIIlIII == 0 then llllIIIlIIlIII = 2654435769 end
    return llllIIIlIIlIII
end

local lIIlIlIIlIII={((74733*8290+387058684)%4294967296),((330810894+1931309363)%4294967296),((762794378*2+1)%4294967296),((17903*152706+680420884)%4294967296),((3657498763+1379017779)%4294967296),((13883*65957+103192673)%4294967296),((1919578214+1780556567)%4294967296),((54385*76200+4065313530)%4294967296),((2095719402*2+1)%4294967296),((55017*55370+3599589488)%4294967296),((59623*34058+4097963191)%4294967296),((3065852394+1462236342+860366797)%4294967296),((1504614714+1997330786)%4294967296),((1100591711*2+0)%4294967296)}
local lIlIIlIIlIllllIl={18,24,1,39,38,37,21,25,33,19,23,11,12,7}
local llIllllIlI={((1215690213+2512402197)%4294967296),((987702581*2+1)%4294967296),((87758010+1771377470)%4294967296),((91079*29675+1401333714)%4294967296),((4235012347+1529793176)%4294967296),((1595580151*2+0)%4294967296),((909634326+1606318226+904813283)%4294967296),((4166453696+2525589905)%4294967296),((47499*53207+2952349779)%4294967296),((25897*90376+2348015484)%4294967296),((271573862+4176901511)%4294967296),((819286275*2+1)%4294967296),((1472774983+2084148901)%4294967296),((1769624851*2+1)%4294967296)}
local lllllIIlIllI={35,16,30,15,20,32,2,5,14,34,40,31,3,28}
local lIllllIlIllIIl={((54674109*2+1)%4294967296),((1604672294*2+1)%4294967296),((1753843855*2+1)%4294967296),((897572780*2+1)%4294967296),((52217*71161+3606745537)%4294967296),((1603144009+1481176914)%4294967296),((1519298498+2574088434+3315544918)%4294967296),((76567*7743+3224754920)%4294967296),((3631625829+316729297)%4294967296),((1139213721*2+1)%4294967296),((1804707396*2+1)%4294967296),((4201050043+382746907)%4294967296),((1331965961*2+0)%4294967296),((1069643457+1765021911+1967528124)%4294967296)}
local lIlllIIIIlIIIlll={27,22,29,9,36,13,17,41,6,26,42,10,4,8}
local lllIlIlIIl={((34521*20993+3498840222)%4294967296),((3734477448+15633072+1239708965)%4294967296),((77115*54214+920559603)%4294967296),((755472283+2503134707+3125228700)%4294967296),((67101*5620+2392341885)%4294967296),((751442754+495430067)%4294967296),((1997393196*2+0)%4294967296),((1880620311*2+0)%4294967296)}
local lIllIIlIIIIIIIIl={}
for llIIIlIIlIl=1,#lIIlIlIIlIII do lIllIIlIIIIIIIIl[lIlIIlIIlIllllIl[llIIIlIIlIl]]=lIIlIlIIlIII[llIIIlIIlIl] end
for llIIIlIIlIl=1,#llIllllIlI do lIllIIlIIIIIIIIl[lllllIIlIllI[llIIIlIIlIl]]=llIllllIlI[llIIIlIIlIl] end
for llIIIlIIlIl=1,#lIllllIlIllIIl do lIllIIlIIIIIIIIl[lIlllIIIIlIIIlll[llIIIlIIlIl]]=lIllllIlIllIIl[llIIIlIIlIl] end
lIIlIlIIlIII=nil
lIlIIlIIlIllllIl=nil
llIllllIlI=nil
lllllIIlIllI=nil
lIllllIlIllIIl=nil
lIlllIIIIlIIIlll=nil
local lIIIlIlIIllll={19,7,29,28,14,27}
local lIIIlIlIIIIIllIl=42

local function lIIlllIllIlIlIlI(llIlllIllIIlIlIl)
    local lIlIlIIIIllI = #llIlllIllIIlIlIl
    local llIlIllIllll = lllIllIIIIlIlIIl(lIlIlIIIIllI / 536870912)
    local llIIIllIIIIlIIlI = (lIlIlIIIIllI * 8) % 4294967296
    local lIIllIIIlII = (56 - ((lIlIlIIIIllI + 1) % 64)) % 64
    local lIIIllllll = {llIlllIllIIlIlIl, lIlIIllIlIlIII(128)}
    for llIIIlIIlIl = 1, lIIllIIIlII do lIIIllllll[#lIIIllllll + 1] = lIlIIllIlIlIII(0) end
    lIIIllllll[#lIIIllllll + 1] = lIlIIllIlIlIII(lllIllIIIIlIlIIl(llIlIllIllll / 16777216) % 256, lllIllIIIIlIlIIl(llIlIllIllll / 65536) % 256, lllIllIIIIlIlIIl(llIlIllIllll / 256) % 256, llIlIllIllll % 256, lllIllIIIIlIlIIl(llIIIllIIIIlIIlI / 16777216) % 256, lllIllIIIIlIlIIl(llIIIllIIIIlIIlI / 65536) % 256, lllIllIIIIlIlIIl(llIIIllIIIIlIIlI / 256) % 256, llIIIllIIIIlIIlI % 256)
    local lIlIlIIIllll = lllllllIlII(lIIIllllll)
    local lllIIlllll, lIlIlIlIIlIl, lIlIllIIII, llIIlIlIIlIllIl, lIlIIIIIlIIlll, lllIIlllIIIlll = lIIIlIlIIllll[1], lIIIlIlIIllll[2], lIIIlIlIIllll[3], lIIIlIlIIllll[4], lIIIlIlIIllll[5], lIIIlIlIIllll[6]
    local lIIlIllIlIlI = lIIIlIlIIIIIllIl
    local llllIlIIll = (lIlIIIIIlIIlll + lllIIlllIIIlll) % 32
    if llllIlIIll == 0 then llllIlIIll = 1 end
    local lIllIIIlIIlIIlll, lIIIIlIlllIllIlI, llIIllIlII, lllIIIlIlI, lIlIIIllIlllIll, lIllIIllllI, lllIIIllll, lIlIllllIllll = lllIlIlIIl[1], lllIlIlIIl[2], lllIlIlIIl[3], lllIlIlIIl[4], lllIlIlIIl[5], lllIlIlIIl[6], lllIlIlIIl[7], lllIlIlIIl[8]
    local lIIIlIllllIllII = {}
    for llIllIlllIII = 1, #lIlIlIIIllll, 64 do
        for llIIIlIIlIl = 0, 15 do
            local llllllllIIlIII, lIllIIllIlIllIl, lIlIlIIIlllIllIl, lIIlllIIIllIll = lIIIIIlIIIlIl(lIlIlIIIllll, llIllIlllIII + llIIIlIIlIl * 4, llIllIlllIII + llIIIlIIlIl * 4 + 3)
            lIIIlIllllIllII[llIIIlIIlIl + 1] = (llllllllIIlIII * 16777216 + lIllIIllIlIllIl * 65536 + lIlIlIIIlllIllIl * 256 + lIIlllIIIllIll) % 4294967296
        end
        for llIIIlIIlIl = 17, lIIlIllIlIlI do
            if llIIIlIIlIl > 64 then lIIIlIllllIllII[llIIIlIIlIl] = 0
            else
            local lIlllIIIIllIlI = lIIIlIllllIllII[llIIIlIIlIl - 15] or 0
            local lIlllIIlIIIlII = lIllIllIlII(lIllIllIlII(llIllIIIll(lIlllIIIIllIlI, lllIIlllll), llIllIIIll(lIlllIIIIllIlI, lIlIlIlIIlIl)), llllIlIIIll(lIlllIIIIllIlI, 3))
            local llIIIlIIIIllllll = lIIIlIllllIllII[llIIIlIIlIl - 2] or 0
            local lllIIlllIllII = lIllIllIlII(lIllIllIlII(llIllIIIll(llIIIlIIIIllllll, lIlIllIIII), llIllIIIll(llIIIlIIIIllllll, llIIlIlIIlIllIl)), llllIlIIIll(llIIIlIIIIllllll, 10))
            lIIIlIllllIllII[llIIIlIIlIl] = (lIIIlIllllIllII[llIIIlIIlIl - 16] + lIlllIIlIIIlII + lIIIlIllllIllII[llIIIlIIlIl - 7] + lllIIlllIllII) % 4294967296
            end
        end
        local llIlIIlIIll, lIIlIlIIll, lllIlIIlIlll, lIIlIIIlIl, lIIlllIlllIIII, lllIlllIIl, lIlllIIllIllIIll, llIIlIIIIlI = lIllIIIlIIlIIlll, lIIIIlIlllIllIlI, llIIllIlII, lllIIIlIlI, lIlIIIllIlllIll, lIllIIllllI, lllIIIllll, lIlIllllIllll
        for llIIIlIIlIl = 1, lIIlIllIlIlI do
            local llIllllIII = lIllIllIlII(lIllIllIlII(llIllIIIll(lIIlllIlllIIII, lIlIIIIIlIIlll), llIllIIIll(lIIlllIlllIIII, lllIIlllIIIlll)), llIllIIIll(lIIlllIlllIIII, llllIlIIll))
            local lIllllIlllI = lIllIllIlII(lIIlIIIlIIIlII(lIIlllIlllIIII, lllIlllIIl), lIIlIIIlIIIlII(lIlIIIlllIII(lIIlllIlllIIII), lIlllIIllIllIIll))
            local lIlllllIIllIllI = (llIIlIIIIlI + llIllllIII + lIllllIlllI + lIllIIlIIIIIIIIl[((llIIIlIIlIl - 1) % lIIlIllIlIlI) + 1] + (lIIIlIllllIllII[llIIIlIIlIl] or 0)) % 4294967296
            local lIllIlIIll = lIllIllIlII(lIllIllIlII(llIllIIIll(llIlIIlIIll, lllIIlllll), llIllIIIll(llIlIIlIIll, lIlIlIlIIlIl)), llIllIIIll(llIlIIlIIll, lIlIllIIII))
            local llIIlIlIIIlIll = lIllIllIlII(lIllIllIlII(lIIlIIIlIIIlII(llIlIIlIIll, lIIlIlIIll), lIIlIIIlIIIlII(llIlIIlIIll, lllIlIIlIlll)), lIIlIIIlIIIlII(lIIlIlIIll, lllIlIIlIlll))
            local lIllIllllII = (lIllIlIIll + llIIlIlIIIlIll) % 4294967296
            llIIlIIIIlI = lIlllIIllIllIIll
            lIlllIIllIllIIll = lllIlllIIl
            lllIlllIIl = lIIlllIlllIIII
            lIIlllIlllIIII = (lIIlIIIlIl + lIlllllIIllIllI) % 4294967296
            lIIlIIIlIl = lllIlIIlIlll
            lllIlIIlIlll = lIIlIlIIll
            lIIlIlIIll = llIlIIlIIll
            llIlIIlIIll = (lIlllllIIllIllI + lIllIllllII) % 4294967296
        end
        lIllIIIlIIlIIlll = (lIllIIIlIIlIIlll + llIlIIlIIll) % 4294967296
        lIIIIlIlllIllIlI = (lIIIIlIlllIllIlI + lIIlIlIIll) % 4294967296
        llIIllIlII = (llIIllIlII + lllIlIIlIlll) % 4294967296
        lllIIIlIlI = (lllIIIlIlI + lIIlIIIlIl) % 4294967296
        lIlIIIllIlllIll = (lIlIIIllIlllIll + lIIlllIlllIIII) % 4294967296
        lIllIIllllI = (lIllIIllllI + lllIlllIIl) % 4294967296
        lllIIIllll = (lllIIIllll + lIlllIIllIllIIll) % 4294967296
        lIlIllllIllll = (lIlIllllIllll + llIIlIIIIlI) % 4294967296
    end
    local llIllIlllll = {}
    for _, lllIlIIlIl in ipairs({lIllIIIlIIlIIlll, lIIIIlIlllIllIlI, llIIllIlII, lllIIIlIlI, lIlIIIllIlllIll, lIllIIllllI, lllIIIllll, lIlIllllIllll}) do
        llIllIlllll[#llIllIlllll + 1] = lIlIIllIlIlIII(lllIllIIIIlIlIIl(lllIlIIlIl / 16777216) % 256, lllIllIIIIlIlIIl(lllIlIIlIl / 65536) % 256, lllIllIIIIlIlIIl(lllIlIIlIl / 256) % 256, lllIlIIlIl % 256)
    end
    return lllllllIlII(llIllIlllll)
end
local function llIlIlIlIllIIII(lIllIIlIllIlIlIl, llIlllIllIIlIlIl)
    if #lIllIIlIllIlIlIl > 64 then lIllIIlIllIlIlIl = lIIlllIllIlIlIlI(lIllIIlIllIlIlIl) end
    local llllllIIlI, llIlIIIllI = {}, {}
    for llIIIlIIlIl = 1, 64 do
        local lIIlIlIIll = lIIIIIlIIIlIl(lIllIIlIllIlIlIl, llIIIlIIlIl) or 0
        llllllIIlI[llIIIlIIlIl] = lIlIIllIlIlIII(lIllIllIlII(lIIlIlIIll, 54))
        llIlIIIllI[llIIIlIIlIl] = lIlIIllIlIlIII(lIllIllIlII(lIIlIlIIll, 92))
    end
    return lIIlllIllIlIlIlI(lllllllIlII(llIlIIIllI) .. lIIlllIllIlIlIlI(lllllllIlII(llllllIIlI) .. llIlllIllIIlIlIl))
end



local function lllllllIlll(f)
    if f == nil or f == 0 then return llIIllllIlIIIl end
    return llIIllllIlIIIl
end
local function lIIIIlIIlIIIIl(f, t)
    if lIlIlIllIIIl(t) == "table" then
        if f == nil or f == 0 then
            for k, v in lIllIlIIllllIlII, t, nil do llIIllllIlIIIl[k] = v end
        end
        return t
    end
    return t
end

local function llIlIIIIIIIl(v)
    if lIlIlIllIIIl(v) == "function" then return v, nil, nil end
    local mt = lllIIIllllIlIIll(v)
    if mt ~= nil then
        local it = mt.__iter
        if it ~= nil then
            local a, b, c = it(v)
            return a, b, c
        end
    end
    if lIlIlIllIIIl(v) == "table" then return lIllIlIIllllIlII, v, nil end
    lIIIIlIIIllIIl("attempt to iterate over a " .. lIlIlIllIIIl(v) .. " value", 2)
end

local lIIlllIIIIlI = lIlIIlIIIllllIII({}, { __mode = "k" })

local lllIllIllIIll = 0
local function lIIllIlllIll(msg)
    if lIlIlIllIIIl(msg) == "string" then
        return msg .. " (line " .. llIIIIlllIIII(lllIllIllIIll) .. ")"
    end
    return msg
end

local lIIllIllIlIIIIl = { "2267e7447d9b89a0d89a25b235eca1030a9d56c8953dce51f88419176654f31310e83af10ccdf864eeab8316b26192b2d85640c1d2ecd66d9cbb30ea1a5b5c81af3bc804d1bca2b8edb9964755b3004bedd44d7a9184e0aad0422b0918f7154f4463e32031b0e3e51447ed1ad0b87e02aa41eac67a6fa0e03e3685222c0b1b9bb5aacccd0780e659f63d41428fdacf9cbe3cb66c6655281b8dd0f5e6fe578ece4460801e304216c1fed9dea4a1c865801a17978b094c9a537ca490b6d858ea035e22e36c2d1cfe7cfd530997afbeaf21ce43101043b9e1f0b7be82d997ff2c7424b02d402bcf1973c98bf2d7508b51a196ff1b8f7fb8fc105e068fbf18f7ecfed57dec8ecc932b172b132dfecb21a7c74534d3290d036a4275d97063be54ca6f5144109cd60d19341e5ab03566e886e3bf6ae22f83db0958707924e00c590155ea003881e895c0e6b7c4543fde76dd69a190813bb9a9cc8c176a684558bfd23568bf735b08846ba268604ee9fad4226e77b276a187e528b5f0d29ff18b28a5f586999a98023fea88152e402df04ff19c92f1729d4abcf4665dd490a19e6425b079d9632f39b592745bedd223e2d8322220cd57eb853d366b7edeb7fc4db7ccac6a094b4099a31606757c1fb4d9631eb96b02395d8c16aa980f4e07323f61e860ca75ea8c6555e441566248f76a184e38d8280fb562eb66b19c855066db6467559131177720ec6ce4000c9d018620010cdbdfe0c22719504e90f9d15b8b6079e1ce09b208cd9bff4bebd4575d22e7455d3151dc25bd00c63982d6f69858feb5391bf04de950e7353477e4388af30e15ce7ab667fdd2ab10e5ce69932174de670a61054b36fb78f36a3371cd8dd31af3a4ac1d6e740cc5803aadb29fb96c039eaa6542fdcbfab4f0c46a722e8ec73cfde2ef30f3933519c944dc38002cebeae8f7ad783b1b5c1722aa77dc7f6be262c59eaef27846e7d853698108c4fe173a42ab54c9a10ac25d597f7bff22fe75bec3055e5674999f13fcd3b918319d34fa5f229efb4990494f8e0934b9f9e759318eab085dbba05bccfa853f8f860b7c2d1407560e1b43dab9621f43e311507ffd33a6578b0572f8c9f626f36ab42811654bc0c02f159242b91b4d883a13b2a8ecc2366243ad2ecc648c36b33d7d50d08c1ab14f6f7a85b845ad6ae6bc4333c0a8be4611e6fb338f611cdd0308fb3bd7908b4e764083a0153a8584c8dfdb105ed47ccb783a33f9a4f6dc6e90715440f4f1f2d20fbeddbe05d5711a63b454c351ae7ea25b7519db7cd328c00dfac0323f1f0e2c4314e5acec491996943e580c715e7dc150ff93ccbd9f313bcfe2de2e835b6391abe8f53b4ed8876760804f13461f49cc289cf8cc9928d79aff67c7ae6e5e83a44a9d95183460f9ead53d6b897201c5d54dabf4541f1efabcf3e43ae928cad3f0e110fb8be8c6095d97052fdeff101689d626b9e42b1f131ed77eda0c4f6ea1832914013de630ff387973118fef628ace6e38321af2e2bb5e9a03e682711bc2fbcb9b7feadcf287f58bfa7a4d40e935661bc6d5ebad457ef2c4dfdea22224a76ddc15c296d216985c8efc7a63845b72387526d64a4e9e183c874cd54382bee1fe12183b3876d8655ef22b0890db5772dec63f050869c3dbec0a27b4cb92999b5a94a6a9390450fd8c0adaa5825633b57fb6fa00bc2bcd19705b841f7313add097970a140aabc24c4a6174d1342a354a6e1a6f80e6c6b578b0d25662668fc5623986be91a579c02ca1b82f2c5ec9a223ed37bf60b3e92889239c73db693e437aa223da20f0ed04ade692aa07e8d3cb5170bc9885f0c652cbdd526e192d6339a4a90a39771e0038ebb810a531168f5357e8c7713d38a0a9ff02ec5c34527a6146837ca1bcd9c2a5de6326e43d673636056a8a7110c2c884e692e63a7c81a3149fe47c390537c16993892011b305a2eceb79c1bc3f2a26ac17767e30f9ce52dfa79f8c5acb798e98d5fbc46c30a2e30396508aa3785602e854d487529098c39bf6127a0dad9d4a740ce1bec2f7da0959689000f402055744181458a8b2edb5271e428c0ab46e1ed3b811d0665fc9f987c737df3dac8875098240395d9132dbdb70ecef575dc63b877472c90bbc0b322f50b816feee3a5b8f293ed2160f21b99a94a5dcae4595cc5d2bfcb30df08a1d9982e30efe3b966bb21b5f08d416b41ede52c26b7d3d939b61f569b7c250f897bf4e51ee0bb7836af43f9deb9c7fabd01340598dc9d017f2f53a245a31c1fe4b7bb8c25a81d45dbde2ea54f12fb8080e319556b7ebf81fbdc124021c90299cc66943a70ab0e5ad4b6e6d166c158d50a3c060e9f52a080acb276762d9607c7fd02a8ccedc89e56fda715a6adde92e78110030e7f66528a06f3c64f721ffe743f5480b8c0cfb91667287127f749be6e186ef91d3231a41eaa8aa569fb92ce508bb81f0055360a0ea28664de665f51ff3fd26c61349f9d437a4516f4a586e6d93b1ced1f7de1b5543a4f881bbd19583219edc0fcfd501f831667830334103be85c5890cf1269c9804fbd3c64e592d76993939084a477436ad9db4bdfdaa8459e22878e35c71252553507ac7d4fd7a1609719451d5dc10f5c3ccd744c9811c54f88bac49d5ab93fcc27d6d36bc4a048ef2a28e61e56cd48180c6f7131906bb8e72ef63b3707c2819ac1fe1cbf132a1057c1c6eb12cfdc352a850f84e4b943bd88b1cc8a2b46b2b510f080f83f6c2ec29172a96d20de3c1bf35dddc9d5e33587316bea194a440e86ded6a3de8b3fe227cc28ba4f4ee1a5ff3350f837a23f77ffb9767b75f2a5d0e2de2b15989116ee9825b4108daea823783a5ca3199572ac77e1e3b793fa2630ada5ba7e9501f80bbacd93eec52482ae1093cd724ae81ab5f6c28b512922ac8365cbd8113e3fc3898df49edeafa5f4d5fdef733c267326ce40eb2682351a2fa3c5882c0455ab868b863069675f793e75d9907d1466421549a503caec44a0a6b8371537d0999c827e69bb62f85dd88bd515a3c968d74bb59a7e9c9a2c9fdce7719caf3c235da9edfc977a0c8d57ab748beca12007a18c6e6cc41c8f4033a40726c23135629e1294590d9db8824158f1bd0634cc5ddacaaae3a9e88744f344877053393c6312289e62ec52cf71f9155f5bd8793f47c8602503d94310e8c31494519ded75cf054fbe589bd5bb5927822522434a05464072553d67852ac1044facbd7e9ff34592b62e7606c309e008c3f7047229418518195db819a4447c2b75123140705b5a69f5d40b3b3a2c0af33c965be3e3b4d01b03f3c1b687e9087a217385720233f7f762f7d51dedf65d24165b5528f80c334c43417ada4c3cead34873cc03f74fb79bd8eab1fe809112f1ec1da7467c07a8b1fd1720d33bf76f5a531185cb4d639fdc9f082963e9a913270781f4e4f0352224b95fcb5fcdae7486f9d22120c68076434b4afe90a709a61ec8226ac5d2b8ad1ac7eb319fb8708312c3e68e5c480e48c0ffec8fefaf2757cbc5d55472427ec85bea2a3e96d21e4ebd28b207fbe42245c182ca36600dee0c25c82e9671c50b04ec14a52ccfd0b402c88f7c8b80e989a21e7a3c95a5fe0608b9d04cc13854c8772fba64f0d81ff1f90345d71213325b3f606797cbc3a8c38e883631e414620a70b27ba9b1acc90870c68454cf5a10882c54a85b24a0175836bcf1eb8c2c1f8a9fbcdb857a2d7641945e71602b232cb4078fa2ffdc5e4d22308e7d2d18d08bdf168b16ce96c3fa7b77374311d0024dcbb08dc9c7d0ef993c6bed3a39a182c0ffd994af9ee3f8920cc1352e198fc94987cc16c7e581afcc58be8f10bb0af2c391da64dbebecef6eeab45cb118ed9a2e0760a47d5511c9dd6d305f0a281e6dd82d55ec12f171225f2f3ba6aa92781c48811466b1a8c34f0674d460999a33870e622cd2d774378627ce2bfcb377c26e57ca0119df42cdfa5396c816021f435a9fe140cb04011a177aea5379b2d0b230de9c78b4462598db1c40317fd239d845d3cd75aafaa0a681a96c111ec327439239f900ce41bcbe06f037fb1e7552fb63ae718968e54b1289bb2ab045ac544afa7ef468cf2c22bb83cf8e71b028ce815ab2433e8d6800b7fc2e3ea684c2cb272788f3534e6a0154572ae6d5bc43829f79bc266a9a937146e2e5612dd7ee2ccbc4a063592b76fdde7d8277c114e5bfc665cb12dfdfa89f2f4bf19921620388b35b7e149e041bf181356e7979e9b8e06a96759d074ae295f41ba0ca24eafdb2a4b1770a61a34ba83ab761855a2dd608bc4744b0ccd52a200819b88a8f9cae2e2e2050fdb3d68d5a70dbb85f5ba8c168835934ef4f19bd82b95fc86aafc9b6ba161276565438e5f59594a9f049dbeaca69027166c37d32838909b44fb06f011a1403fc07901b8d9bf18831f18fbf11abc30321ddd7a1275f23606c06d8452e997c73e8f042d43a380af9417a797f7c3b324601c9dfe310b3976a4a5dd9d054a17ce78c35f85fc80a16cb417c4982ed36aacfb0b2416a2bd2274b51e2f4412bb31ce628cd6b73a6c2394c468a2eb51a396d0854bdbc166d27398f550681a968d833fa0856c784ef97b2a25eb18643d9631891378614895daa74cdef5544206a0a498c8749ce2438902ba0942f0746bc9dc664b4c8284942796df8d429fa689c2e5360a71178f60392e98376ddcc6502d13bcb0f15a7145055dc583979c5809c3eb1c63e7853ac333ad91cdef90ccd2ca404f0cd698763296b97dece945861880dc91f3a76926e941ca918cecc1062685afb910d74c34ace94fc2bba6a7d1952dc60ea04e6bfc4b8d597e3487b7243a3a90bd1d86f6377529028cd3521b440043efefc50e81ad08e5eb24814b50d3ddcd403c65d4fb31084fed5b9c2e300891581629340ab0ff862c85c525dca22c7ab7f82d69eefeca58f25357a9c7fbaf67ac290ad337dca201d9af55471b68e8fc926e929bac5b124659834bfda79b3b7f8243c5d69982b5f933189c20f197cb89eb5490c4d0ad985f46f6ac51414f0b72b07c643e8fdafede68a6c1ee603f94aad42ece1af79ff16c2756788b961819dc3cb9bd4ac16aedbabd0c921116e9e7ad5aaccfbbd8261d707c0158b51413388f7819fd29caf4b84010b247fc8d5eb42fc585cb4c26f2a0df39db539414a5fe65225408f64a63096654c46a3e7136ef78670a9e5451f8e2660e683d239ab52c6ab202f08085b896c6" }

local llIIIIIlIIll=((((2162101072+3988208254)%4294967296)+(0xEBE13545)+(0xA5888550))%4294967296)
local llIIIIlIIlIIl=lIlIIllIlIlIII(((72+109)%256),((1+58)%256),((238+186)%256),((69+142)%256),((109+23)%256),((133+15)%256),((24+49)%256),((68+94)%256))
local lIIlllIlIIllIlII=lIlIIllIlIlIII(((1+33)%256),((143+86)%256),((23+8)%256),((138+182)%256),((122+178)%256),((233+255)%256),((95+236)%256),((118+7)%256))
local lllIIIlIll=lIlIIllIlIlIII(((216+56)%256),((38+169)%256),((40+111)%256),((249+83)%256),((17+251)%256),((55+218)%256))
local lIlIlIlIIIIlll=lIlIIllIlIlIII(((245+39)%256),((39+223)%256),((138+15)%256),((227+207)%256),((110+224)%256),((163+201)%256))
local llllIlIlIIIIlI=lIlIIllIlIlIII(((55+122)%256),((227+132)%256),((249+47)%256),((248+128)%256),((195+78)%256),((125+63)%256))
local lllIlIIlIIl=lIlIIllIlIlIII(((40+171)%256),((38+107)%256),((4+229)%256),((48+205)%256),((254+54)%256),((188+96)%256))
local llIlIIlIllll=lIlIIllIlIlIII(((26+118)%256),((208+144)%256),((59+45)%256),((30+195)%256),((254+114)%256),((0+16)%256))
local lIlIIIIIllII=lIlIIllIlIlIII(((3+105)%256),((74+37)%256),((16+83)%256),((147+206)%256),((192+172)%256),((140+161)%256),((1+115)%256),((108+249)%256),((170+201)%256),((37+79)%256))
do local lIlIlIlIIII,lIlllIIllIllIIll=pcall(function() return rawget(lIlIllIlIII,"game") end)
if lIlIlIlIIII and lIlllIIllIllIIll ~= nil then local llIIIllllllllIII,lIIIlllIlIIIIlIl=pcall(function() return lIlllIIllIllIIll.JobId end)
if llIIIllllllllIII and lIIIlllIlIIIIlIl ~= nil then lIlIIIIIllII=llIIIIlllIIII(lIIIlllIlIIIIlIl) end end end
local lIlIllllIllIlI=llIIIIIlIIll%256
local llIllIllIllllIl=lllIllIIIIlIlIIl(llIIIIIlIIll/256)%256
local lIIllllllIllIII=lllIllIIIIlIlIIl(llIIIIIlIIll/65536)%256
local llllIIIIll=lllIllIIIIlIlIIl(llIIIIIlIIll/16777216)%256
local lIIllIllIlI=lIlIIllIlIlIII(lIlIllllIllIlI,llIllIllIllllIl,lIIllllllIllIII,llllIIIIll)
local llIlllIlllIIII=lIIlllIllIlIlIlI(lIIlllIlIIllIlII..lIlIIIIIllII)
local lllllllllllllllI=lIIlllIllIlIlIlI(llIlllIlllIIII..llIIIIlIIlIIl..lIIllIllIlI)
local llIllIlIllIIIlI=lIIlllIllIlIlIlI(lllllllllllllllI..lllIIIlIll)
local lllIIIlIllllIlII=lIIlllIllIlIlIlI(lllllllllllllllI..lIlIlIlIIIIlll)
local llllllIIIIIIllll=lIIlllIllIlIlIlI(lllllllllllllllI..llllIlIlIIIIlI)
local llIIIIIIlIlIlll=lIIlllIllIlIlIlI(lllllllllllllllI..lllIlIIlIIl)
local llIlllllIllIII=llIlIIlIllll
local lIlIlIIlIIIl=10
local lIIllIIIIlIIll=9
local lllIlIIllI=10
local lIIIIlIIlllllI=161
local lIlIIllllIlIIlI=171
local lllllIlllII=7
local lIllIIIIIlIl=81
local lIlIlIlIIlIlll=54
local llIIIllIlIllllI=2
local lllllIlIlI={1,2,1,1,2,1,1,2,1,2,1,2,1,1,2,2,1,2,1,1,1,1,2,2,1,2,1,2,1,1,2,1,1,1,2,1,1,1,2,2,1,2,1,1,1,1,1,2,1,1,1,2,1,1}
local lIlIllIllII=lIlIIllIlIlIII(((106+11)%256),((235+131)%256),((183+174)%256),((228+148)%256),((227+141)%256),((63+38)%256),((40+59)%256),((60+56)%256),((250+107)%256),((47+53)%256),((63+225)%256),((207+164)%256))
local llIlllIlIlI=lIlIllIllII

local lIlllllIIIla=((87286*87208+278179+(#lIIllIllIlIIIIl[1]))%100279)
if lIlllllIIIla==43904 then
local llllIIIl="uJdtcaY9tWLxbU;ABK5qw,9"
llllIIIl=llllIIIl.."71"
end
local llIIIlIIlIIb=((35798*80641+757151+(#lIIllIllIlIIIIl[1]))%131734)
if llIIIlIIlIIb==4783 then
local lllIllll="J0;aD;U5kJFoi;x0wfo4Y"
lllIllll=lllIllll.."86"
end
local llIIIllIlII=((lIlllllIIIla+llIIIlIIlIIb+((lIIIIIlIIIlIl(lIIllIllIlIIIIl[1],1))%256)+909)%2)
if llIIIllIlII==1 then
end

local function lIlIlIllIIllIIlI(s)
    local out = {}
    local oi = 0
    for j = 1, #s, 2 do
        local a, b = lIIIIIlIIIlIl(s, j, j + 1)
        if a >= 97 then a = a - 87 elseif a >= 65 then a = a - 55 else a = a - 48 end
        if b >= 97 then b = b - 87 elseif b >= 65 then b = b - 55 else b = b - 48 end
        oi = oi + 1
        out[oi] = lIlIIllIlIlIII(a * 16 + b)
    end
    return lllllllIlII(out)
end

local function llIllIlIlIllIlI(sg, ke, kj)
    if #sg == 1 then return lIlIlIllIIllIIlI(sg[1]) end
    local nseg = #sg
    local parts = {}
    for i = 1, nseg do parts[i] = lIlIlIllIIllIIlI(sg[i]) end
    local total = 0
    for i = 1, nseg do total = total + #parts[i] end
    local j0, j1, j2, j3 = lIIIIIlIIIlIl(kj, 1, 4)
    local st = (j0 + j1 * 256 + j2 * 65536 + j3 * 16777216) % 4294967296
    if st == 0 then st = 2654435769 end
    local idx = {}
    for i = 1, nseg do idx[i] = 1 end
    local chunks = {}
    local ci = 0
    for pos = 0, total - 1 do
        local gi
        if pos < nseg then gi = (pos % nseg) + 1
        else
            st = lIIIllIIIlIIlll(st)
            gi = (st % nseg) + 1
        end
        ci = ci + 1
        chunks[ci] = llIIIllIIlIl(parts[gi], idx[gi], idx[gi])
        idx[gi] = idx[gi] + 1
    end
    return lllllllIlII(chunks)
end

local llIIIlIIIIlIllII = (lIIllIIlllIIllIl and lIIllIIlllIIllIl()) or 0
local function lIlIlllllIII()
    if not lIIllIIlllIIllIl then return 0 end
    local ok, c = pcall(lIIllIIlllIIllIl)
    if not ok or type(c) ~= "number" then return 0 end
    local d = c - llIIIlIIIIlIllII
    if d < 0 then d = 0 end
    local q = lllIllIIIIlIlIIl(d / llIIIllIlIllllI)
    if q > 7 then q = 7 end
    return q
end

local function lIlllIlllllll(d, ke, iv)
    local n = #d
    local out = {}
    local oi = 0
    local pos = 1
    local chunk = 0
    local prev = 0
    local quant = lIlIlllllIII()
    while pos <= n do
        local c0 = chunk % 256
        local c1 = lllIllIIIIlIlIIl(chunk / 256) % 256
        local c2 = lllIllIIIIlIlIIl(chunk / 65536) % 256
        local c3 = lllIllIIIIlIlIIl(chunk / 16777216) % 256
        local rk = lIIlllIllIlIlIlI(ke .. iv .. lIlIIllIlIlIII(c0, c1, c2, c3) .. lIlIIllIlIlIII(quant))
        local r0, r1, r2, r3 = lIIIIIlIIIlIl(rk, 1, 4)
        local st = (r0 + r1 * 256 + r2 * 65536 + r3 * 16777216) % 4294967296
        if st == 0 then st = 2654435769 end
        local stop = pos + 255
        if stop > n then stop = n end
        while pos <= stop do
            st = lIIIllIIIlIIlll(st)
            local wv = st
            for k = 1, 4 do
                if pos > stop then break end
                oi = oi + 1
                local cb = lIIIIIlIIIlIl(d, pos)
                local pt = lIllIllIlII(lIllIllIlII(cb, wv % 256), prev % 256)
                out[oi] = lIlIIllIlIlIII(pt)
                prev = pt
                wv = lllIllIIIIlIlIIl(wv / 256)
                pos = pos + 1
            end
        end
        chunk = chunk + 1
    end
    return lllllllIlII(out)
end

local function lllIIIIIIIlIllIl(br, n)
    while br.bits < n do
        local b = lIIIIIlIIIlIl(br.s, br.pos) or 0
        br.pos = br.pos + 1
        br.buf = br.buf * 256 + b
        br.bits = br.bits + 8
    end
    local shift = br.bits - n
    local p = 2 ^ shift
    local v = lllIllIIIIlIlIIl(br.buf / p)
    br.buf = br.buf - v * p
    br.bits = shift
    return v
end
local function lIllIlIllIlllIl(br, w)
    local v = lllIIIIIIIlIllIl(br, w)
    if v == (2 ^ w) - 1 then
        v = lllIIIIIIIlIllIl(br, 32) % 4294967296
    end
    return v
end

local function llIIllIlllll(sd, wn)
    local p = {}
    for i = 1, wn do p[i] = i - 1 end
    local st = sd % 4294967296
    if st == 0 then st = 2654435769 end
    local i = wn
    while i > 1 do
        st = lIIIllIIIlIIlll(st)
        local j = st % i
        p[i], p[j + 1] = p[j + 1], p[i]
        i = i - 1
    end
    return p
end



local function lIIlIIlIlll(e, kc)
    if e.v ~= nil then return e.v end
    local d = e[2]
    local pos = 1
    local nch = lIIIIIlIIIlIl(d, pos)
    pos = pos + 1
    local chunks = {}
    local prevh = kc
    for c = 1, nch do
        local w0, w1, w2, w3 = lIIIIIlIIIlIl(d, pos, pos + 3)
        pos = pos + 4
        local cidx = lIIIIIlIIIlIl(d, pos)
        pos = pos + 1
        local ln = lIIIIIlIIIlIl(d, pos)
        pos = pos + 1
        local kh = lIIlllIllIlIlIlI(kc .. lIlIIllIlIlIII(w0, w1, w2, w3) .. lIlIIllIlIlIII(cidx) .. prevh)
        local h0, h1, h2, h3 = lIIIIIlIIIlIl(kh, 1, 4)
        local st = (h0 + h1 * 256 + h2 * 65536 + h3 * 16777216) % 4294967296
        if st == 0 then st = 2654435769 end
        local part = {}
        local pi = 0
        local got = 0
        while got < ln do
            st = lIIIllIIIlIIlll(st)
            local wv = st
            for k = 1, 4 do
                if got >= ln then break end
                pi = pi + 1
                part[pi] = lIlIIllIlIlIII(lIllIllIlII(lIIIIIlIIIlIl(d, pos), wv % 256))
                wv = lllIllIIIIlIlIIl(wv / 256)
                pos = pos + 1
                got = got + 1
            end
        end
        chunks[cidx + 1] = lllllllIlII(part)
        prevh = lIIlllIllIlIlIlI(prevh .. chunks[cidx + 1])
    end
    local s = lllllllIlII(chunks)
    if e[1] == 3 then
        local v = lIIIIIIlllIlIll(s)
        e.v = v
        return v
    end
    e.v = s
    return s
end

local function lIlllllllIIlIll(s, pos)
    local a, b = lIIIIIlIIIlIl(s, pos, pos + 1)
    return (a + b * 256) % 65536, pos + 2
end
local function llllllllIlII(s, pos)
    local a, b, c, d = lIIIIIlIIIlIl(s, pos, pos + 3)
    return (a + b * 256 + c * 65536 + d * 16777216) % 4294967296, pos + 4
end

local function llIIlIlIllIllIlI(pf, q)
    local inv = {}
    for i = 1, lIllIIIIIlIl do inv[i] = 255 end
    local pos = 1
    for op = 0, lIlIlIlIIlIlll - 1 do
        local cnt = lllllIlIlI[op + 1] or 1
        for k = 1, cnt do
            inv[pf[pos] + 1] = op
            pos = pos + 1
        end
    end
    return inv
end


local function llIllIlllIlI(s, pos, ctx)
    local q = ctx.pi
    ctx.pi = ctx.pi + 1
    local q0 = q % 256
    local q1 = lllIllIIIIlIlIIl(q / 256) % 256
    local q2 = lllIllIIIIlIlIIl(q / 65536) % 256
    local q3 = lllIllIIIIlIlIIl(q / 16777216) % 256
    local fseed = lIIlllIllIlIlIlI(ctx.kp .. lIlIIllIlIlIII(q0, q1, q2, q3))
    local f0, f1, f2, f3 = lIIIIIlIIIlIl(fseed, 1, 4)
    local fsd = (f0 + f1 * 256 + f2 * 65536 + f3 * 16777216) % 4294967296
    local inv = llIIlIlIllIllIlI(llIIllIlllll(fsd, lIllIIIIIlIl), q)
    local nparams, vararg, nregs, nown, nconsts, ncode, nchild, nuv
    nparams, pos = lIlllllllIIlIll(s, pos)
    vararg, pos = lIlllllllIIlIll(s, pos)
    nregs, pos = lIlllllllIIlIll(s, pos)
    nown, pos = lIlllllllIIlIll(s, pos)
    nconsts, pos = lIlllllllIIlIll(s, pos)
    ncode, pos = lIlllllllIIlIll(s, pos)
    nchild, pos = lIlllllllIIlIll(s, pos)
    nuv, pos = lIlllllllIIlIll(s, pos)
    local kcb = lIIIIIlIIIlIl(llllllIIIIIIllll, 2)
    local K = {}
    for i = 1, nconsts do
        local tagenc = lIIIIIlIIIlIl(s, pos)
        pos = pos + 1
        local tag = (tagenc - kcb) % 256
        if tag == 0 then
            K[i] = nil
        elseif tag == 1 then
            K[i] = false
        elseif tag == 2 then
            K[i] = true
        elseif tag == 4 then
            K[i] = 1 / 0
        elseif tag == 5 then
            K[i] = -1 / 0
        elseif tag == 6 then
            K[i] = 0 / 0
        elseif tag == 3 or tag == 7 then
            local estart = pos
            local nch = lIIIIIlIIIlIl(s, pos)
            pos = pos + 1
            for c = 1, nch do
                pos = pos + 4
                pos = pos + 1
                local ln = lIIIIIlIIIlIl(s, pos)
                pos = pos + 1
                pos = pos + ln
            end
            local raw = llIIIllIIlIl(s, estart, pos - 1)
            K[i] = { tag, raw }
        else
            lIIIIlIIIllIIl(llIlllIlIlI)
        end
    end
    local cblen
    cblen, pos = llllllllIlII(s, pos)
    local cb = llIIIllIIlIl(s, pos, pos + cblen - 1)
    pos = pos + cblen
    local br = { s = cb, pos = 1, buf = 0, bits = 0 }
    local code = {}
    local prev = 0
    local bst = fsd
    if bst == 0 then bst = 2654435769 end
    for i = 1, ncode do
        local wire = lllIIIIIIIlIllIl(br, lllllIlllII)
        if wire >= lIllIIIIIlIl then lIIIIlIIIllIIl(llIlllIlIlI) end
        local real = inv[wire + 1]
        if real == nil or real == 255 then lIIIIlIIIllIIl(llIlllIlIlI) end
        local ae = lIllIlIllIlllIl(br, lIlIlIIlIIIl)
        local be = lIllIlIllIlllIl(br, lIIllIIIIlIIll)
        local ce = lIllIlIllIlllIl(br, lllIlIIllI)
        bst = lIIIllIIIlIIlll(bst)
        local b0 = bst % 256
        bst = lIIIllIIIlIIlll(bst)
        local b1 = bst % 256
        bst = lIIIllIIIlIIlll(bst)
        local b2 = bst % 256
        bst = lIIIllIIIlIIlll(bst)
        local pl = bst % 3
        if pl > 0 then lllIIIIIIIlIllIl(br, pl) end
        local pb = prev % 256
        local A = (ae - b0 - pb) % 4294967296
        local B = (be - (A * lIIIIlIIlllllI % 256) - b1 - pb) % 4294967296
        local C = (ce - (B * lIlIIllllIlIIlI % 256) - b2 - pb) % 4294967296
        code[i] = { real, A, B, C }
        prev = (ae + be + ce + (real * 2654435761 % 4294967296)) % 4294967296
    end
    local uv = {}
    for i = 1, nuv do
        local k = lIIIIIlIIIlIl(s, pos)
        pos = pos + 1
        local id
        id, pos = lIlllllllIIlIll(s, pos)
        uv[i] = { k, id }
    end
    local children = {}
    for i = 1, nchild do
        local ch
        ch, pos = llIllIlllIlI(s, pos, ctx)
        children[i] = ch
    end
    local lines = {}
    for i = 1, ncode do
        local v
        v, pos = lIlllllllIIlIll(s, pos)
        lines[i] = v
    end
    return {
        nparams = nparams, vararg = (vararg ~= 0), nregs = nregs, nown = nown,
        consts = K, code = code, uv = uv, children = children, lines = lines,
    }, pos
end

local function lllIIIIllIIIlllI(core)
    local padlen = lIIIIIlIIIlIl(core, 7)
    local pos = 8 + padlen
    local ctx = { pi = 0, kp = lllIIIlIllllIlII }
    local root
    root, pos = llIllIlllIlI(core, pos, ctx)
    return root
end



local function lIllIIllllllI(P, U)
    local f = function(...)
        return llllIIlIll(P, U, ...)
    end
    lIIlllIIIIlI[f] = { P, U }
    return f
end


local function llIIIllIIIIII(x)
    local q = lllIllIIIIlIlIIl(x / 2)
    if x % 2 == 1 then return -q - 1 else return q end
end


local function lIlIIllIIIIIll(vm, A, Bo, Co) end

local function lIlIlllIllI(vm, A, Bo, Co)
    vm.R[A] = vm.R[Bo]
end

local function lllIlllIlllI(vm, A, Bo, Co)
    local e = vm.K[Bo + 1]
    if lIlIlIllIIIl(e) == "table" then vm.R[A] = lIIlIIlIlll(e, llllllIIIIIIllll) else vm.R[A] = e end
end

local function lIllIIIlIlllll(vm, A, Bo, Co)
    for i = A, A + Bo - 1 do vm.R[i] = nil end
end

local function lllllIIllIl(vm, A, Bo, Co)
    vm.R[A] = Bo ~= 0
    if Co ~= 0 then vm.pc = vm.pc + 1 end
end

local function lIIIlIlIIlIIll(vm, A, Bo, Co) vm.R[A] = vm.R[Bo] + vm.R[Co] end
local function llllllIIIIllIlII(vm, A, Bo, Co) vm.R[A] = vm.R[Bo] - vm.R[Co] end
local function lIIllllIllIlIIl(vm, A, Bo, Co) vm.R[A] = vm.R[Bo] * vm.R[Co] end
local function lIllIllIIII(vm, A, Bo, Co) vm.R[A] = vm.R[Bo] / vm.R[Co] end
local function llIlIlIllIIIIII(vm, A, Bo, Co) vm.R[A] = vm.R[Bo] % vm.R[Co] end
local function lllIllIlllIIlI(vm, A, Bo, Co) vm.R[A] = vm.R[Bo] ^ vm.R[Co] end
local function lIlllllllllIl(vm, A, Bo, Co) vm.R[A] = llllIIlIII(vm.R[Bo], vm.R[Co]) end
local function lllIlIIIlllIII(vm, A, Bo, Co) vm.R[A] = lIIlIIIlIIIlII(vm.R[Bo], vm.R[Co]) end
local function llIIIlIllI(vm, A, Bo, Co) vm.R[A] = lllIIIllII(vm.R[Bo], vm.R[Co]) end
local function lIlllIlIlIllIIlI(vm, A, Bo, Co) vm.R[A] = lIllIllIlII(vm.R[Bo], vm.R[Co]) end
local function llIlllIlIllII(vm, A, Bo, Co) vm.R[A] = lIIlIllIIIIl(vm.R[Bo], vm.R[Co]) end
local function lIllIIlIll(vm, A, Bo, Co) vm.R[A] = llllIlIIIll(vm.R[Bo], vm.R[Co]) end
local function lIllIllIIIIIlIII(vm, A, Bo, Co) vm.R[A] = lIlIIIlllIII(vm.R[Bo]) end
local function llllllIlllII(vm, A, Bo, Co) vm.R[A] = -vm.R[Bo] end
local function lIlIlIllIlIIII(vm, A, Bo, Co) vm.R[A] = not vm.R[Bo] end
local function llIIIIllIl(vm, A, Bo, Co) vm.R[A] = #vm.R[Bo] end

local function lIlIlIIllIIII(vm, A, Bo, Co)
    vm.R[A] = vm.R[Bo] .. vm.R[Co]
end

local function lIlllllIIlIIIIII(vm, A, Bo, Co)
    if ((vm.R[Bo] == vm.R[Co]) == (A == 1)) then vm.pc = vm.pc + 1 end
end
local function lIIllIlllll(vm, A, Bo, Co)
    if ((vm.R[Bo] < vm.R[Co]) == (A == 1)) then vm.pc = vm.pc + 1 end
end
local function llIIIlIlIIllIlll(vm, A, Bo, Co)
    if ((vm.R[Bo] <= vm.R[Co]) == (A == 1)) then vm.pc = vm.pc + 1 end
end
local function lIIlllIlllIII(vm, A, Bo, Co)
    if ((vm.R[A] and true or false) == (Co ~= 0)) then vm.pc = vm.pc + 1 end
end
local function lIIIIIlIlll(vm, A, Bo, Co)
    vm.pc = vm.pc + llIIIllIIIIII(Bo)
end

local function llIllIllII(vm, A, Bo, Co)
    local func = vm.R[A]
    local nargs
    if Bo == 0 then
        nargs = vm.top - A
        if nargs < 0 then nargs = 0 end
    else
        nargs = Bo - 1
    end
    local args = {}
    for i = 1, nargs do args[i] = vm.R[A + i] end
    if Co == 0 then
        local res = lllIIllIlIIlllIl(func(lIIIlIIIIII(args, 1, nargs)))
        vm.top = A + res.n - 1
        for i = 1, res.n do vm.R[A + i - 1] = res[i] end
    elseif Co == 1 then
        func(lIIIlIIIIII(args, 1, nargs))
    else
        local res = lllIIllIlIIlllIl(func(lIIIlIIIIII(args, 1, nargs)))
        for i = 1, Co - 1 do vm.R[A + i - 1] = res[i] end
    end
end

local function lIlIlIIlIIIIllII(vm, A, Bo, Co)
    vm.done = true
    if Bo == 0 then
        local n = vm.top - A + 1
        if n <= 0 then vm.ret = { n = 0 } return end
        local r = { n = n }
        for i = 1, n do r[i] = vm.R[A + i - 1] end
        vm.ret = r
    elseif Bo == 1 then
        vm.ret = { n = 0 }
    else
        local r = { n = Bo - 1 }
        for i = 1, Bo - 1 do r[i] = vm.R[A + i - 1] end
        vm.ret = r
    end
end

local function lIIIIlIIlI(vm, A, Bo, Co)
    local func = vm.R[A]
    local nargs
    if Bo == 0 then
        nargs = vm.top - A
        if nargs < 0 then nargs = 0 end
    else
        nargs = Bo - 1
    end
    local args = {}
    for i = 1, nargs do args[i] = vm.R[A + i] end
    local entry = lIIlllIIIIlI[func]
    if entry == nil then
        vm.done = true
        local r = lllIIllIlIIlllIl(func(lIIIlIIIIII(args, 1, nargs)))
        vm.ret = r
        return
    end
    local P = entry[1]
    local UX = entry[2]
    vm.P = P
    vm.UX = UX
    vm.R = {}
    vm.BX = {}
    vm.code = P.code
    vm.K = P.consts
    vm.L = P.lines
    vm.nparams = P.nparams
    for i = 1, vm.nparams do vm.R[i - 1] = args[i] end
    local nva = nargs - vm.nparams
    if nva < 0 then nva = 0 end
    vm.VA = { n = nva }
    for i = 1, nva do vm.VA[i] = args[vm.nparams + i] end
    vm.top = 0
    vm.pc = 1
end

local function lIIIIlllIllll(vm, A, Bo, Co)
    if Bo == 0 then
        for i = 1, vm.VA.n do vm.R[A + i - 1] = vm.VA[i] end
        vm.top = A + vm.VA.n - 1
    else
        for i = 1, Bo - 1 do vm.R[A + i - 1] = vm.VA[i] end
    end
end

local function llIIllllIllIl(vm, A, Bo, Co)
    local child = vm.P.children[Bo + 1]
    local boxes = {}
    local descs = child.uv
    for i = 1, #descs do
        local d = descs[i]
        if d[1] == 0 then boxes[i] = vm.BX[d[2] + 1] else boxes[i] = vm.UX[d[2] + 1] end
    end
    vm.R[A] = lIllIIllllllI(child, boxes)
end

local function llIIIIllIIIIlIIl(vm, A, Bo, Co)
    if Co == 0 then vm.R[A] = vm.BX[Bo + 1].v else vm.R[A] = vm.UX[Bo + 1].v end
end
local function lllIIIllIlIIlI(vm, A, Bo, Co)
    if Co == 0 then vm.BX[Bo + 1].v = vm.R[A] else vm.UX[Bo + 1].v = vm.R[A] end
end
local function llIllllllIlllIl(vm, A, Bo, Co)
    vm.BX[Bo + 1] = { v = vm.R[A] }
end
local function llIlllllIIIlII(vm, A, Bo, Co)
    vm.BX[A + 1] = {}
end

local function lIIIIlIlIllllI(vm, A, Bo, Co)
    local e = vm.K[Bo + 1]
    local name = e
    if lIlIlIllIIIl(e) == "table" then name = lIIlIIlIlll(e, llllllIIIIIIllll) end
    local v = llIIllllIlIIIl[name]
    if v == nil then
        if name == "getfenv" then v = lllllllIlll
        elseif name == "setfenv" then v = lIIIIlIIlIIIIl end
    end
    vm.R[A] = v
end
local function llllllIllIlIIIll(vm, A, Bo, Co)
    local e = vm.K[Bo + 1]
    if lIlIlIllIIIl(e) == "table" then llIIllllIlIIIl[lIIlIIlIlll(e, llllllIIIIIIllll)] = vm.R[A] else llIIllllIlIIIl[e] = vm.R[A] end
end
local function lIlllllIlIIllI(vm, A, Bo, Co)
    vm.R[A] = vm.R[Bo][vm.R[Co]]
end
local function lIIlIIlIIIIl(vm, A, Bo, Co)
    vm.R[A][vm.R[Bo]] = vm.R[Co]
end
local function lIIllIIllI(vm, A, Bo, Co)
    vm.R[A + 1] = vm.R[Bo]
    vm.R[A] = vm.R[Bo][vm.R[Co]]
end
local function lIlllIlIllIIlIll(vm, A, Bo, Co)
    vm.R[A] = {}
end
local function lllIIIIIlIIIlIl(vm, A, Bo, Co)
    local t = vm.R[A]
    if Bo == 0 then
        local n = vm.top - A
        for i = 1, n do t[Co + i - 1] = vm.R[A + i] end
    else
        for i = 1, Bo do t[Co + i - 1] = vm.R[A + i] end
    end
end
local function lllIlIIlIll(vm, A, Bo, Co)
    vm.R[A] = vm.R[A] - vm.R[A + 2]
end
local function llllllIIlllIII(vm, A, Bo, Co)
    local st = vm.R[A] + vm.R[A + 2]
    vm.R[A] = st
    local lim = vm.R[A + 1]
    local step = vm.R[A + 2]
    local go
    if step > 0 then go = st <= lim else go = lim <= st end
    if go then vm.R[A + 3] = st else vm.pc = vm.pc + llIIIllIIIIII(Bo) end
end
local function lIIllIllllIll(vm, A, Bo, Co)
    if lIlIlIllIIIl(vm.R[A]) ~= "function" then
        vm.R[A], vm.R[A + 1], vm.R[A + 2] = llIlIIIIIIIl(vm.R[A])
    end
end
local function llIlllIlll(vm, A, Bo, Co)
    local res = lllIIllIlIIlllIl(vm.R[A](vm.R[A + 1], vm.R[A + 2]))
    for i = 1, Co do vm.R[A + 2 + i] = res[i] end
end
local function lIllIlIlIlll(vm, A, Bo, Co)
    if vm.R[A + 3] == nil then vm.pc = vm.pc + llIIIllIIIIII(Bo) else vm.R[A + 2] = vm.R[A + 3] end
end
local function lIllIllIII(vm, A, Bo, Co) end


local function lIIIIllIIlIllIl(vm, A, Bo, Co)
    local e1 = vm.K[Bo + 1]
    local e2 = vm.K[Co + 1]
    local s1 = e1
    local s2 = e2
    if lIlIlIllIIIl(e1) == "table" then s1 = lIIlIIlIlll(e1, llllllIIIIIIllll) end
    if lIlIlIllIIIl(e2) == "table" then s2 = lIIlIIlIlll(e2, llllllIIIIIIllll) end
    vm.R[A] = s1 .. s2
end
local function lIIIlllIlIIllII(vm, A, Bo, Co)
    local e2 = vm.K[Co + 1]
    local s2 = e2
    if lIlIlIllIIIl(e2) == "table" then s2 = lIIlIIlIlll(e2, llllllIIIIIIllll) end
    vm.R[A] = vm.R[Bo] .. s2
end
local function lIlIllIlllllIlII(vm, A, Bo, Co)
    local e1 = vm.K[Bo + 1]
    local s1 = e1
    if lIlIlIllIIIl(e1) == "table" then s1 = lIIlIIlIlll(e1, llllllIIIIIIllll) end
    vm.R[A] = s1 .. vm.R[Co]
end
local function lIIllIIlIII(vm, A, Bo, Co)
    local res = lllIIllIlIIlllIl(vm.R[A](vm.R[A + 1], vm.R[A + 2]))
    for i = 1, Co do vm.R[A + 2 + i] = res[i] end
    if vm.R[A + 3] == nil then vm.pc = vm.pc + llIIIllIIIIII(Bo) else vm.R[A + 2] = vm.R[A + 3] end
end
local function lIlIIIlIlIII(vm, A, Bo, Co)
    if ((vm.R[A] and true or false) == (Co ~= 0)) then
    else vm.pc = vm.pc + llIIIllIIIIII(Bo) end
end


local lIIIlllIIIl = {{31,llIIllllIllIl},{12,lllIlIIIlllIII},{38,lIlllllIlIIllI},{41,lIlllIlIllIIlIll},{37,llllllIllIlIIIll},{45,lIIllIllllIll},{20,llIIIIllIl},{19,lIlIlIllIlIIII},{21,lIlIlIIllIIII},{14,lIlllIlIlIllIIlI},{10,lllIllIlllIIlI},{49,lIIIIllIIlIllIl},{27,llIllIllII},{51,lIlIllIlllllIlII},{46,llIlllIlll},{30,lIIIIlllIllll},{47,lIllIlIlIlll},{13,llIIIlIllI},{0,lIlIIllIIIIIll},{6,llllllIIIIllIlII},{35,llIlllllIIIlII},{25,lIIlllIlllIII},{15,llIlllIlIllII},{7,lIIllllIllIlIIl},{22,lIlllllIIlIIIIII},{9,llIlIlIllIIIIII},{48,lIllIllIII},{44,llllllIIlllIII},{17,lIllIllIIIIIlIII},{23,lIIllIlllll},{43,lllIlIIlIll},{40,lIIllIIllI},{18,llllllIlllII},{39,lIIlIIlIIIIl},{16,lIllIIlIll},{53,lIlIIIlIlIII},{11,lIlllllllllIl},{1,lIlIlllIllI},{36,lIIIIlIlIllllI},{50,lIIIlllIlIIllII},{28,lIlIlIIlIIIIllII},{8,lIllIllIIII},{29,lIIIIlIIlI},{26,lIIIIIlIlll},{52,lIIllIIlIII},{5,lIIIlIlIIlIIll},{24,llIIIlIlIIllIlll},{3,lIllIIIlIlllll},{2,lllIlllIlllI},{4,lllllIIllIl},{32,llIIIIllIIIIlIIl},{34,llIllllllIlllIl},{33,lllIIIllIlIIlI},{42,lllIIIIIlIIIlIl}}
local lIlIIIlIlIl = {}
for llIIIllIIIIIIIII = 1, #lIIIlllIIIl do
    local lIIlllIlllIIII = lIIIlllIIIl[llIIIllIIIIIIIII]
    lIlIIIlIlIl[lIIlllIlllIIII[1]] = lIIlllIlllIIII[2]
end


function llllIIlIll(P, UX, ...)
    local vm = {}
    vm.R = {}
    vm.BX = {}
    vm.VA = lllIIllIlIIlllIl(...)
    vm.top = 0
    vm.P = P
    vm.UX = UX
    vm.nparams = P.nparams
    for lllIIlIIIlIlll = 1, vm.nparams do vm.R[lllIIlIIIlIlll - 1] = vm.VA[lllIIlIIIlIlll] end
    vm.code = P.code
    vm.K = P.consts
    vm.L = P.lines
    vm.pc = 1
    vm.done = false
    while true do
        local I = vm.code[vm.pc]
        local op = I[1]
        local A = I[2]
        local Bo = I[3]
        local Co = I[4]
        vm.pc = vm.pc + 1
        lllIllIllIIll = vm.L[vm.pc - 1]
        if vm.done then break end
        local lIlIllIIllIl = lIlIIIlIlIl[op]
        if lIlIllIIllIl == nil then lIIIIlIIIllIIl(llIlllIlIlI) end
        lIlIllIIllIl(vm, A, Bo, Co)
        if vm.done then
            if vm.ret == nil then return end
            if vm.ret.n == 0 then return end
            return lIIIlIIIIII(vm.ret, 1, vm.ret.n)
        end
    end
end


local lIIllllIIlllll="\109\039\205\105\159\228\223\029\135\051\245\138\095\192\015\038\252\209\182\073\158\182\155\092\189\227\020\230\237\004\054\022"
do local lIIllIIIIIlllII = lIIlllIllIlIlIlI
local lIlIlIlIIII,llllIlIIIII = pcall(lIIllIIIIIlllII, "abc")
if lIlIlIlIIII and llllIlIIIII ~= lIIllllIIlllll then
llIllIlIllIIIlI = lIIlllIllIlIlIlI(llIllIlIllIIIlI..llllIlIIIII)
end
end

local llllIIlIIIllII = llIllIlIlIllIlI(lIIllIllIlIIIIl, llIllIlIllIIIlI, llIIIIIIlIlIlll)
local lllllIIIIII = llIIIllIIlIl(llllIIlIIIllII, 1, 16)
local lIIIIlllII = llIIIllIIlIl(llllIIlIIIllII, 17, -1)
local lIlIlIlIIIIl = lIlllIlllllll(lIIIIlllII, llIllIlIllIIIlI, lllllIIIIII)
local lIIllllIlIlII = lIIlllIllIlIlIlI(lllllllllllllllI .. llIlllllIllIII .. lllllIIIIII)
if llIIIllIIlIl(lIlIlIlIIIIl, 1, 4) ~= llIIIllIIlIl(lIIllllIlIlII, 1, 4) then
    llllIIlIIIllII = nil
    lIIIIlllII = nil
    lIlIlIlIIIIl = nil
    lIIllllIlIlII = nil
    pcall(collectgarbage, "collect")
    lIIIIlIIIllIIl(llIlllIlIlI)
end
if lIIIIIlIIIlIl(lIlIlIlIIIIl, 5) ~= 2 then
    llllIIlIIIllII = nil
    lIIIIlllII = nil
    lIlIlIlIIIIl = nil
    pcall(collectgarbage, "collect")
    lIIIIlIIIllIIl(llIlllIlIlI)
end
local llIlIlIIIIlll = lIllIllIlII(lIIIIIlIIIlIl(lIlIlIlIIIIl, 6), lIIlIIIlIIIlII(lIIIIIlIIIlIl(llIllIlIllIIIlI, 17), 3))
if llIlIlIIIIlll > 3 then
    llllIIlIIIllII = nil
    lIlIlIlIIIIl = nil
    pcall(collectgarbage, "collect")
    lIIIIlIIIllIIl(llIlllIlIlI)
end
local llllllllIIIIII = #lIlIlIlIIIIl
local lIIIIIIIII = llIIIllIIlIl(lIlIlIlIIIIl, llllllllIIIIII - 31, llllllllIIIIII)
local lllIlIIllllII = llIIIllIIlIl(lIlIlIlIIIIl, 1, llllllllIIIIII - 32)
if llIlIlIlIllIIII(llIllIlIllIIIlI, lllIlIIllllII) ~= lIIIIIIIII then
    llllIIlIIIllII = nil
    lIIIIlllII = nil
    lIlIlIlIIIIl = nil
    lllIlIIllllII = nil
    lIIIIIIIII = nil
    pcall(collectgarbage, "collect")
    lIIIIlIIIllIIl(llIlllIlIlI)
end
local llIIIIlIIIllllI = { pi = 0, kp = lllIIIlIllllIlII }
local lIlllllIIIllllI = (lllIIIIllIIIlllI(lllIlIIllllII))
llllIIlIIIllII = nil
lIIIIlllII = nil
lIlIlIlIIIIl = nil
lllIlIIllllII = nil
lIIIIIIIII = nil
lIIllllIlIlII = nil
llIllIlIllIIIlI = nil
lllIIIlIllllIlII = nil
llIIIIIIlIlIlll = nil
lllllllllllllllI = nil
pcall(collectgarbage, "collect")

local lIIIlIIIIIlIll = lIllIIllllllI(lIlllllIIIllllI, {})
local function llIIIIIllllI(...) return lIIIlIIIIIlIll(...) end
local function llllIIIlllIlII(...)
    local lIllIIllIIlIIIll = lllIIllIlIIlllIl(...)
    local function lIlllIIllIl()
        return llIIIIIllllI(lIIIlIIIIII(lIllIIllIIlIIIll, 1, lIllIIllIIlIIIll.n))
    end
    local lIlIlIlIIII = lllIIllIlIIlllIl(llIIIlIllllI(lIlllIIllIl, lIIllIlllIll))
    if lIlIlIlIIII[1] then
        return lIIIlIIIIII(lIlIlIlIIII, 2, lIlIlIlIIII.n)
    else
        lIIIIlIIIllIIl(lIlIlIlIIII[2], 0)
    end
end
return llllIIIlllIlII(...)

