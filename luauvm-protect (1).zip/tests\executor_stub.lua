-- executor_stub.lua: mocks Roblox executor environment for testing
-- Provides game, workspace, task, getgenv, identifyexecutor, Instance, etc.
-- Load before the obfuscated payload in tests.

local _G = _G

-- task library (Roblox)
task = task or {}
if not task.wait then
    function task.wait(t) return t or 0 end
end
if not task.spawn then
    function task.spawn(f, ...) local co = coroutine.create(f) coroutine.resume(co, ...) end
end
if not task.delay then
    function task.delay(t, f, ...) f(...) end
end
if not task.defer then
    function task.defer(f, ...) f(...) end
end

-- game / workspace
if not game then
    local PlayersSvc = {
        Name = "Players",
        LocalPlayer = { Name = "TestPlayer", UserId = 12345 },
        GetPlayers = function(self) return { self.LocalPlayer } end,
    }
    local ReplicatedStorageSvc = {
        Name = "ReplicatedStorage",
        WaitForChild = function(self, n) return { Name = n } end,
    }
    local services = {
        Players = PlayersSvc,
        ReplicatedStorage = ReplicatedStorageSvc,
        Workspace = { Name = "Workspace" },
    }
    game = {
        GetService = function(self, n)
            local s = services[n]
            if s then return s end
            return { Name = n }
        end,
    }
end
workspace = workspace or game:GetService("Workspace")

-- getgenv / executor UNC
if not getgenv then
    function getgenv() return _G end
end
if not identifyexecutor then
    function identifyexecutor() return "TestExec" end
end
if not gethui then
    function gethui() return { Name = "Gui" } end
end

-- Instance mock (supports .new + basic properties + RemoteEvent)
if not Instance then
    Instance = {}
    function Instance.new(cls)
        local obj = { ClassName = cls, Name = cls }
        if cls == "RemoteEvent" then
            obj._fired = {}
            function obj:FireServer(...) self._fired[#self._fired+1] = { ... } end
            function obj:FireClient(...) end
            function obj:FireAllClients(...) end
            obj.OnServerEvent = { Connect = function() end }
            obj.OnClientEvent = { Connect = function() end }
        end
        if cls == "Part" then
            obj.Position = { X = 0, Y = 0, Z = 0 }
            obj.Anchored = false
        end
        return obj
    end
end

-- Common Roblox value types (pass-through mocks)
if not Vector2 then Vector2 = { new = function(x, y) return { X = x, Y = y } end } end
if not Vector3 then Vector3 = { new = function(x, y, z) return { X = x, Y = y, Z = z } end } end
if not UDim2 then UDim2 = { new = function(...) return { ... } end } end
if not Color3 then Color3 = { new = function(r, g, b) return { R = r, G = g, B = b } end } end
if not CFrame then CFrame = { new = function(...) return { ... } end } end
