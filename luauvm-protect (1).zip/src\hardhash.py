"""Per-build ARX hash (v3): randomized rotations, round count, IVs, K-table.

Replaces stock SHA256. Each build gets fresh params derived from the
build RNG; Python and emitted Lua implement the identical algorithm, so
digests match. No fixed H0/KK literals appear in output: tables are split
into 2-4 shuffled chunks and reconstructed with arithmetic.
"""
import random

MASK32 = 0xFFFFFFFF


def gen_params(rng: random.Random) -> dict:
    """Generate per-build hash params. Deterministic given rng."""
    # 6 rotation amounts, each 3..29, all distinct-ish
    rots = []
    while len(rots) < 6:
        v = rng.randrange(3, 30)
        if v not in rots:
            rots.append(v)
    r0, r1, r2, r3, r4, r5 = rots
    # Leaner/faster: 32..48 rounds (was 56..80). Still per-build ARX,
    # no stock constants; cuts K-table size ~40% and hash cost ~40%,
    # which dominates loader time (rekeys, const keys, MAC).
    nrounds = rng.randrange(32, 49)  # 32..48 inclusive
    h0 = [rng.randrange(0, 2 ** 32) for _ in range(8)]
    k = [rng.randrange(0, 2 ** 32) for _ in range(nrounds)]
    return {"rots": (r0, r1, r2, r3, r4, r5), "rounds": nrounds, "h0": h0, "k": k}


def _rotr(x: int, n: int) -> int:
    n &= 31
    if n == 0:
        return x & MASK32
    return (((x >> n) | (x << (32 - n))) & MASK32)


def _shr(x: int, n: int) -> int:
    return (x >> n) & MASK32


def digest(msg: bytes, p: dict) -> bytes:
    """ARX digest parameterized by p. SHA256-shaped, nonstandard constants."""
    r0, r1, r2, r3, r4, r5 = p["rots"]
    nr = p["rounds"]
    ml = len(msg)
    hi = (ml >> 29) & MASK32
    lo = (ml * 8) & MASK32
    padlen = (56 - ((ml + 1) % 64)) % 64
    data = msg + b"\x80" + b"\x00" * padlen + hi.to_bytes(4, "big") + lo.to_bytes(4, "big")
    h = list(p["h0"])
    k = p["k"]
    for off in range(0, len(data), 64):
        w = [int.from_bytes(data[off + i * 4:off + i * 4 + 4], "big") for i in range(16)]
        # message schedule with randomized rots
        for i in range(16, 64 if nr >= 64 else nr):
            if i >= nr:
                break
            x = w[i - 15]
            s0 = (_rotr(x, r0) ^ _rotr(x, r1) ^ _shr(x, 3)) & MASK32
            y = w[i - 2]
            s1 = (_rotr(y, r2) ^ _rotr(y, r3) ^ _shr(y, 10)) & MASK32
            w.append((w[i - 16] + s0 + w[i - 7] + s1) & MASK32)
        while len(w) < nr:
            w.append(0)
        a, b, c, d, e, f, g, hh = h
        for i in range(nr):
            S1 = (_rotr(e, r4) ^ _rotr(e, r5) ^ _rotr(e, (r4 + r5) % 32 or 1)) & MASK32
            ch = ((e & f) ^ ((~e) & g)) & MASK32
            t1 = (hh + S1 + ch + k[i % len(k)] + w[i]) & MASK32
            S0 = (_rotr(a, r0) ^ _rotr(a, r1) ^ _rotr(a, r2)) & MASK32
            mj = ((a & b) ^ (a & c) ^ (b & c)) & MASK32
            t2 = (S0 + mj) & MASK32
            hh, g, f, e, d, c, b, a = g, f, e, (d + t1) & MASK32, c, b, a, (t1 + t2) & MASK32
        h = [(h[j] + v) & MASK32 for j, v in enumerate((a, b, c, d, e, f, g, hh))]
    return b"".join(v.to_bytes(4, "big") for v in h)


def hmac(key: bytes, msg: bytes, p: dict) -> bytes:
    if len(key) > 64:
        key = digest(key, p)
    ip = bytes(b ^ 0x36 for b in key.ljust(64, b"\x00"))
    op = bytes(b ^ 0x5C for b in key.ljust(64, b"\x00"))
    return digest(op + digest(ip + msg, p), p)


def obf_u32(rng: random.Random, v: int) -> str:
    """Render u32 as decimal-only expression (never hex of v)."""
    v &= MASK32
    style = rng.randrange(0, 4)
    if style == 0:
        a = rng.randrange(0, 2 ** 32)
        b = (v - a) & MASK32
        return f"(({a}+{b})%4294967296)"
    if style == 1:
        a = rng.randrange(1, 100000) | 1
        # solve a*q + r = v
        q = rng.randrange(0, 2 ** 32 // a)
        r = (v - (a * q & MASK32)) & MASK32
        return f"(({a}*{q}+{r})%4294967296)"
    if style == 2:
        a = rng.randrange(0, 2 ** 32)
        b = rng.randrange(0, 2 ** 32)
        c = (v - a - b) & MASK32
        return f"(({a}+{b}+{c})%4294967296)"
    half = v // 2
    rem = v - half * 2
    return f"(({half}*2+{rem})%4294967296)"


def obf_byte(rng: random.Random, v: int) -> str:
    """Render byte 0..255 as arithmetic (no bare literal when possible)."""
    v &= 0xFF
    if rng.randrange(0, 2):
        a = rng.randrange(0, 256)
        b = (v - a) & 0xFF
        return f"(({a}+{b})%256)"
    a = rng.randrange(1, 256)
    # v = (a + b) % 256
    b = (v - a) & 0xFF
    return f"(({a}+{b})%256)"


def lua_params_code(rng: random.Random, p: dict, prefix: str) -> str:
    """Emit Lua code reconstructing H0 + K from 2-4 shuffled chunks.

    Returns Lua source defining prefix_H (8) and prefix_K (rounds) tables.
    All u32s rendered via obf_u32; chunk order shuffled with index map.
    """
    nch = rng.randrange(2, 4)
    # split K indices into nch shuffled chunks
    idx = list(range(len(p["k"])))
    rng.shuffle(idx)
    chunks = [[] for _ in range(nch)]
    for pos, ki in enumerate(idx):
        chunks[pos % nch].append(ki)
    lines = []
    for ci, members in enumerate(chunks):
        vals = ",".join(obf_u32(rng, p["k"][ki]) for ki in members)
        order = ",".join(str(ki + 1) for ki in members)  # 1-based round idx
        lines.append(f"local {prefix}_C{ci}={{{vals}}}")
        lines.append(f"local {prefix}_O{ci}={{{order}}}")
    hvals = ",".join(obf_u32(rng, v) for v in p["h0"])
    lines.append(f"local {prefix}_H={{{hvals}}}")
    lines.append(f"local {prefix}_K={{}}")
    for ci, members in enumerate(chunks):
        lines.append(f"for __i=1,#{prefix}_C{ci} do {prefix}_K[{prefix}_O{ci}[__i]]={prefix}_C{ci}[__i] end")
    # wipe chunk tables (anti-dump: do not keep fragments)
    for ci in range(nch):
        lines.append(f"{prefix}_C{ci}=nil")
        lines.append(f"{prefix}_O{ci}=nil")
    r0, r1, r2, r3, r4, r5 = p["rots"]
    lines.append(f"local {prefix}_R={{{r0},{r1},{r2},{r3},{r4},{r5}}}")
    lines.append(f"local {prefix}_N={p['rounds']}")
    return "\n".join(lines)
